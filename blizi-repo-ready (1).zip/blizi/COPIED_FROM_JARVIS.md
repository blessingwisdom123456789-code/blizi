# Files copied from JARVIS

Each line: `jarvis_copied/<destination> <- Jarvis-master/<source>`

| Step | File | Origin | Purpose |
|------|------|--------|---------|
| 2 | `jarvis_copied/AgentAccessibilityService.kt` <- `Jarvis-master/android/app/src/main/kotlin/com/privateagent/private_agent/AgentAccessibilityService.kt` | `Jarvis-master` | Screen dump (dumpScreen), tap (clickAt), swipe, scroll, typeText, global keys (pressKey), screenshot (takeScreenshotBase64). Package renamed to com.blizi.ai.plugin.jarvis_copied; Flutter MethodChannel deps removed; instance tracking added so BliziNativeBridgePlugin can reach the running service. Registered in AndroidManifest.xml with BIND_ACCESSIBILITY_SERVICE + accessibility_service_config. |
