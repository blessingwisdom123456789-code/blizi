# BLIZI 3D body (experimental, opt-in, UNVERIFIED on real hardware)

> v0.4.0: a static GLB character is now bundled and shown by default when 3D is switched on; see `GLB_STATIC_MODE.md`. The rest of this page describes the rigged-VRM path, which is unchanged. "No model is included" below applies to VRM only.

Status: the viewer code is integrated and its logic is tested with FAKE three.js/three-vrm objects (35 checks).
**Nothing here has been rendered with real WebGL, loaded a real VRM file, or run on a phone.** The development
environment had no internet, no GPU/WebGL and no model file. The 2D SVG Blizi is unchanged and is the default and the fallback.

## What you must supply
A **full-body anime humanoid in VRM 0.x format** (this viewer targets the three-vrm 0.x API; VRM 1.0 files are not supported yet).
No model is included, and none was downloaded. Use only a model you made or have written permission to use, and read the license
stored in the VRM. VRoid Studio can export VRM; check which VRM version your copy exports (I could not verify its options).

Recommended targets for a mid-range Android phone (my estimates, not measured): file under ~10 MB (hard limit 25 MB),
roughly 30,000-50,000 triangles or fewer, textures 1024 px or smaller, few materials (each adds draw calls).
Needed VRM expression presets: Joy, Fun, Angry, A, Blink. Needed bones: head, chest, left/right upper arm.

## How it behaves
Settings -> "3D body (experimental)": switch on, pick the .vrm/.glb from the phone. The file is read in the browser, never uploaded,
and is NOT remembered after refresh. Libraries (three r128, its GLTFLoader, three-vrm 0.3.x) are fetched from cdnjs/jsDelivr only when you
pick a file; if one fails the status line says which and 2D Blizi stays.

- Expressions follow the existing BLIZI states (happy, thinking, surprised, serious, listening, speaking). VRM 0.x has no "surprised"
  preset, so surprise is approximated with a small open mouth.
- Idle: blinking, breathing, slow head sway, arms lowered. Speaking: the mouth moves with an approximate envelope.
  **It is not synchronized to the audio** (browser speech synthesis exposes no audio stream).
- Touch: tap = surprised reaction; horizontal drag turns her slightly.
- Performance guards: pixel ratio capped at 1.5, no antialiasing, low-power GPU hint, about 30 fps cap, rendering stops when the tab is hidden,
  Home is not the visible view, or the canvas is scrolled out of view. WebGL missing, context loss, a load error or a render error all fall back to 2D.

## Guesses that may need adjusting (this is why the two toggles exist)
Model facing direction (rotated 180 degrees by default; "Turn her around" flips it), arm-lowering angle and sign ("Flip arms"),
camera framing, and which three-vrm 0.3.x versions exist and work with three r128 (three candidates are tried in order).

## Next steps once a model is available
1. Test on the phone; report the status line text and what looks wrong.
2. Self-host the three libraries (copy them next to index.html) so the standalone site does not depend on a CDN.
3. Optionally persist the model with IndexedDB, add VRM 1.0 support (three-vrm 1.x/2.x modules), and add animation clips.
4. True lip-sync needs an audio source (a TTS service that returns audio, then amplitude/viseme analysis).
