# BLIZI Stage 4: mobile AI VTuber (status report)

Source of truth: the Manus Stage 2 ZIP (`_backup_original/`), plus the opt-in 3D viewer, simple mode, voice and PWA work layered on top.
No newer Manus ZIP was provided, and https://blizi-ngujm8uk.manus.space could not be reached from the build environment, so anything that exists only on that live site is unseen here.

## Phase 1 findings
- Framework: none. Vanilla single-file frontend (`frontend/index.html`), dependency-free Node host (`server.mjs`), Worker-style backend (`backend/worker.js`).
- Character: BLIZI is a **2D inline-SVG** anime boy (dark futuristic outfit, electric-blue/cyan lighting, expressive eyes, six expression states). Preserved unchanged.
- The ZIP contains **no VRM, no 3D model, no rig, no animation clips, no existing viewer** and no PWA files (no manifest or service worker).
- **Missing asset (needs you): a full-body VRM 0.x model of BLIZI.** I cannot create 3D art here. Options: build it in VRoid Studio, or commission an artist using the BLIZI design.

## Phase 2: 3D avatar (built, NOT verified on real hardware)
Opt-in viewer (`Body3D`): three r128 + GLTFLoader + three-vrm 0.3.x, loaded from a CDN only when you pick a VRM file. Blinking, breathing, head sway, expressions,
touch (tap reacts, drag turns), 30 fps cap, pauses when hidden, 2D fallback on any failure. Wave, jump and dance are **code-driven poses, not animation clips**
(no clips exist); axis/sign choices are guesses. See `docs/3D_BODY.md`. Evaluated route: a separate Unity/native app was not built; the in-browser route keeps one integrated BLIZI.

## Phase 3: AI brain and voice
- Gemini chat through the secure backend (unchanged, mock-tested only).
- **New: `POST /tts`** (Gemini text-to-speech, key server-side, 500-character limit, 10/min limiter, session required in secure mode, allowed in simple mode).
  Needs `GEMINI_TTS_MODEL` (and optionally `GEMINI_TTS_VOICE`). Request/response format is from the author's knowledge of the API and is **unverified against live docs**.
- **Lip-sync is driven by the generated audio itself**: the page decodes the returned PCM, computes a mouth-openness envelope from the real samples, and reads it on the
  audio clock while it plays. It is amplitude-driven (open/close), **not phoneme/viseme accurate**. It drives the 3D mouth and the 2D SVG mouth.
- If `/tts` fails, the user is told and the browser voice is used. The microphone-loopback method from the Gemini concept was **not** implemented (unreliable and unnecessary).
- Real Gemini chat, real Gemini speech, and real lip-sync on a phone: **never tested.**

## Phase 4: Android
- Mobile-first layout, 2D fallback, and capped render cost are in place.
- **PWA files added** (`manifest.webmanifest`, `sw.js`, icons). Service worker is network-first for the app shell and never touches `/chat`, `/tts`, `/memory`, `/auth`.
  Chrome install needs HTTPS hosting with these files served next to `index.html`. Logic is tested; installing on a phone was not.

## Test status (273 checks, all pass)
Mock/fake only: worker + adapter 66, Gemini chat 37, Node host + secure mode 14, simple mode 17, TTS 37, lip-sync math 10, PWA/service worker 15,
3D logic with fake libraries 48, page script in a stubbed browser 29. **Not tested:** real WebGL, a real VRM, real Gemini (chat or speech), real audio output,
real phone layout/performance, PWA install, deployment.

## What needs your action
1. A full-body VRM 0.x model (the one missing asset).
2. Deploy (Cloudflare Worker or Node host) per `docs/DEPLOY.md` and host the frontend folder (index.html, manifest, sw.js, icons) on HTTPS.
3. Fresh Gemini key as a server secret; set `GEMINI_MODEL_FAST` and `GEMINI_TTS_MODEL` from AI Studio's list. Keep billing off for a free tier; limits unverified.
4. On the phone: Settings -> Backend URL (ending `/chat`) -> Test AI connection; Voice source -> Backend; 3D body -> pick the VRM; Chrome menu -> Install app.

## Fix: "No compatible three-vrm build could be loaded"
The viewer requested `@pixiv/three-vrm@0.3.11`, `0.3.10` and `0.3.9`. Those versions could not be confirmed to exist on npm/jsDelivr (the published 0.x list I could see shows 0.3.3, 0.3.4 and 0.6.x), so every attempt failed and the viewer fell back to 2D. The loader now tries `0.6.7` and `0.3.4` on jsDelivr, each with an unpkg mirror. The same UMD API (`THREE.VRM.from`, `blendShapeProxy`, `humanoid.getBoneNode`) is used. NOT verified in a real browser: confirm by loading a .vrm on the deployed site.
