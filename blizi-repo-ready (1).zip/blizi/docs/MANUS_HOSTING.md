# Manus-hosted BLIZI v0.4.0

This publication uses the existing public Manus WebDev project `BLIZI AI`; it does not deploy to or modify the owner's Cloudflare account. The site keeps the archive's frontend, icon, manifest, service worker, and chat design. A separate Node container serves `POST /chat` and calls the Manus built-in LLM API using credentials injected only into the server runtime. No browser asset contains a provider key. The app's database remains off.

## Character personality

Edit `config/blizi-personality.txt` to change BLIZI's default voice. Save and publish the change to update the running app. Interface context (such as the selected name/persona and saved notes) is treated as user-controlled context and cannot replace the server character profile.

## Credit safeguards

- Maximum 500 Unicode characters in each user message (enforced in the UI and again on the server).
- Maximum 5 accepted AI requests per visitor/IP in any rolling 10-minute window.
- Maximum 20 accepted AI requests per visitor/IP per UTC day.
- Maximum 100 accepted AI requests per Node server process per UTC day.

The rate and daily counters are in memory because this release intentionally has no database. They reset on process restart or UTC-day rollover and are not shared across multiple simultaneous instances. The site therefore enforces the limits per active process; it cannot guarantee a durable account-wide daily ceiling without shared storage. The current chat uses `gpt-6-luna`, low reasoning effort, and a 240-token completion cap. When returned by the LLM API, the chat response includes prompt/completion token usage and a rough catalog-rate estimate; the platform's final credit accounting may differ.

## Updating the live site without changing its link

1. Open the existing Manus WebDev project **BLIZI AI** (the same project used for this deployment). Do not initialize a new project.
2. Edit the desired source file in that project. For personality-only changes, edit `config/blizi-personality.txt`.
3. Save the change to the project's canonical `main` branch by committing and pushing through the existing WebDev Git connection. This project already has auto-publish enabled; an accepted checkpoint automatically republishes to the same project URL.
4. Wait until the WebDev dashboard shows the new published version, then reload the existing site. No Cloudflare change or new Pages project is required.

For a larger source replacement, use the downloaded complete source archive as the source, but update the existing **BLIZI AI** project/repository rather than creating another project. Preserve its existing project identity, publication setting, and public hostname.

## Reproduction checks

`npm run test:manus` runs local mock-only adapter/server regression checks. `npm test` runs the retained upstream v0.4.0 test suite. The latter does not contact the live AI provider. Container readiness is `GET /_app/health`; `POST /chat` is same-origin-only for the published app.
