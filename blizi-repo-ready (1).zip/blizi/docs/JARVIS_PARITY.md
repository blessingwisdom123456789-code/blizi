# Jarvis to Blizi parity audit

Source: the 49 files in Jarvis `lib/services`. Classified from file size, doc comments, endpoints and method names, not from reading every line of every file. Public web APIs were tested only against fakes; the build sandbox has no network, so nothing here has been tried against the real services or on a real phone.

## Summary

- Built: 3
- Partly built: 14
- Blizi already has an equivalent: 9
- Buildable in the web app (not built yet): 1
- Buildable with Blizi AI (not built yet): 2
- Needs a server (not built yet): 3
- Needs the native app: 17

## Built

- `airspace_radar_service`: ISS position (wheretheiss.at) and aircraft overhead (OpenSky). Not yet tried against the real APIs from a browser
- `finance_tracking_service`: live crypto prices (CoinGecko) plus a spending log. Not yet tried against the real API from a browser
- `todo_service`: todos.js

## Partly built

- `calendar_reminder_service`: reminders built; no calendar events or recurring reminders yet
- `charging_telemetry_service`: battery and charging text; no Arc Reactor charging screen
- `commute_traffic_service`: driving route and time between two places; no live traffic and no proactive warnings
- `email_triage_service`: paste an email and the AI summarizes it and suggests a reply; reading a real inbox is native
- `jarvis_tools_service`: weather (wttr.in), Wikipedia, date and time built. News and web search still need a worker proxy
- `message_drafting_service`: AI drafts the message text; no send links (wa.me, sms:, mailto:) yet
- `multi_task_service`: rule-based brain-dump splitter; Jarvis uses AI to extract tasks
- `notes_knowledge_service`: notes saved and listed; no search or AI knowledge-base yet
- `polyglot_diplomat_service`: typed "translate to X: text" through the AI; live two-way voice translation not built
- `routine_automation_service`: manual routines built; no automatic morning/evening trigger yet
- `security_alert_service`: risky tools need a confirm card in the registry; no risk scoring of AI output
- `sound_radar_service`: rough microphone loudness only; no song identification
- `system_diagnostics_service`: network, memory, CPU threads, storage, battery; no OS model, ROM, thermals (browsers hide them)
- `workflow_service`: manual routines only; no auto-evolved workflows

## Blizi already has an equivalent

- `ai_service`: Blizi has its own AI layer
- `conversational_memory_service`: Blizi Core State facts and episodes cover this; not compared in depth
- `edge_tts_service`: Blizi has /tts voice; Edge neural voices not ported
- `hermes_evolution_service`: Blizi has identity and self-model; SOUL/self-evolving files not ported
- `jarvis_service`: central controller; Blizi page script plays this role
- `personality_service`: Blizi already has persona, humor and formality settings; emotion detection not compared in depth
- `proactive_agent_service`: Blizi has core/proactive.js check-ins
- `settings_service`: Blizi has its own settings
- `voice_service`: Blizi has speech recognition and backend/browser voice

## Buildable in the web app (not built yet)

- `skill_memory_service`: replay of saved action sequences; routines are the manual version

## Buildable with Blizi AI (not built yet)

- `optical_solver_service`: camera photo to AI vision; needs your AI backend to accept images
- `vision_perception_service`: camera photo to AI vision; same dependency

## Needs a server (not built yet)

- `smart_home_service`: Home Assistant is on your LAN: browsers hit CORS/mixed-content limits, so route via a worker or the app
- `sports_service`: needs a search proxy for live results; the web has no key-less scores API I can rely on
- `telegram_service`: needs a bot token and a worker webhook

## Needs the native app

- `air_gesture_service`: camera hand tracking in the background
- `app_launcher_service`: list and launch installed apps
- `app_usage_service`: UsageStatsManager
- `code_black_service`: hardware lockout / deceptive screen
- `floating_copilot_service`: reads other apps on screen
- `form_filling_service`: fills forms in other apps via accessibility
- `inbox_service`: reads SMS and email notifications
- `macro_recorder_service`: records screen taps through accessibility
- `native_bridge_service`: Android MethodChannel dispatcher (Blizi has BliziNative as the web-side stub)
- `network_audit_service`: scanning the Wi-Fi subnet is impossible in a browser
- `permission_manager_service`: Android permission audit
- `phone_storage_service`: free file access to Downloads/Documents; browsers only get sandboxed files
- `recovery_engine`: only supports the screen agent loop
- `screen_automation_service`: accessibility service
- `sentry_service`: motion-sensor anti-theft in the background
- `system_control_service`: volume, brightness, alarms, contacts, dialer
- `task_executor`: the agent loop that drives the screen
