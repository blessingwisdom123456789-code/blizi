# BLIZI Core State v1

This document records the compatibility review and the first implementation milestone. The uploaded Core State Schema and `BLIZI-Core-State-v1-Implementation-Handoff` are authoritative; this repository does not contain a separate copy of `BLIZI-Core-State-Schema-v1.md`, so field-level decisions not repeated in the handoff remain intentionally unexpanded.

## 1. Compatibility assessment

BLIZI is compatible with the Core State direction. The app is a vanilla static frontend with ES5-style IIFE modules, injected time/randomness in tests, a localStorage-based legacy data model, and a stable `AI.complete(...)` boundary. The existing Cloudflare/D1 secure-memory backend can remain untouched because Core State v1 is local-only.

The repository already contains a substantial Phase A foundation: `core-schema.js`, `core-store.js`, `core-events.js`, `core-seed.js`, `core-migrations.js`, and `core-state.js`; a single `prof_main` profile; IndexedDB/localStorage/memory adapters; atomic event mutations; non-destructive legacy staging; export/import; snapshots; and the `off|shadow|on` setting. The existing tests cover these pieces.

Before this milestone, the compatibility gaps were the missing canonical identity API and integrity hash, the missing identity-only context assembler, and the absence of a real `instr()` integration path. The current page also loads Core State after avatar modules but lacked the new Phase A scripts in the service-worker shell and explicit server route table.

The authoritative constraints are preserved: no new dependencies, no renderer coupling, no automatic model calls from Core State, one profile with enforced `profileId`, sensitive records rejected, and `S.core = "off"` retaining the legacy prompt behavior.

## 2. Required architecture changes

Phase A adds `frontend/core/identity.js` and `frontend/core/context-assembler.js`. `identity.js` owns the immutable seeded identity record (`idn_main`), canonical hard-boundary hashing through injected `crypto.subtle`, read/render/verify APIs, and atomic first-write through the existing event layer. It deliberately exposes no general identity setter.

`context-assembler.js` is a pure, bounded identity block builder. It never calls an AI model and never touches avatar APIs. Later phases can add mood, relationship, projects, facts, and episodes as separately ranked blocks without changing the `AI.complete` boundary.

`core-state.js` now opens the identity service as part of Phase A and exposes it through the facade. The page loads both modules before the inline app code; the Node server and service worker serve/cache them. The prompt integration keeps a separate legacy builder: `off` returns it unchanged, `shadow` builds the Core block but sends the legacy prompt, and `on` sends the bounded Core prompt with fallback to legacy on any error.

## 3. Migration strategy

Legacy localStorage remains the source of truth while `S.core` is `off`. On open, the existing migration code stages an immutable, refreshable raw snapshot of `blizi.settings`, `blizi.settings.manus.v1`, `blizi.notes`, and `blizi.convs` without deleting or interpreting the source data. The identity seed is only a candidate projection at this stage; no user values silently overwrite the canonical identity.

When a later migration promotes values, it must be explicit, versioned, profile-scoped, event-logged, and reversible through export/snapshot restore. Existing secure backend memory is not imported into Core State v1. A future encrypted bundle backup may use the existing backend, but it is out of this milestone.

## 4. Context Assembly plan

Phase A assembles only the identity block. The target default is 2800 characters and the hard ceiling is 3000 because the backend rejects longer system prompts. The identity block is capped at 450 characters and is appended to the existing base only in Core `on` mode.

Later phases reserve the budget as follows: fixed rules/persona/date 650, identity 450, mood/relationship 250, relevant project 350, memories 900, and 400 characters of slack. Selection must be deterministic, local, lexical, source-labelled, and bounded. It must trim lowest-priority blocks first, never include sensitive/non-active records, record used IDs in `meta.lastContext`, and return the legacy prompt on errors or timeouts.

## 5. First implementation milestone

Phase A delivers: identity seed and record, hard-boundary SHA-256 integrity verification, identity render, bounded identity context assembly, Core State facade wiring, flag-gated prompt behavior, script/cache/server route wiring, and regression tests. Exit evidence is identity round-trip/export/import, tamper detection, prompt compatibility while `off`, and a context length at or below 3000 characters.

Run `npm test` from the repository root. The tests remain dependency-free and use fake storage/crypto where appropriate; browser rendering and real providers are not required for this milestone.

## Phase C — Relationship System

Phase C adds `frontend/core/relationship.js` with one profile-scoped `relationship` record. It preserves provenance on communication preferences as `{value, source, confidence}`, with `stated` values taking precedence over `inferred` values. The record includes `typicalActiveHours`, bounded interaction history, user-entered people, familiarity, rapport, trust inputs, quiet hours, explicit autonomy caps, and user-defined rituals.

The module exposes `get`, `setPreference`, `recordSession`, `recordInteraction`, `isQuietNow`, `autonomy`, `autonomyDetails`, `setAutonomyCap`, `explain`, people add/update/remove, ritual add/update/remove/record, and `recordPromise`. Autonomy is inspectable as `min(userCap, earnedLevel)` with familiarity and trust inputs; there is no hidden relationship score. Every mutation uses the existing atomic store-plus-event-log path. Legacy settings map without loss: `S.name` to `addressing.userCalledBy`, `S.persona` to stated tone, and `S.speak`/`S.voice` to stated voice preferences. Existing settings remain the source of truth while Core is `off`.

Integration remains boundary-based. The page records a relationship session only when Core is not `off`; the relationship service feeds a small deterministic mood cause and reads identity metadata during initialization. AvatarController, blink scheduling, idle motion, lip-sync, and Project Ledger APIs are unchanged. Existing relationship records migrate in place: missing interaction history, rituals, and autonomy explanation fields are defaulted without changing prior scores or preferences. Tests cover stated-over-inferred precedence, session familiarity/rapport behavior, interaction history, explicit autonomy caps, ritual lifecycle, quiet-hour suppression, legacy migration, profile isolation, and `off|shadow|on` behavior. No episodic-memory changes were made.

## Phase D — Memory System

Phase D adds `frontend/core/episodes.js` and `frontend/core/facts.js`. Episodic memory stores bounded rule-based conversation summaries with topics, projects, people, importance, strength, pinning, recall timestamps, and active/archive state. It supports capture, query, update, pin, delete, touch, decay, capacity maintenance, and the 2000-active-record cap. Semantic memory stores profile-scoped facts with source provenance, confidence, status, temporal metadata, and optional changing/reconfirmation rules. It supports add, confirm, retract, dispute, query, decay, and explicit correction.

Every memory mutation uses the existing atomic store-plus-event-log path. Corrections create a locked replacement fact and a correction record; `purgeBefore: true` deletes the old value rather than copying it into the correction record. Inferred facts are capped at 0.5 confidence and are never created automatically by conversation text. The page recognizes only explicit patterns such as `my name is`, `call me`, `I prefer`, and `remember that` when Core is enabled.

Raw conversation transcripts are intentionally not persisted in Phase D. Although the handoff describes an optional transcript store, the project decision that sensitive memory is disabled in v1 takes precedence; episodic capture stores bounded summaries only. Existing legacy localStorage and secure backend memory are not migrated or deleted. `off` keeps the legacy prompt and storage behavior unchanged; `shadow` may stage Core memory without changing replies; `on` enables Core memory capture. No avatar or VRM work was added.

## Phase E — Project Ledger

Phase E adds `frontend/core/projects.js` with a seeded `proj_blizi` record and profile-scoped project records. Projects contain status, aliases, keywords, goals, roadmap phases, milestones, decisions, open/resolved issues, people, and pointer-only references. Decisions require rationale and scope; overlapping scopes are returned as conflicts instead of being silently selected. Milestone completion stores bounded evidence pointers and feeds a deterministic positive mood cause without coupling the ledger to avatar code.

The ledger exposes create/get/list/update, addDecision, addIssue, resolveIssue, completeMilestone, detect, and bounded render APIs through `core.projects()`. Local `/decide`, `/issue`, and `/done` commands are handled in the browser and are never sent to the AI engine. The ledger uses the existing event-log path, remains single-profile (`prof_main`), and receives optional dependency handles for episodes, relationship, and mood without duplicating those stores. Context Assembly is intentionally unchanged and was not implemented in this phase.
