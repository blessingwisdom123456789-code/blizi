# BLIZI Stage 2 — private backend and cloud-memory foundation

**Status: implementation and mock testing only. Not deployed. Not yet verified against a real Cloudflare account, D1 database, browser cookie policy, or AI provider. Do not expose a public endpoint until the gated deployment checklist below has been completed.**

This stage extends the existing BLIZI project. It preserves `frontend/index.html`, the existing BLIZI character and personality, the provider adapter, local chats/notes, tools, and the optional page-runtime provider. Cloud backup is explicit and manual; no local history is silently uploaded.

## Security design

The deployment target is a Cloudflare Worker with a D1 binding named `DB`. This fits the existing Worker backend and has a small operational footprint. The app is currently configured as a **single-owner** service: a private backend password creates a session for the fixed principal `owner`. It does not implement public account registration, multi-user onboarding, password reset email, or team administration. The data schema is owner-keyed and request-provided user IDs are ignored. The automated isolation test seeds a second principal to prove that lookup, update, and delete use the session principal rather than a client-supplied ID; production login only creates the owner principal.

`POST /auth/login` compares the submitted password against the server-only `BLIZI_AUTH_PASSWORD`, uses a constant-time digest comparison, and creates a cryptographically random 256-bit session token. Only a SHA-256 digest of the token is persisted. Sessions expire after seven days; logout revokes the server-side session and expires the cookie. Production cookies use the `__Host-` prefix, `Secure`, `HttpOnly`, `Path=/`, and `SameSite=None`; the explicit `BLIZI_COOKIE_INSECURE=true` switch is for local HTTP testing only. The frontend uses `credentials: include` and never saves the password. For browser cookie compatibility, host the frontend and API on HTTPS origins under the same registrable site (for example `app.example.com` and `api.example.com`) and set `ALLOWED_ORIGINS` to the exact frontend origin. Do not rely on a cross-site third-party cookie setup.

Origin allowlisting is only an additional CORS/CSRF safeguard. Every chat and memory operation also requires a valid session. Login, chat, and memory requests are rate-limited through atomic D1 upserts: login by a keyed digest of the client IP (5 attempts per 15 minutes), chat by authenticated account (30 per minute), and memory operations by account (60 per minute). The IP is not stored in clear text. Expired rate-limit buckets are pruned opportunistically. These controls are not a substitute for Cloudflare WAF/edge abuse controls if the service is exposed more broadly.

Chat and memory request bodies are size-limited and schema-validated; only `user`/`assistant` chat turns and `user`/`bot` saved messages are accepted. Provider keys remain Worker secrets. Provider error details and secret values are not returned to the browser. Responses include `Cache-Control: no-store` and `X-Content-Type-Options: nosniff`; the Node development host also returns common framing/referrer/content-security headers and does not trust a client-provided IP header.

### Cloud-memory privacy

`migrations/0001_secure_memory.sql` creates `sessions`, `rate_limits`, and `user_data`. Memory, notes, and saved conversations are serialized as one payload and encrypted in the Worker with AES-256-GCM using a fresh random IV on each write. Only ciphertext plus user ID and update timestamp are stored in D1. The encryption key is derived from the separately configured `MEMORY_ENCRYPTION_KEY`; it never goes to the browser or AI provider. The Worker necessarily decrypts data to return an authenticated user’s cloud backup. This is **server-side application encryption, not end-to-end encryption**: someone with Worker execution and its encryption secret could access the data. Cloud backup is separately controlled from on-device storage and does not occur automatically.

The Settings page adds explicit actions to back up current local data, restore cloud data to this device, export the cloud copy as JSON, explicitly import a JSON backup to replace cloud data (with a confirmation step), and delete the cloud copy. Deleting cloud data does not delete local data. Exported JSON is plaintext after download; store it privately. The backend limits cloud history to 30 conversations, 100 saved messages per conversation, and bounded text sizes. Existing local-memory behavior is retained during the transition.

`MEMORY_ENCRYPTION_KEY` is part of the recovery boundary. Back it up in a password manager or secure secret vault. If it is lost or changed without re-encrypting existing rows, encrypted cloud memory becomes unreadable. Do not rotate it by simply replacing the secret. A rotation procedure must decrypt all rows using the old secret and re-encrypt using the new secret before removal of the old one. Password/session-secret rotation invalidates or disrupts sessions, so plan it separately.

## Required manual configuration (not performed here)

1. Create a Cloudflare D1 database named `blizi-memory` and use its returned database ID in a local `wrangler.toml` copied from `wrangler.toml.example`. Keep the real `wrangler.toml` out of version control if it contains account-specific IDs.
2. Apply the included migration to a **staging** D1 database first, inspect the tables, then apply the same migration to the intended production database. Do not run the migration against an unrelated or existing database.
3. In the Cloudflare Worker’s **secret/environment secret** interface, set `BLIZI_AUTH_PASSWORD`, `SESSION_SECRET`, and `MEMORY_ENCRYPTION_KEY`, plus the selected AI provider key (`GEMINI_API_KEY` or `PROVIDER_KEY`). Use independent strong values. Generate random secrets locally with a password manager or `openssl rand -base64 48`; enter values directly into the host’s secure secret UI. Do not put them in `.env`, source code, Git, logs, or chat. Set model IDs, exact `ALLOWED_ORIGINS`, and non-secret configuration separately.
4. Attach the D1 binding exactly as `DB`. Keep `BLIZI_COOKIE_INSECURE` unset in production. The example config’s `ALLOWED_ORIGINS` placeholder must be replaced by the real HTTPS frontend origin; a wildcard is not supported.
5. Deploy to a private/staging Worker first. Complete the real integration and browser acceptance checks below before enabling public routing or sharing the URL. A configured URL or passing mock test is not deployment evidence.

No Cloudflare account, custom domain, database, production secret, AI API key, or deployment permission was available or used during this stage. The API key slots remain placeholders; no real provider request was sent.

## Staging acceptance gate (required before production exposure)

- Verify migration state and schema against the target D1 instance; confirm no saved memory fields appear in plaintext in a D1 export.
- From an HTTPS browser at the exact allowed origin, confirm unauthenticated `/chat` and `/memory` requests fail; wrong password is rejected; correct password creates a secure cookie; logout revokes the session; unknown origins fail; repeated login/chat calls return 429.
- Confirm a valid authenticated request succeeds, a tampered cookie fails, an expired/revoked session fails, and one account cannot read, overwrite, or delete another account’s data. The live app currently provisions only one account, so use an isolated staging-only second principal to validate the SQL ownership predicate if a multi-principal test is required.
- Back up a harmless test memory, export it, restore it to another browser/device, delete it, and verify local data remains. Confirm wrong/missing encryption key fails closed with a generic storage error and do not overwrite the old key.
- Test the selected provider once with a non-sensitive test prompt. A provider response proves that one live integration call worked; it does not prove other models, limits, or billing terms.
- Check rate limiting at the edge as well as the D1 application limiter, logs for accidental credential/content capture, and the actual browser’s cookie behavior.

Until all of these pass, do not point a public app at the Worker. The repository tests currently do not perform these real integration checks.

## Database migrations, backups, recovery, rollback

The migration is additive and creates new tables only. Keep local copies of the previous Worker version and the exact `wrangler.toml`/migration version before rollout. Apply schema before deploying code that uses it. For rollback, redeploy the previous Worker build while leaving the new tables intact; do not drop the Stage 2 tables as part of an application rollback. If the migration itself is wrong, pause writes and restore from the pre-migration backup/Cloudflare recovery point in a reviewed operation.

For D1 exports, use Cloudflare’s documented command (the SQL export contains encrypted memory ciphertext, but still contains account identifiers and session/rate-limit metadata):

```sh
npx wrangler d1 export blizi-memory --remote --output=./blizi-memory-backup.sql
```

Keep that file private and outside Git. Cloudflare documents restore/import via `wrangler d1 execute <database_name> --remote --file=<export.sql>`. Prefer importing into a separate recovery database and verifying tables/data before any destructive production restore. D1 exports can block other database requests while the export runs.

Cloudflare D1 Time Travel provides a short recovery window (currently documented as seven days on Free and up to 30 days on paid plans; verify the current account-specific policy). A separate encrypted-database SQL export is still recommended for longer retention. The browser’s cloud JSON export is a user-controlled decrypted copy; restore it to the cloud only through the app’s explicit JSON-import action, after checking that the selected account is correct. Retain local device copies and D1/Time Travel recovery as independent recovery paths.

## Tests and what they prove

Run `npm test` from the project root. The current suite uses a mocked D1 implementation and mocked Gemini/OpenAI-compatible endpoints. It checks auth rejection, wrong credentials, session cookies/revocation, login and chat throttles, owner scoping, encrypted memory round-trips, validation, provider key non-disclosure, adapter compatibility, and the local Node host. The Node integration test uses real local HTTP between the test host and mock Worker/provider, but **D1 and both AI providers are simulated**. None of this proves that Cloudflare D1, Cloudflare secret injection, an HTTPS deployment, browser cookie storage, or a real provider is working.

## Cost and limits (Cloudflare docs checked 2026-10-17)

Cloudflare D1 Free currently advertises 5 million rows read per day, 100,000 rows written per day, and 5 GB total storage; Free reads/writes stop at daily limits until reset. D1 paid currently lists larger monthly included quotas and usage-based overages. Workers Free currently has a 100,000 requests/day limit; paid Workers starts at US$5/month with included usage, subject to current plan details. D1 and Workers quotas/prices change; verify them in the Cloudflare dashboard before launch. D1 Time Travel retention differs by plan as above. A small private app may fit free quotas, but abuse, chat volume, conversation size, and edge requests can change that. AI provider usage is separate and may incur costs; this implementation does not estimate or cap provider billing beyond application request throttles.

Official references: [D1 pricing](https://developers.cloudflare.com/d1/platform/pricing/), [Workers pricing](https://developers.cloudflare.com/workers/platform/pricing/), [D1 migrations](https://developers.cloudflare.com/d1/reference/migrations/), [D1 Time Travel](https://developers.cloudflare.com/d1/reference/time-travel/), [D1 import/export](https://developers.cloudflare.com/d1/best-practices/import-export-data/).
