# SIMPLE MODE (recommended first test; no D1, password or sessions)

Opt in by setting the Worker text variable `BLIZI_MODE` to exactly `simple`. Then you only need:
- `GEMINI_API_KEY` (secret), `GEMINI_MODEL_FAST` (text, a model id from Google AI Studio), `ALLOWED_ORIGINS` (text, your site's exact origin)

Protection in this mode is only the Origin allowlist (browsers only) and a best-effort in-memory limit of 20 chat requests/minute per IP per
Worker instance. Anyone who learns the Worker URL can call it from a script and spend your provider quota. Keep the URL private, use a fresh key,
and move to the secure mode below before sharing the app. `/memory` and `/auth/*` are disabled in this mode, so the cloud-backup buttons will not work.

**Backend URL must end in `/chat`** (this worker returns 404 for other paths), e.g. `https://<name>.<account>.workers.dev/chat`.

Status: tested with mocks only (17 checks). No real Cloudflare deployment or real Gemini request has been made. Dashboard steps below are unverified.

---

# BLIZI — protected backend deployment (Stage 2)

**No public deployment has been made. Do not expose a backend until the staging gate in [Stage 2 security and memory](STAGE2_SECURITY_MEMORY.md) passes against a real D1 database and HTTPS browser.**

BLIZI remains the existing app and character. The existing AI adapter and Gemini/OpenAI-compatible provider adapters are retained. The backend now requires a private login, an authenticated session, an attached D1 database, a session secret, and a memory-encryption secret before API routes are enabled.

## Target architecture

- Existing `frontend/index.html` hosted as a static site over HTTPS.
- Existing `backend/worker.js` deployed as a Cloudflare Worker.
- Cloudflare D1 database bound to the Worker as `DB` and migrated with `migrations/0001_secure_memory.sql`.
- AI provider credentials, owner password, session secret, and memory-encryption secret configured as host-managed Worker secrets, never in source code or browser settings.
- Exact HTTPS frontend origin set in `ALLOWED_ORIGINS`.

Use the frontend and API on HTTPS origins under the same registrable domain (e.g. `app.example.com` and `api.example.com`) so browser cookie policies do not treat the API session as an unrelated third-party cookie. Set `ALLOWED_ORIGINS` to the exact frontend origin, without a trailing slash.

## Setup sequence

1. Review [Stage 2 security and memory](STAGE2_SECURITY_MEMORY.md) and create a disposable staging environment first. Do not use production memories for acceptance testing.
2. Create a D1 database with Wrangler or the Cloudflare dashboard. Copy `wrangler.toml.example` to a local, untracked `wrangler.toml`, replace the D1 `database_id`, and set model IDs plus the real exact `ALLOWED_ORIGINS` in `[vars]`.
3. Apply the migration to staging and verify schema. A typical Wrangler command is `npx wrangler d1 migrations apply blizi-memory --remote`; check the current Wrangler prompt/output and selected database before confirming. Never run it against a database whose identity you have not verified.
4. In the Worker’s secure secret interface, configure `BLIZI_AUTH_PASSWORD`, `SESSION_SECRET`, and `MEMORY_ENCRYPTION_KEY`. Also set either `GEMINI_API_KEY` or the existing OpenAI-compatible `PROVIDER_KEY`; do not configure both unless the code’s provider selection is intentionally updated. Configure the applicable provider model IDs as non-secret variables. Secret values should be entered directly into Cloudflare’s secure interface, not pasted into this repository, browser app, issue, or chat.
5. Deploy the Worker only to staging and run the full real acceptance gate in the security/memory document. The current `npm test` suite is not a real D1/provider deployment test.
6. Host the unchanged project `frontend/index.html` over HTTPS. In BLIZI Settings, set **Backend URL** to the Worker API URL ending in `/chat`, use the private backend password to sign in, then run **Test AI connection**. The Settings screen also contains opt-in cloud-memory controls; these require a live deployment and a signed-in session.
7. Only after successful real staging checks should you set the production origin/domain, provision production D1 and secrets, apply the migration to the verified production database, deploy, and verify using a non-sensitive test account/chat. Preserve a rollback copy and database backup first.

## Local tests

The local Node host remains available for testing, but production memory requires a D1 binding; a `.env` file does not create a persistent database. Never expose the local Node host directly. `BLIZI_COOKIE_INSECURE=true` is only for local HTTP testing; never set it in production. The included D1 test double is in-memory and loses data when the test process exits.

See [Stage 2 security and memory](STAGE2_SECURITY_MEMORY.md) for the secret inventory, cookie/session model, migration and recovery instructions, accepted tests, and current costs/limits.
