# Static GLB mode (BLIZI 3D, v0.4.0)

The bundled character `frontend/models/blizi-character.glb` (your upload, byte-identical, sha256 `473d2ccd…62c2c1`) is shown as a
**static 3D model**. It has no skeleton, no face shapes and no animations, so it does **not** have skeletal animation, expressions or lip-sync.

## What it does
- Settings -> 3D body -> **Use 3D body** downloads the viewer libraries and the character (about 5 MB) and shows her instead of the 2D Blizi. 3D stays opt-in (off by default; flip `DEF.b3d` in `index.html` to change that).
- Camera framing: normalised to a fixed body height and fitted to the canvas, including narrow portrait canvases.
- Gentle sway (about +/-0.4 rad), drag to turn freely, tap = small hop and wobble. Sway stops when Animations is off or the phone asks for reduced motion.
- **Disabled for static models** (buttons greyed, note text changes, code refuses): Wave / Jump / Dance, Flip arms, expressions, blink, approximate mouth movement, audio lip-sync.
- "Turn her around" adds 180 degrees. The bundled file faces +X, so the page applies a -90 degree correction (`yaw` in `sources`); the GLB itself is untouched.

## How a rigged VRM replaces her later (no rebuild)
The viewer picks the mode from the **file contents**, not a setting. `sources` in `index.html` is tried in order:
1. `models/blizi-character.vrm` (optional; absent today, served as a clean 404)
2. `models/blizi-character.glb`

Drop a VRM 0.x file at `frontend/models/blizi-character.vrm` and it wins automatically, with expressions, gestures and mouth movement.
A file picked in Settings overrides both for the session. VRM 1.0 is refused with a clear message (not supported yet).

## Error handling (all fall back to the 2D Blizi, with a readable status line)
Empty, over 25 MB, not a GLB, wrong glTF version, truncated, damaged header, required compression extensions (Draco/meshopt/basis, no decoder included),
unknown required extensions, no mesh, over 500k vertices, VRM 1.0, library download failure (names the host; suggests ad blocker/connection),
library loaded but not started, parse failure, empty/invalid bounds, WebGL missing or lost, offline/missing built-in file.
Header checks run before any download. Static mode never fetches three-vrm, so a three-vrm outage cannot block her.

## Files and external dependencies
- Bundled: the GLB (no external file needed for the model).
- **Still required from the internet:** three.js r128 (cdnjs) and its GLTFLoader (jsDelivr). three-vrm (jsDelivr, unpkg mirror) only for VRM files.
  They are not self-hosted because the build environment had no internet. Self-hosting is the recommended next step.
- The service worker caches the model after the first successful load (network-first). It is not pre-cached at install.
- `server.mjs` serves only the two exact `/models/blizi-character.{glb,vrm}` paths (ETag, 404 when absent, no traversal).

## Verified vs not verified
Verified (automated): `npm test`. 75 focused checks in `tests/glb-mode.test.mjs` plus the older suites.
Real in those tests: the viewer code, GLB header inspection (including on the real file: static, 30,890 vertices, no skins, no animations), the shipped bytes, the Node `/models` route.
**Fake in those tests:** three.js, GLTFLoader, three-vrm, WebGL, fetch for the built-in sources. These are logic tests, not browser verification.

**Not verified:** rendering in any real browser or phone; real three.js loading this GLB; that the -90 degree facing is right on screen
(derived from a rough software point-cloud render of the vertex data, not from three.js); lighting/exposure of the white outfit
(light intensities are estimates); frame rate and memory (3 textures of 2048x2048, about 49k triangles, one mesh, one material);
the real CDN files; PWA install and offline behaviour with the 5 MB file; the live site.

## If it looks wrong on the phone
Facing backwards or sideways: drag, or toggle "Turn her around"; report it and the `yaw` value gets corrected. Too bright or dark: tell me; the three light intensities are in `mountStatic`.
Blank/2D: read the status line under "Model file" and send me its text.
