import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { createBliziChatService } from "./backend/manus-chat.mjs";

const PROJECT_ROOT = path.dirname(fileURLToPath(import.meta.url));
const DEFAULT_STATIC_ROOT = path.join(PROJECT_ROOT, "frontend");
const PUBLIC_ORIGIN = process.env.BLIZI_PUBLIC_ORIGIN || "https://blizi-5wmngeff.manus.space";
const BODY_LIMIT_BYTES = 16 * 1024;
const MIME = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".mjs": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".webmanifest": "application/manifest+json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".glb": "model/gltf-binary",
  ".vrm": "model/gltf-binary",
  ".ico": "image/x-icon",
};

function json(res, status, body) {
  const data = Buffer.from(JSON.stringify(body));
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Content-Length": data.length,
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "strict-origin-when-cross-origin",
  });
  res.end(data);
}

async function readJson(req) {
  const chunks = [];
  let bytes = 0;
  for await (const chunk of req) {
    bytes += chunk.length;
    if (bytes > BODY_LIMIT_BYTES) {
      const err = new Error("body_too_large");
      err.status = 413;
      throw err;
    }
    chunks.push(chunk);
  }
  try {
    return JSON.parse(Buffer.concat(chunks).toString("utf8"));
  } catch {
    const err = new Error("invalid_json");
    err.status = 400;
    throw err;
  }
}

function staticFilePath(root, pathname) {
  let decoded;
  try { decoded = decodeURIComponent(pathname); } catch { return null; }
  if (decoded.includes("\0") || decoded.includes("\\") || decoded.split("/").some((part) => part === ".." || part.startsWith("."))) return null;
  if (decoded === "/") decoded = "/index.html";
  const file = path.resolve(root, `.${decoded}`);
  if (file !== root && !file.startsWith(root + path.sep)) return null;
  return file;
}

async function serveStatic(req, res, root) {
  if (req.method !== "GET" && req.method !== "HEAD") return json(res, 405, { error: "method_not_allowed" });
  const url = new URL(req.url, "http://localhost");
  const file = staticFilePath(root, url.pathname);
  let selected = file;
  if (!selected || !fs.existsSync(selected) || !fs.statSync(selected).isFile()) selected = path.join(root, "index.html");
  if (!fs.existsSync(selected)) return json(res, 404, { error: "not_found" });
  const ext = path.extname(selected).toLowerCase();
  const stat = fs.statSync(selected);
  res.writeHead(200, {
    "Content-Type": MIME[ext] || "application/octet-stream",
    "Content-Length": stat.size,
    "Cache-Control": [".html", ".webmanifest", ".js", ".mjs"].includes(ext) ? "no-cache" : "public, max-age=3600",
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "strict-origin-when-cross-origin",
    "Permissions-Policy": "microphone=(self), camera=()",
  });
  if (req.method === "HEAD") return res.end();
  fs.createReadStream(selected).pipe(res);
}

export function createManusServer({ chatService, staticRoot = DEFAULT_STATIC_ROOT, publicOrigin = PUBLIC_ORIGIN } = {}) {
  const chat = chatService || createBliziChatService({ allowedOrigin: publicOrigin });
  return http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, "http://localhost");
      if (url.pathname === "/_app/health") {
        if (req.method !== "GET" && req.method !== "HEAD") return json(res, 405, { error: "method_not_allowed" });
        res.writeHead(200, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" });
        return res.end(req.method === "HEAD" ? undefined : JSON.stringify({ status: "ok" }));
      }
      if (url.pathname === "/chat") {
        if (req.method !== "POST") return json(res, 405, { error: "method_not_allowed" });
        if (!String(req.headers["content-type"] || "").toLowerCase().startsWith("application/json")) return json(res, 415, { error: "content_type_required" });
        let body;
        try { body = await readJson(req); }
        catch (err) { return json(res, err.status || 400, { error: err.message === "body_too_large" ? "request_too_large" : "invalid_json" }); }
        const edgeIp = req.headers["cf-connecting-ip"];
        const visitor = typeof edgeIp === "string" && edgeIp.trim() ? edgeIp.trim().slice(0, 128) : (req.socket.remoteAddress || "shared-unknown");
        const result = await chat.handle({ body, origin: req.headers.origin || "", visitor });
        return json(res, result.status, result.body);
      }
      return serveStatic(req, res, staticRoot);
    } catch {
      if (!res.headersSent) return json(res, 500, { error: "server_error" });
      res.end();
    }
  });
}

if (process.argv[1] && pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url) {
  const port = Number(process.env.PORT) || 3000;
  createManusServer().listen(port, "0.0.0.0", () => {
    console.log(`BLIZI Manus host listening on port ${port}`);
  });
}
