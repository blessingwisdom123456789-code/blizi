// Optional Node host: serves the existing frontend and mounts the secure worker API.
// Lets BLIZI run outside Cloudflare (any Node 18+ host). No dependencies.
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import worker from "./backend/worker.js";

const root = path.dirname(fileURLToPath(import.meta.url));

const STATIC = {
  "/manus-routes.json": ["frontend/manus-routes.json", "application/json"],
  "/manifest.webmanifest": ["frontend/manifest.webmanifest", "application/manifest+json"],
  "/sw.js": ["frontend/sw.js", "text/javascript"],
  "/avatar/expression-map.js": ["frontend/avatar/expression-map.js", "text/javascript"],
  "/avatar/blink-config.js": ["frontend/avatar/blink-config.js", "text/javascript"],
  "/avatar/blink-scheduler.js": ["frontend/avatar/blink-scheduler.js", "text/javascript"],
  "/avatar/svg-renderer.js": ["frontend/avatar/svg-renderer.js", "text/javascript"],
  "/avatar/avatar-controller.js": ["frontend/avatar/avatar-controller.js", "text/javascript"],
  "/avatar/expression-arbiter.js": ["frontend/avatar/expression-arbiter.js", "text/javascript"],
  "/core/body-intent.js": ["frontend/core/body-intent.js", "text/javascript"],
  "/core/self-model.js": ["frontend/core/self-model.js", "text/javascript"],
  "/core/core-schema.js": ["frontend/core/core-schema.js", "text/javascript"],
  "/core/core-store.js": ["frontend/core/core-store.js", "text/javascript"],
  "/core/core-events.js": ["frontend/core/core-events.js", "text/javascript"],
  "/core/core-seed.js": ["frontend/core/core-seed.js", "text/javascript"],
  "/core/identity.js": ["frontend/core/identity.js", "text/javascript"],
  "/core/context-assembler.js": ["frontend/core/context-assembler.js", "text/javascript"],
  "/core/proactive.js": ["frontend/core/proactive.js", "text/javascript"],
  "/core/core-migrations.js": ["frontend/core/core-migrations.js", "text/javascript"],
  "/core/mood.js": ["frontend/core/mood.js", "text/javascript"],
  "/core/core-avatar-bridge.js": ["frontend/core/core-avatar-bridge.js", "text/javascript"],
  "/core/relationship.js": ["frontend/core/relationship.js", "text/javascript"],
  "/core/episodes.js": ["frontend/core/episodes.js", "text/javascript"],
  "/core/facts.js": ["frontend/core/facts.js", "text/javascript"],
  "/core/projects.js": ["frontend/core/projects.js", "text/javascript"],
  "/core/core-state.js": ["frontend/core/core-state.js", "text/javascript"],
  "/core/voice-profile.js": ["frontend/core/voice-profile.js", "text/javascript"],
  "/tools/registry.js": ["frontend/tools/registry.js", "text/javascript"],
  "/tools/native-bridge.js": ["frontend/tools/native-bridge.js", "text/javascript"],
  "/tools/reminders.js": ["frontend/tools/reminders.js", "text/javascript"],
  "/tools/todos.js": ["frontend/tools/todos.js", "text/javascript"],
  "/tools/extras.js": ["frontend/tools/extras.js", "text/javascript"],
  "/tools/device.js": ["frontend/tools/device.js", "text/javascript"],
  "/tools/web-info.js": ["frontend/tools/web-info.js", "text/javascript"],
  "/tools/page-actions.js": ["frontend/tools/page-actions.js", "text/javascript"],
  "/icons/icon-192.png": ["frontend/icons/icon-192.png", "image/png"],
  "/icons/icon-512.png": ["frontend/icons/icon-512.png", "image/png"],
  // Optional 3D character files. Exact names only (no directory listing, no path traversal). The .vrm is optional: a missing file is a 404.
  "/models/blizi-character.glb": ["frontend/models/blizi-character.glb", "model/gltf-binary", true],
  "/models/blizi-character.vrm": ["frontend/models/blizi-character.vrm", "model/gltf-binary", true]
};

export function makeServer(env) {
  return http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, "http://localhost");
      const st = STATIC[url.pathname];
      if (req.method === "GET" && st) {
        const file = path.join(root, st[0]);
        if (st[2]) { // large optional asset: 404 when absent, ETag so repeat visits revalidate instead of re-downloading
          if (!fs.existsSync(file)) { res.writeHead(404, { "Content-Type": "text/plain" }).end("Not found"); return; }
          const stt = fs.statSync(file), etag = '"' + stt.size.toString(16) + "-" + Math.floor(stt.mtimeMs).toString(16) + '"';
          if (req.headers["if-none-match"] === etag) { res.writeHead(304, { ETag: etag, "Cache-Control": "no-cache" }).end(); return; }
          res.writeHead(200, { "Content-Type": st[1], "Content-Length": stt.size, "Cache-Control": "no-cache", ETag: etag, "X-Content-Type-Options": "nosniff" });
          res.end(fs.readFileSync(file));
          return;
        }
        res.writeHead(200, { "Content-Type": st[1], "Cache-Control": "no-cache" });
        res.end(fs.readFileSync(file));
        return;
      }
      if (req.method === "GET" && (url.pathname === "/" || url.pathname === "/index.html")) {
        res.writeHead(200, { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-cache", "X-Content-Type-Options": "nosniff", "Referrer-Policy": "strict-origin-when-cross-origin", "Permissions-Policy": "microphone=(self), camera=()" });
        res.end(fs.readFileSync(path.join(root, "frontend", "index.html")));
        return;
      }
      if (["/chat", "/tts", "/auth/login", "/auth/logout", "/auth/session", "/memory"].includes(url.pathname)) {
        const chunks = []; let n = 0;
        for await (const c of req) { n += c.length; if (n > 1100000) { res.writeHead(413).end(); return; } chunks.push(c); }
        const headers = new Headers();
        for (const [k, v] of Object.entries(req.headers)) if (typeof v === "string") headers.set(k, v);
        // Do not trust a client-supplied forwarding header on this Node host.
        headers.set("CF-Connecting-IP", req.socket.remoteAddress || "unknown");
        const hasBody = req.method !== "GET" && req.method !== "HEAD";
        const r = await worker.fetch(new Request("http://localhost" + url.pathname + url.search, { method: req.method, headers, body: hasBody ? Buffer.concat(chunks) : undefined }), env);
        res.writeHead(r.status, Object.fromEntries(r.headers));
        res.end(Buffer.from(await r.arrayBuffer()));
        return;
      }
      res.writeHead(404, { "Content-Type": "text/plain" }).end("Not found");
    } catch (e) {
      res.writeHead(500, { "Content-Type": "application/json" });
      res.end('{"error":"server_error"}');
    }
  });
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const port = Number(process.env.PORT) || 8787;
  makeServer(process.env).listen(port, () => console.log("BLIZI AI listening on http://localhost:" + port));
}
