## Manus-hosted BLIZI site

This source package adds a Manus-hosted server adapter for the original v0.4.0 phone-first BLIZI chat. The live app uses Manus built-in AI from the server; no personal API key is needed in the browser. Read [docs/MANUS_HOSTING.md](docs/MANUS_HOSTING.md) for the editable personality file, exact credit safeguards, update path for the existing public link, and verification commands. The original Cloudflare Worker, migrations, tests, and deployment references remain in the source tree but are not deployed by this Manus-hosted release.

---

# BLIZI AI — existing project (Stage 2 security foundation)

BLIZI is the existing personal anime-style AI companion web app: mobile-first dark blue/cyan interface, animated 2D character and expressions, BLIZI’s established personality, chat, saved conversations, voice input/output, tools, and settings. This work extends the uploaded project; it does not create a second character or rebuild the application.

The existing frontend and provider adapter remain. Additions are private backend authentication, owner-scoped APIs, input/rate-limit protections, encrypted cloud-memory storage, opt-in backup controls, a D1 migration, and security documentation. No secrets are included; values in `.env.example` are placeholders.

## Project layout

| Path | Purpose |
|---|---|
| `frontend/index.html` | Existing single-file app, character SVG/animations, chat, local storage, voice, tools, settings, existing AI adapter, and optional manual cloud-memory controls. |
| `backend/worker.js` | Cloudflare Worker API proxy with fail-closed authentication, CORS/CSRF safeguards, rate limiting, validation, server-side provider calls, sessions, and AES-GCM encrypted cloud memory. |
| `server.mjs` | Dependency-free local Node host that serves the frontend and forwards API paths to the Worker handler. A real D1 binding is required for protected API use; the included in-memory D1 exists only in tests. |
| `migrations/0001_secure_memory.sql` | Additive D1 schema for sessions, rate limits, and encrypted user data. |
| `tests/` | `npm test` suite; mocks and their limits are described below. |
| `docs/PERSONALITY.md` | Existing BLIZI personality and response constraints. |
| `docs/STAGE2_SECURITY_MEMORY.md` | Security design, cloud-memory privacy, setup, staging acceptance, backup/rollback, tests, and costs. |
| `docs/DEPLOY.md` | Deployment checklist gated on real staging verification. |
| `.env.example`, `wrangler.toml.example` | Placeholders only; no secrets. |

## Architecture

```text
Existing BLIZI frontend, character, personality, tools and provider adapter
  ├─ selected page-runtime provider (only where that environment exists)
  └─ existing backend adapter -> authenticated POST /chat
       └─ Cloudflare Worker -> Gemini or existing OpenAI-compatible provider
            └─ provider keys remain server-side

Optional, user-triggered cloud-memory actions
  └─ authenticated /memory -> Worker AES-GCM encryption -> D1 ciphertext
```

The local browser copy of chat and notes remains in local storage as before. Cloud memory does not sync automatically; the user signs in and starts backup, restore, export, or deletion from Settings. No background tasks, scheduled execution, push notifications, or PWA installation work is claimed by Stage 2.

## Stage 2 status and verification

**Current deployment status: not deployed.** No Cloudflare account, D1 database, production secrets, custom domain, or real AI credentials were used here. No public backend is exposed, and no real AI provider request has been made.

**Automated tests:** `npm test` currently passes **115 checks** across three files (64 main worker/adapter checks, 37 Gemini worker checks, 14 local HTTP checks). The suite covers invalid credentials, unauthenticated/invalid sessions, login and chat throttles, owner-scoped memory reads/writes/deletion, encrypted memory round-trips and wrong-key failure, request validation, provider error mapping/key non-disclosure, existing adapter behaviors, CORS, and local host routing. The test D1 is an in-memory mock; Gemini and OpenAI-compatible endpoints are mocks. The local HTTP test uses actual local HTTP between the test process, Node host, and mock provider, but not Cloudflare or a real provider. These results do not verify production SQL compatibility, Cloudflare secret injection, browser cookie policy, real provider behavior, or deployment.

**Implemented in code but unverified against live services:** password login/session lifecycle, Worker+D1 session-backed API, D1-backed rate limiting, app-layer encrypted cloud-memory persistence, CORS credentials, and opt-in cloud-memory UI. Treat all cloud features as unavailable until a real staging deployment completes every acceptance check in `docs/STAGE2_SECURITY_MEMORY.md`.

**Still not provided by this stage:** public account registration, multi-user enrollment/password reset, actual cloud deployment, PWA manifest/service worker, push notifications, background jobs/scheduling/retries, streaming backend replies, or production operations/monitoring. The existing local-memory and chat functionality remain the usable fallback during migration.

## Run tests

Requirements: Node 18+ (run here on Node 22); no package install is required.

```sh
npm test
```

For a local development server, `npm start` can serve the existing frontend. The protected API requires a database binding; `.env.example` alone does not provide persistent D1 and local API requests should not be described as cloud-memory or production integration. Do not expose the Node server directly to the Internet.

## Configuration names

| Name | Purpose |
|---|---|
| `BLIZI_AUTH_PASSWORD` | Private single-owner login passphrase (host secret; minimum 16 chars). |
| `SESSION_SECRET` | Independent server-only secret for rate-limit HMAC and session-related security (minimum 32 chars). |
| `MEMORY_ENCRYPTION_KEY` | Independent server-only AES-GCM memory key material (minimum 32 chars; back it up securely). |
| `ALLOWED_ORIGINS` | Exact frontend origin(s), comma-separated; additional safeguard, not authentication. |
| `GEMINI_API_KEY` | Server-side Gemini key; when configured, selects the Gemini path. |
| `GEMINI_MODEL_FAST` / `GEMINI_MODEL_DEEP` | Gemini model IDs. |
| `PROVIDER_URL` / `PROVIDER_KEY` / `MODEL_FAST` / `MODEL_DEEP` | Existing OpenAI-compatible provider alternative. |
| `PORT` | Optional Node host port (default 8787). |
| `BLIZI_COOKIE_INSECURE` | Local HTTP test switch only; never set in production. |

Set production secrets in the hosting provider’s secure secret interface. Do not paste keys into the frontend, source, Git, logs, or chat. See `docs/DEPLOY.md` and `docs/STAGE2_SECURITY_MEMORY.md` before attempting deployment.


## Simple mode (added after Stage 2)
Set `BLIZI_MODE=simple` (exact value) to run the chat endpoint without D1, a password, or sessions. Secure mode is unchanged and still
fails closed when unconfigured. See the top of `docs/DEPLOY.md`. Mock-tested only (`tests/simple-mode.test.mjs`).

## 3D body (added after Stage 2; experimental)
Opt-in 3D viewer with automatic 2D fallback. v0.4.0 bundles a **static GLB** character (no skeleton: no expressions, lip-sync or gestures) and still supports rigged VRM 0.x files. See `docs/GLB_STATIC_MODE.md` and `docs/3D_BODY.md`. Logic tested with fake libraries only; real rendering is unverified. The pre-3D frontend is kept in `_backup_original/`.

## Stage 4: spoken replies, audio-driven lip-sync, PWA
`POST /tts` (Gemini TTS), lip-sync from the generated audio, procedural gestures, and installable-PWA files were added. Mock/fake-tested only; no VRM model is included.
See `docs/VTUBER_STAGE4.md` for the exact status and what needs your action.
