// BLIZI AI backend proxy (Cloudflare Workers module syntax).
// Provider keys remain server-side. All application routes require configured auth + D1.
// Origin checks are an additional browser/CSRF safeguard; they are never authentication.

const MAX_CHAT_BODY = 100000;
const MAX_MEMORY_BODY = 1000000;
const MAX_MESSAGES = 24, MAX_CHARS = 6000, MAX_SYSTEM = 3000, TIMEOUT_MS = 45000;
const SESSION_TTL_MS = 7 * 24 * 60 * 60 * 1000;
const GEMINI_BASE = "https://generativelanguage.googleapis.com/v1beta/models/";
const OWNER_ID = "owner"; // Single-owner deployment. Never accepted from a request.
let lastRatePruneHour = 0;

function allowedOrigins(env) {
  return String(env.ALLOWED_ORIGINS || "").split(",").map(s => s.trim()).filter(Boolean);
}
function cors(origin, env) {
  if (!origin || !allowedOrigins(env).includes(origin)) return null;
  return {
    "Access-Control-Allow-Origin": origin,
    "Access-Control-Allow-Credentials": "true",
    "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Max-Age": "600",
    "Vary": "Origin"
  };
}
function json(status, body, headers) {
  return new Response(JSON.stringify(body), { status, headers: Object.assign({ "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" }, headers || {}) });
}
function configReady(env) {
  if (simpleMode(env)) return allowedOrigins(env).length > 0;
  return !!(env && env.DB && typeof env.DB.prepare === "function" &&
    typeof env.BLIZI_AUTH_PASSWORD === "string" && env.BLIZI_AUTH_PASSWORD.length >= 16 &&
    typeof env.SESSION_SECRET === "string" && env.SESSION_SECRET.length >= 32 &&
    typeof env.MEMORY_ENCRYPTION_KEY === "string" && env.MEMORY_ENCRYPTION_KEY.length >= 32 &&
    allowedOrigins(env).length);
}
function cookiePolicy(env) {
  const localInsecure = env.BLIZI_COOKIE_INSECURE === "true";
  return { name: localInsecure ? "blizi_session" : "__Host-blizi_session", secure: !localInsecure, sameSite: localInsecure ? "Lax" : "None" };
}
function cookieValue(req, name) {
  const raw = req.headers.get("Cookie") || "";
  for (const part of raw.split(";")) {
    const i = part.indexOf("=");
    if (i < 0) continue;
    if (part.slice(0, i).trim() === name) return part.slice(i + 1).trim();
  }
  return "";
}
function b64url(bytes) {
  let s = "";
  for (const b of bytes) s += String.fromCharCode(b);
  return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}
function fromB64url(text) {
  const s = text.replace(/-/g, "+").replace(/_/g, "/"), padded = s + "=".repeat((4 - s.length % 4) % 4);
  const raw = atob(padded), out = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) out[i] = raw.charCodeAt(i);
  return out;
}
async function digest(text) {
  const out = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return Array.from(new Uint8Array(out), b => b.toString(16).padStart(2, "0")).join("");
}
async function keyedDigest(secret, text) {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const out = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(text));
  return Array.from(new Uint8Array(out), b => b.toString(16).padStart(2, "0")).join("");
}
async function memoryKey(secret) {
  const raw = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(secret));
  return crypto.subtle.importKey("raw", raw, { name: "AES-GCM" }, false, ["encrypt", "decrypt"]);
}
async function encryptMemory(env, data) {
  const iv = new Uint8Array(12); crypto.getRandomValues(iv);
  const plain = new TextEncoder().encode(JSON.stringify(data));
  const cipher = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, await memoryKey(env.MEMORY_ENCRYPTION_KEY), plain);
  return b64url(iv) + "." + b64url(new Uint8Array(cipher));
}
async function decryptMemory(env, text) {
  const split = String(text || "").split(".");
  if (split.length !== 2) throw new Error("encrypted_memory_format");
  const plain = await crypto.subtle.decrypt({ name: "AES-GCM", iv: fromB64url(split[0]) }, await memoryKey(env.MEMORY_ENCRYPTION_KEY), fromB64url(split[1]));
  return JSON.parse(new TextDecoder().decode(plain));
}
function constantTimeEqual(a, b) {
  const aa = new TextEncoder().encode(String(a)), bb = new TextEncoder().encode(String(b));
  let diff = aa.length ^ bb.length;
  const n = Math.max(aa.length, bb.length);
  for (let i = 0; i < n; i++) diff |= (aa[i % (aa.length || 1)] || 0) ^ (bb[i % (bb.length || 1)] || 0);
  return diff === 0;
}
async function readLimited(req, max) {
  const declared = Number(req.headers.get("Content-Length") || 0);
  if (declared > max) return { tooLarge: true };
  if (!req.body) return { text: "" };
  const reader = req.body.getReader(), chunks = [];
  let size = 0;
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > max) { try { await reader.cancel(); } catch (_) {} return { tooLarge: true }; }
      chunks.push(value);
    }
  } finally { try { reader.releaseLock(); } catch (_) {} }
  const all = new Uint8Array(size); let offset = 0;
  for (const c of chunks) { all.set(c, offset); offset += c.byteLength; }
  try { return { text: new TextDecoder("utf-8", { fatal: true }).decode(all) }; }
  catch (_) { return { invalidEncoding: true }; }
}
function parseJSON(text) { try { return JSON.parse(text); } catch (_) { return null; } }
function validateChat(b) {
  if (!b || typeof b !== "object" || Array.isArray(b)) return "invalid_body";
  if (!Array.isArray(b.messages) || b.messages.length < 1 || b.messages.length > MAX_MESSAGES) return "invalid_messages";
  for (const m of b.messages) {
    if (!m || (m.role !== "user" && m.role !== "assistant") || typeof m.content !== "string" || !m.content.trim() || m.content.length > MAX_CHARS) return "invalid_messages";
  }
  if (b.messages[b.messages.length - 1].role !== "user") return "invalid_messages";
  if (b.system !== undefined && (typeof b.system !== "string" || b.system.length > MAX_SYSTEM)) return "invalid_system";
  if (b.tier !== undefined && b.tier !== "fast" && b.tier !== "deep") return "invalid_tier";
  return null;
}
function normalizeMemory(b) {
  if (!b || typeof b !== "object" || Array.isArray(b) || typeof b.memory !== "string" || b.memory.length > 1000 || typeof b.notes !== "string" || b.notes.length > 20000) return null;
  const c = b.conversations;
  if (!c || typeof c !== "object" || !Array.isArray(c.list) || c.list.length > 30 || (c.cur !== null && typeof c.cur !== "string")) return null;
  const ids = new Set(), list = [];
  for (const item of c.list) {
    if (!item || typeof item.id !== "string" || !item.id || item.id.length > 64 || ids.has(item.id) || !Array.isArray(item.msgs) || item.msgs.length > 100 || !Number.isFinite(Number(item.t))) return null;
    ids.add(item.id);
    const msgs = [];
    for (const m of item.msgs) {
      if (!m || !["user", "bot"].includes(m.who) || typeof m.text !== "string" || m.text.length > 12000 || typeof (m.t || "") !== "string") return null;
      msgs.push({ who: m.who, t: (m.t || "").slice(0, 40), text: m.text, demo: !!m.demo, ai: !!m.ai });
    }
    list.push({ id: item.id, t: Number(item.t), msgs });
  }
  if (c.cur && !ids.has(c.cur)) return null;
  const clean = { memory: b.memory, notes: b.notes, conversations: { cur: c.cur, list } };
  if (JSON.stringify(clean).length > MAX_MEMORY_BODY - 4096) return null;
  return clean;
}
async function rateLimit(env, scope, identity, limit, windowMs) {
  const now = Date.now(), start = Math.floor(now / windowMs) * windowMs;
  const hour = Math.floor(now / 3600000);
  if (hour > lastRatePruneHour) {
    lastRatePruneHour = hour;
    await env.DB.prepare("DELETE FROM rate_limits WHERE window_start < ?").bind(now - 24 * 60 * 60 * 1000).run();
  }
  const hashed = await keyedDigest(env.SESSION_SECRET, String(identity));
  const key = scope + ":" + hashed;
  const row = await env.DB.prepare("INSERT INTO rate_limits (bucket_key, window_start, count) VALUES (?, ?, 1) ON CONFLICT(bucket_key) DO UPDATE SET count = CASE WHEN window_start = excluded.window_start THEN count + 1 ELSE 1 END, window_start = excluded.window_start RETURNING count").bind(key, start).first();
  if (!row || !Number.isFinite(Number(row.count))) throw new Error("rate_limit_storage");
  return { limited: Number(row.count) > limit, retryAfter: Math.max(1, Math.ceil((start + windowMs - now) / 1000)) };
}
function clientIp(req) {
  // Cloudflare supplies this header at the edge. Node server.mjs overwrites it with socket.remoteAddress.
  return req.headers.get("CF-Connecting-IP") || "unknown";
}
async function authenticated(req, env) {
  const policy = cookiePolicy(env), token = cookieValue(req, policy.name);
  if (!token || token.length > 128) return null;
  const tokenHash = await digest(token);
  const row = await env.DB.prepare("SELECT user_id, expires_at FROM sessions WHERE token_hash = ? AND expires_at > ?").bind(tokenHash, Date.now()).first();
  if (!row || typeof row.user_id !== "string" || !row.user_id) return null;
  return { userId: row.user_id, tokenHash };
}
async function handleLogin(req, env, corsHeaders) {
  if (req.method !== "POST") return json(405, { error: "method_not_allowed" }, corsHeaders);
  if (!String(req.headers.get("Content-Type") || "").toLowerCase().startsWith("application/json")) return json(415, { error: "content_type_required" }, corsHeaders);
  const bucket = await rateLimit(env, "login", clientIp(req), 5, 15 * 60 * 1000);
  if (bucket.limited) return json(429, { error: "rate_limited" }, { ...corsHeaders, "Retry-After": String(bucket.retryAfter) });
  const read = await readLimited(req, 4096);
  if (read.tooLarge) return json(413, { error: "body_too_large" }, corsHeaders);
  if (read.invalidEncoding) return json(400, { error: "invalid_body" }, corsHeaders);
  const body = parseJSON(read.text);
  if (!body || typeof body.password !== "string" || body.password.length > 256) return json(400, { error: "invalid_credentials" }, corsHeaders);
  const supplied = await digest(body.password), expected = await digest(env.BLIZI_AUTH_PASSWORD);
  if (!constantTimeEqual(supplied, expected)) return json(401, { error: "invalid_credentials" }, corsHeaders);
  const bytes = new Uint8Array(32); crypto.getRandomValues(bytes);
  const token = b64url(bytes), tokenHash = await digest(token), now = Date.now(), expires = now + SESSION_TTL_MS;
  await env.DB.prepare("INSERT INTO sessions (token_hash, user_id, created_at, expires_at) VALUES (?, ?, ?, ?)").bind(tokenHash, OWNER_ID, now, expires).run();
  await env.DB.prepare("DELETE FROM sessions WHERE expires_at < ?").bind(now).run();
  const p = cookiePolicy(env), secure = p.secure ? "; Secure" : "";
  const cookie = p.name + "=" + token + "; Path=/; HttpOnly" + secure + "; SameSite=" + p.sameSite + "; Max-Age=" + Math.floor(SESSION_TTL_MS / 1000);
  return json(200, { authenticated: true, expiresAt: expires }, { ...corsHeaders, "Set-Cookie": cookie });
}
async function handleSession(req, env, corsHeaders) {
  if (req.method !== "GET") return json(405, { error: "method_not_allowed" }, corsHeaders);
  const session = await authenticated(req, env);
  return session ? json(200, { authenticated: true }, corsHeaders) : json(401, { error: "unauthorized" }, corsHeaders);
}
async function handleLogout(req, env, corsHeaders) {
  if (req.method !== "POST") return json(405, { error: "method_not_allowed" }, corsHeaders);
  const session = await authenticated(req, env);
  if (session) await env.DB.prepare("DELETE FROM sessions WHERE token_hash = ?").bind(session.tokenHash).run();
  const p = cookiePolicy(env), secure = p.secure ? "; Secure" : "";
  return json(200, { authenticated: false }, { ...corsHeaders, "Set-Cookie": p.name + "=; Path=/; HttpOnly" + secure + "; SameSite=" + p.sameSite + "; Max-Age=0" });
}
async function handleMemory(req, env, corsHeaders, session) {
  const bucket = await rateLimit(env, "memory", session.userId, 60, 60 * 1000);
  if (bucket.limited) return json(429, { error: "rate_limited" }, { ...corsHeaders, "Retry-After": String(bucket.retryAfter) });
  if (req.method === "GET") {
    const row = await env.DB.prepare("SELECT payload_ciphertext, updated_at FROM user_data WHERE user_id = ?").bind(session.userId).first();
    if (!row) return json(200, { memory: "", notes: "", conversations: { cur: null, list: [] }, updatedAt: null }, corsHeaders);
    try {
      const data = await decryptMemory(env, row.payload_ciphertext);
      if (!data || typeof data.memory !== "string" || typeof data.notes !== "string" || !data.conversations || !Array.isArray(data.conversations.list)) throw new Error("memory_payload_invalid");
      return json(200, { memory: data.memory, notes: data.notes, conversations: data.conversations, updatedAt: row.updated_at }, corsHeaders);
    } catch (_) { return json(500, { error: "storage_error" }, corsHeaders); }
  }
  if (req.method === "PUT") {
    if (!String(req.headers.get("Content-Type") || "").toLowerCase().startsWith("application/json")) return json(415, { error: "content_type_required" }, corsHeaders);
    const read = await readLimited(req, MAX_MEMORY_BODY);
    if (read.tooLarge) return json(413, { error: "body_too_large" }, corsHeaders);
    if (read.invalidEncoding) return json(400, { error: "invalid_body" }, corsHeaders);
    const data = normalizeMemory(parseJSON(read.text));
    if (!data) return json(400, { error: "invalid_memory" }, corsHeaders);
    const now = Date.now();
    const payload = await encryptMemory(env, data);
    await env.DB.prepare("INSERT INTO user_data (user_id, payload_ciphertext, updated_at) VALUES (?, ?, ?) ON CONFLICT(user_id) DO UPDATE SET payload_ciphertext = excluded.payload_ciphertext, updated_at = excluded.updated_at").bind(session.userId, payload, now).run();
    return json(200, { saved: true, updatedAt: now }, corsHeaders);
  }
  if (req.method === "DELETE") {
    await env.DB.prepare("DELETE FROM user_data WHERE user_id = ?").bind(session.userId).run();
    return json(200, { deleted: true }, corsHeaders);
  }
  return json(405, { error: "method_not_allowed" }, corsHeaders);
}

// Provider functions return { text } or { status, error }; provider bodies/keys are never forwarded.
async function callGemini(env, body) {
  const model = body.tier === "deep" && env.GEMINI_MODEL_DEEP ? env.GEMINI_MODEL_DEEP : env.GEMINI_MODEL_FAST;
  if (typeof model !== "string" || !/^[A-Za-z0-9._-]+$/.test(model)) return { status: 500, error: "backend_not_configured" };
  const payload = { contents: body.messages.map(m => ({ role: m.role === "assistant" ? "model" : "user", parts: [{ text: m.content }] })), generationConfig: { maxOutputTokens: 2048 } };
  if (body.system) payload.systemInstruction = { parts: [{ text: body.system }] };
  let r;
  try { r = await fetch(GEMINI_BASE + model + ":generateContent", { method: "POST", headers: { "Content-Type": "application/json", "x-goog-api-key": env.GEMINI_API_KEY }, body: JSON.stringify(payload), signal: AbortSignal.timeout(TIMEOUT_MS) }); }
  catch (_) { return { status: 504, error: "provider_unreachable" }; }
  if (!r.ok) {
    let msg = ""; try { const j = await r.json(); msg = String(j && j.error && j.error.message || ""); } catch (_) {}
    if (r.status === 429) return { status: 429, error: "provider_rate_limited" };
    if (r.status === 401 || r.status === 403 || (r.status === 400 && /api key/i.test(msg))) return { status: 502, error: "provider_auth_failed" };
    if (r.status === 404) return { status: 502, error: "provider_model_not_found" };
    return { status: 502, error: "provider_error" };
  }
  let d; try { d = await r.json(); } catch (_) { return { status: 502, error: "provider_bad_response" }; }
  const cand = d && Array.isArray(d.candidates) ? d.candidates[0] : null;
  if (!cand) return { status: 502, error: d && d.promptFeedback && d.promptFeedback.blockReason ? "provider_blocked" : "provider_bad_response" };
  const parts = cand.content && Array.isArray(cand.content.parts) ? cand.content.parts : [];
  const text = parts.filter(p => p && typeof p.text === "string" && !p.thought).map(p => p.text).join("");
  if (!text.trim()) return { status: 502, error: cand.finishReason === "SAFETY" || cand.finishReason === "PROHIBITED_CONTENT" ? "provider_blocked" : "provider_bad_response" };
  return { text };
}
async function callOpenAICompat(env, body) {
  if (!env.PROVIDER_URL || !env.PROVIDER_KEY || !env.MODEL_FAST) return { status: 500, error: "backend_not_configured" };
  const model = body.tier === "deep" && env.MODEL_DEEP ? env.MODEL_DEEP : env.MODEL_FAST;
  const msgs = (body.system ? [{ role: "system", content: body.system }] : []).concat(body.messages.map(m => ({ role: m.role, content: m.content })));
  let r;
  try { r = await fetch(env.PROVIDER_URL, { method: "POST", headers: { "Content-Type": "application/json", "Authorization": "Bearer " + env.PROVIDER_KEY }, body: JSON.stringify({ model, messages: msgs, max_tokens: 800 }), signal: AbortSignal.timeout(TIMEOUT_MS) }); }
  catch (_) { return { status: 504, error: "provider_unreachable" }; }
  if (r.status === 429) return { status: 429, error: "provider_rate_limited" };
  if (r.status === 401 || r.status === 403) return { status: 502, error: "provider_auth_failed" };
  if (!r.ok) return { status: 502, error: "provider_error" };
  let data; try { data = await r.json(); } catch (_) { return { status: 502, error: "provider_bad_response" }; }
  const text = data && data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content;
  if (typeof text !== "string" || !text.trim()) return { status: 502, error: "provider_bad_response" };
  return { text };
}

// Simple mode is enabled ONLY by the exact value BLIZI_MODE=simple. A missing DB binding never downgrades secure mode.
function simpleMode(env) { return !!env && env.BLIZI_MODE === "simple"; }
const memBuckets = new Map();
function memoryLimit(key, limit, windowMs) {
  const now = Date.now();
  if (memBuckets.size > 1000) for (const [k, v] of memBuckets) if (now - v.start >= windowMs) memBuckets.delete(k);
  if (memBuckets.size > 5000) memBuckets.clear();
  let b = memBuckets.get(key);
  if (!b || now - b.start >= windowMs) { b = { start: now, count: 0 }; memBuckets.set(key, b); }
  b.count++;
  return { limited: b.count > limit, retryAfter: Math.max(1, Math.ceil((b.start + windowMs - now) / 1000)) };
}
async function handleChat(req, env, corsHeaders, session) {
  const bucket = session ? await rateLimit(env, "chat", session.userId, 30, 60 * 1000) : memoryLimit(clientIp(req), 20, 60 * 1000);
  if (bucket.limited) return json(429, { error: "rate_limited" }, { ...corsHeaders, "Retry-After": String(bucket.retryAfter) });
  if (req.method !== "POST") return json(405, { error: "method_not_allowed" }, corsHeaders);
  if (!String(req.headers.get("Content-Type") || "").toLowerCase().startsWith("application/json")) return json(415, { error: "content_type_required" }, corsHeaders);
  const read = await readLimited(req, MAX_CHAT_BODY);
  if (read.tooLarge) return json(413, { error: "body_too_large" }, corsHeaders);
  if (read.invalidEncoding) return json(400, { error: "invalid_body" }, corsHeaders);
  const body = parseJSON(read.text);
  if (body === null) return json(400, { error: "invalid_json" }, corsHeaders);
  const bad = validateChat(body);
  if (bad) return json(400, { error: bad }, corsHeaders);
  const out = env.GEMINI_API_KEY ? await callGemini(env, body) : await callOpenAICompat(env, body);
  if (out.error) return json(out.status, { error: out.error }, corsHeaders);
  return json(200, { text: out.text }, corsHeaders);
}

const MAX_TTS_BODY = 4000, MAX_TTS_CHARS = 500;
// Gemini text-to-speech. Format/model names come from the author's knowledge of the API and are UNVERIFIED against live docs.
async function callGeminiTTS(env, text) {
  const model = env.GEMINI_TTS_MODEL;
  if (!env.GEMINI_API_KEY || typeof model !== "string" || !/^[A-Za-z0-9._-]+$/.test(model)) return { status: 503, error: "tts_not_configured" };
  const gc = { responseModalities: ["AUDIO"] };
  if (/^[A-Za-z]{2,24}$/.test(env.GEMINI_TTS_VOICE || "")) gc.speechConfig = { voiceConfig: { prebuiltVoiceConfig: { voiceName: env.GEMINI_TTS_VOICE } } };
  let r;
  try {
    r = await fetch(GEMINI_BASE + model + ":generateContent", {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-goog-api-key": env.GEMINI_API_KEY },
      body: JSON.stringify({ contents: [{ parts: [{ text }] }], generationConfig: gc }),
      signal: AbortSignal.timeout(TIMEOUT_MS)
    });
  } catch (e) { return { status: 504, error: "provider_unreachable" }; }
  if (!r.ok) {
    let msg = "";
    try { const j = await r.json(); msg = String(j && j.error && j.error.message || ""); } catch (e) {}
    if (r.status === 429) return { status: 429, error: "provider_rate_limited" };
    if (r.status === 401 || r.status === 403 || (r.status === 400 && /api key/i.test(msg))) return { status: 502, error: "provider_auth_failed" };
    if (r.status === 404) return { status: 502, error: "provider_model_not_found" };
    return { status: 502, error: "provider_error" };
  }
  let d;
  try { d = await r.json(); } catch (e) { return { status: 502, error: "provider_bad_response" }; }
  const cand = d && Array.isArray(d.candidates) ? d.candidates[0] : null;
  const parts = cand && cand.content && Array.isArray(cand.content.parts) ? cand.content.parts : [];
  const p = parts.find(x => x && x.inlineData && typeof x.inlineData.data === "string");
  if (!p) return { status: 502, error: d && d.promptFeedback && d.promptFeedback.blockReason ? "provider_blocked" : "provider_bad_response" };
  const data = p.inlineData.data, rate = /rate=(\d{4,6})/.exec(String(p.inlineData.mimeType || ""));
  if (data.length < 8 || data.length > 6000000 || !/^[A-Za-z0-9+/]+={0,2}$/.test(data)) return { status: 502, error: "provider_bad_response" };
  return { audio: data, sampleRate: rate ? Number(rate[1]) : 24000 };
}

async function handleTTS(req, env, corsHeaders, session) {
  const bucket = session ? await rateLimit(env, "tts", session.userId, 10, 60 * 1000) : memoryLimit("tts:" + clientIp(req), 10, 60 * 1000);
  if (bucket.limited) return json(429, { error: "rate_limited" }, { ...corsHeaders, "Retry-After": String(bucket.retryAfter) });
  if (req.method !== "POST") return json(405, { error: "method_not_allowed" }, corsHeaders);
  if (!String(req.headers.get("Content-Type") || "").toLowerCase().startsWith("application/json")) return json(415, { error: "content_type_required" }, corsHeaders);
  const read = await readLimited(req, MAX_TTS_BODY);
  if (read.tooLarge) return json(413, { error: "body_too_large" }, corsHeaders);
  if (read.invalidEncoding) return json(400, { error: "invalid_body" }, corsHeaders);
  const body = parseJSON(read.text);
  if (body === null || typeof body !== "object" || typeof body.text !== "string" || !body.text.trim() || body.text.length > MAX_TTS_CHARS) return json(400, { error: "invalid_text" }, corsHeaders);
  const out = await callGeminiTTS(env, body.text.trim());
  if (out.error) return json(out.status, { error: out.error }, corsHeaders);
  return json(200, { audio: out.audio, sampleRate: out.sampleRate, format: "pcm16" }, corsHeaders);
}

export default {
  async fetch(req, env) {
    try {
      const url = new URL(req.url), origin = req.headers.get("Origin"), path = url.pathname;
      const ch = cors(origin, env);
      if (req.method === "OPTIONS") return ch ? new Response(null, { status: 204, headers: ch }) : json(403, { error: "origin_not_allowed" });
      if (origin && !ch) return json(403, { error: "origin_not_allowed" });
      // Reject unsafe browser requests without an explicitly permitted Origin. Origin is not auth.
      if (!["GET", "HEAD"].includes(req.method) && !ch) return json(403, { error: "origin_not_allowed" });
      if (!["/chat", "/tts", "/auth/login", "/auth/logout", "/auth/session", "/memory"].includes(path)) return json(404, { error: "not_found" }, ch || undefined);
      if (!configReady(env)) return json(503, { error: "backend_not_configured" }, ch || undefined);
      if (simpleMode(env)) {
        // Explicit opt-in simple mode: no D1, no sessions. Origin allowlist plus a best-effort in-memory limiter only.
        if (path === "/tts") return await handleTTS(req, env, ch || {}, null);
        if (path !== "/chat") return json(404, { error: "not_available_in_simple_mode" }, ch || undefined);
        return await handleChat(req, env, ch || {}, null);
      }
      if (path === "/auth/login") return await handleLogin(req, env, ch || {});
      if (path === "/auth/session") return await handleSession(req, env, ch || {});
      if (path === "/auth/logout") return await handleLogout(req, env, ch || {});
      const session = await authenticated(req, env);
      if (!session) return json(401, { error: "unauthorized" }, ch || undefined);
      if (path === "/memory") return await handleMemory(req, env, ch || {}, session);
      if (path === "/chat") return await handleChat(req, env, ch || {}, session);
      if (path === "/tts") return await handleTTS(req, env, ch || {}, session);
      return json(404, { error: "not_found" }, ch || undefined);
    } catch (_) {
      return json(503, { error: "service_unavailable" });
    }
  }
};
