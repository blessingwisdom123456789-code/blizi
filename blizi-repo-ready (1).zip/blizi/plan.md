# BLIZI AI — Manus-hosted v0.4.0 chat

## Approach and architecture

Reuse the existing public Manus WebDev project and the attached/extracted BLIZI v0.4.0 source. Preserve its phone-oriented visual design, chat experience, original illustration, PWA manifest/icons/service worker, and complete upstream source/tests. Keep the managed database disabled. Use Manus's already-approved Server capability for a same-origin `/chat` endpoint. A separate Node container adapter (`manus-server.mjs`) sends requests to the Manus built-in LLM runtime using credentials available only in the server environment; no provider key is included in client assets. Pin the supported low-cost model `gpt-6-luna` with low reasoning effort. Add an unauthenticated `/_app/health` endpoint for container readiness.

A plain-text file at `config/blizi-personality.txt` owns the editable character voice. The backend validates role/content shape, limits each user message to 500 characters, applies visitor and daily request caps, and returns only reply text and non-sensitive token usage. Limits are process-memory counters because the owner explicitly keeps the database off; their reset/replica boundaries will be disclosed.

Publication is hybrid: existing `frontend/` remains the static build output; `/chat` and `/_app/health` route to the container before the static catch-all. Keep the existing published project and public URL. No Cloudflare account resource is used or changed. Retain the original `server.mjs` and Cloudflare Worker source for source compatibility and historical completeness; the production image runs the separate Manus adapter.

## Project structure

- `frontend/`: original v0.4.0 mobile UI, character, manifest, icons, model, and service worker.
- `backend/worker.js`, `migrations/`, `tests/`, `docs/`: retained original source and tests for completeness; the Manus chat host is a separate adapter, not a rewrite of the Cloudflare Worker.
- `backend/manus-chat.mjs`: input validation, rate/daily caps, personality prompt, built-in LLM request.
- `manus-server.mjs`: Node host for the same-origin `/chat` and `/_app/health` routes; serves any locally previewed app shell without changing the original `server.mjs`.
- `config/blizi-personality.txt`: easy-to-edit system personality text, copied into the deployed image.
- `Dockerfile`, `package.json`: self-contained production image/start command; original tests and package scripts remain available.
- `plan.md`, `TODO.md`: current implementation decisions and outcomes.

## Design direction (reuse v0.4.0)

- **Design movement:** retain the supplied v0.4.0 anime-companion interface rather than redesigning it.
- **Core principles:** phone-first, friendly, legible, low-friction.
- **Color philosophy:** preserve the existing deep-night navy, electric cyan/blue, and restrained violet accents.
- **Layout paradigm:** keep the original single-screen character-led home and bottom navigation, with chat as a thumb-friendly full-height panel.
- **Signature elements:** original Blizi illustration; cyan-to-blue action gradient; compact rounded dark cards.
- **Interaction philosophy:** one-tap chat, short message limit stated clearly, visible Clear control, clear loading/error states.
- **Animation:** preserve existing modest character motion; respect reduced-motion preference; do not auto-enable the experimental 3D viewer.
- **Typography:** preserve the original system sans-serif hierarchy and large mobile-readable controls.
- **Brand essence:** a friendly AI companion for brief, supportive everyday conversation; warm, curious, encouraging.
- **Brand voice:** short, plain-language replies with one mood tag for the existing UI (e.g. `[happy] Hey, I’m glad you’re here.` and `[thinking] Let’s take it one small step at a time.`).
- **Wordmark/logo:** retain the original BLIZI AI wordmark and archive icon.
- **Signature brand color:** preserve the existing electric cyan.

## Core State v1 — Context Assembly integration plan (Phase A active; domain schema deferred)

### Current integration boundary

The current app is a static vanilla-JavaScript PWA. `frontend/index.html` owns the local chat and currently persists conversations in `blizi.convs`, user settings (including the free-text `S.memory`) in `blizi.settings`, and separate notes in `blizi.notes`. Its `instr()` function injects persona, user name, the saved-memory string, current time, and behavior constraints into each request. `turns()` supplies recent user/AI turns. `AI.complete(...)` is the existing provider boundary and must remain the only model-call path. The Manus host serves `POST /chat` and `/_app/health`; it has no Core State database or `/memory` implementation, and the managed database remains off.

No `frontend/core/` modules, `S.core` flag, or standalone `BliziIdleMotion` module currently exist. The app does have `BliziExpressionMap`, `AvatarController`, and the renderer-independent `BlinkScheduler`; Core State must call only the existing public avatar API. Any future idle-engine connection is a separate phase and must not modify these APIs during Core State work.

### Context Assembly flow

When enabled, Core State receives the current user turn and current conversation/project focus, then asynchronously reads local records for the single active profile (`prof_main`). Identity, current mood, and relationship preferences form small baseline blocks. Candidate episodic memories, semantic facts, project-ledger records, and journal proposals are fetched only from relevant indexes and only when applicable to the current query or active focus; raw transcripts are not searched wholesale. `RuleSummarizer` remains the default; no model is called from Core State, and model-backed summarization stays opt-in because it sends conversation text to `AI.complete`.

Ranking is deterministic and occurs only after profile, status, sensitivity, and correction filters. Corrections/retractions and conflict status are resolved before ranking. Remaining candidates use the schema-defined importance/strength/decay and provenance fields, plus query/topic relevance and project-focus relevance; pinned records may receive the schema-defined priority. The exact coefficient formula and tie-break fields must come from `BLIZI-Core-State-Schema-v1.md`, not be invented in this plan. Results are deduplicated by canonical record identity and assembled in stable domain order: identity, mood, relationship, corrected/explicit semantic facts, relevant project state, relevant episodes, then lower-confidence journal proposals. The assembler must keep the total browser-supplied system context within the stricter current Manus adapter limit of 2,000 characters (and therefore also below the handoff's 3,000-character ceiling) unless that limit is deliberately reviewed separately.

The prompt bridge preserves the existing behavior behind `S.core`: `off` keeps the current `instr()` bytes and behavior unchanged; `shadow` assembles but does not send Core context; `on` sends the bounded assembled context through the unchanged `AI.complete(...)` boundary and falls back to the old prompt if Core State fails. Shadow diagnostics should report record IDs/counts and character totals, not raw memory text, to avoid leaking personal context into browser console logs. Mood labels are validated by `BliziExpressionMap` and passed through `AvatarController`; Core State itself never manipulates SVG, Three.js, VRM, blink, or idle internals.

### Conflict and correction policy

Use the schema's correction/supersession/retraction relationships before candidate ranking. A corrected active value must win over the superseded value; retracted or disputed values must not be asserted as settled facts. A stated preference outranks an inferred one. If the schema reports an unresolved conflict, the context should expose the ambiguity as such or omit it and ask the user, rather than choose a winner by recency alone. Journal lessons remain proposals and are not promoted to facts or identity. Deletion must remove content from the record and any schema-defined transcript/index copies while preserving only the permitted content-free audit entry. Exact record fields and atomicity rules remain subject to the missing fixed schema.

### Storage and legacy secure-memory decision

Use the handoff's local IndexedDB `blizi-core` adapter and schema-defined object stores as the single active Core State source of truth; keep a Map-backed adapter for deterministic Node tests. Inject `profileId: "prof_main"` in the storage layer and validate it on every read/write while retaining profile fields for future compatibility. Sensitive-memory fields may exist in the schema, but v1 must reject sensitive-record writes and provide no sensitive collection flow. Do not add a D1 migration or dual-write path.

The old localStorage keys are migration inputs and must remain intact until an idempotent import succeeds and the user can export/verify the Core bundle. The Stage 2 secure-memory implementation is an encrypted aggregate blob (`user_data`) exposed by `backend/worker.js`; its own documentation says it was mock-tested and not deployed. The current Manus container does not expose `/memory`, and the Worker simple mode rejects it. Recommendation: treat an authenticated, user-exported legacy JSON backup as a one-time import source if one exists; do not keep the old Worker/D1 payload as an active backup or dual-write target. After the import path is verified, mark the old cloud-memory UI/API as deprecated for this release. No Cloudflare account or D1 resource is to be accessed or changed as part of this plan.

### First coding milestone — Phase A foundation (authorized now)

Implement only schema-neutral foundations now: `core-schema.js` (store registry and generic guards, not domain validators), `core-store.js` (memory, IndexedDB, and bounded localStorage adapters), `core-events.js` (atomic metadata event foundation), `core-seed.js` (identity seed manifest and legacy-setting map, not a finalized Identity record), `core-migrations.js` (idempotent raw legacy snapshot), and `core-state.js` (open/export/import/snapshot/status foundation). Add `S.core = "off"` as the default and initialize the local copy in the background without awaiting it in chat. Keep the existing `instr()` path byte-for-byte unchanged when off. Wire only the local browser modules and static asset/cache/test routes; do not add an AI, D1, or Cloudflare API. Preserve all old localStorage keys. Do not implement mood, relationship, episodic/semantic memory, projects, journal, evolution, or final field-level validators until the canonical schema arrives.

### Deferred schema-dependent work

The required `BLIZI-Core-State-Schema-v1.md` (or `.docx`) is not present in accessible project/upload storage. The two supplied `pasted_content*.txt` files are each exactly 20,000 bytes and stop partway through section 4.6 (semantic memory); they do not include the complete data models, Context Assembly section, ranking weights, or the remaining handoff. The user authorizes Phase A infrastructure without those documents, but domain record shapes, Context Assembly ranking rules, and field-level validators remain deferred until the canonical schema and complete handoff are available.
