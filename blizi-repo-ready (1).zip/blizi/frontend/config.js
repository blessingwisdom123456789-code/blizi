/* Build-time settings. NEVER put API keys here: provider keys live only in the backend's secrets.
   backendUrl: full chat endpoint of your deployed backend, e.g. "https://blizi-ai-backend.<you>.workers.dev/chat".
   Leave empty to use the in-app Settings > Backend URL instead. */
window.BLIZI_CONFIG = { backendUrl: "", maxToolResultChars: 1500, maxSystemChars: 3000 };
