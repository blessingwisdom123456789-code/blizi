(function (root) {
  "use strict";

  function create(svg, options) {
    if (!svg) throw new Error("SvgRenderer requires the #blizi element");
    var opts = options || {};
    var expressions = root.BliziExpressionMap;
    var expression = expressions
      ? expressions.normalize((svg.dataset && svg.dataset.expr) || "happy")
      : ((svg.dataset && svg.dataset.expr) || "happy");
    var idleState = "idle";
    var blinkTimer = null;
    var glanceTimer = null;
    var destroyed = false;

    function schedule(fn, delay) {
      if (typeof opts.setTimeout === "function") return opts.setTimeout(fn, delay);
      if (root && typeof root.setTimeout === "function") return root.setTimeout(fn, delay);
      return setTimeout(fn, delay);
    }

    function cancel(timer) {
      if (timer === null || timer === undefined) return;
      if (typeof opts.clearTimeout === "function") opts.clearTimeout(timer);
      else if (root && typeof root.clearTimeout === "function") root.clearTimeout(timer);
      else clearTimeout(timer);
    }

    function normalize(name) {
      return expressions ? expressions.normalize(name) : (typeof name === "string" && name ? name : "neutral");
    }

    function supportsExpression(name) {
      return expressions ? expressions.isSupported(name) : name === "happy" || name === "neutral" || name === "speaking";
    }

    function setExpression(name) {
      expression = normalize(name);
      if (svg.dataset) svg.dataset.expr = expression;
      return expression;
    }

    function setSpeaking(active) {
      if (svg.classList) svg.classList.toggle("speaking", !!active);
      return expression;
    }

    function setMouthLevel(value) {
      if (value === null || value === undefined) {
        svg.classList.remove("audio");
        svg.style.removeProperty("--mouth");
        return null;
      }
      if (typeof value !== "number" || !isFinite(value)) return null;
      var level = Math.max(0, Math.min(1, value));
      svg.classList.add("audio");
      svg.style.setProperty("--mouth", level.toFixed(2));
      return level;
    }

    function triggerBlink(durationMs) {
      if (destroyed || idleState !== "idle") return false;
      cancel(blinkTimer);
      svg.classList.add("blink");
      var duration = typeof durationMs === "number" && isFinite(durationMs)
        ? Math.max(80, Math.min(600, Math.round(durationMs)))
        : 130;
      blinkTimer = schedule(function () {
        svg.classList.remove("blink");
        blinkTimer = null;
      }, duration);
      return true;
    }

    function setIdleState(state) {
      var enabled = state === true || state === "idle";
      idleState = enabled ? "idle" : "paused";
      return idleState;
    }

    function glanceLoop() {
      if (destroyed) return;
      glanceTimer = schedule(function () {
        glanceTimer = null;
        if (destroyed) return;
        if (idleState === "idle") {
          svg.style.setProperty("--gx", (Math.random() * 4 - 2).toFixed(1) + "px");
          svg.style.setProperty("--gy", (Math.random() * 3 - 1.5).toFixed(1) + "px");
        } else {
          svg.style.setProperty("--gx", "0px");
          svg.style.setProperty("--gy", "0px");
        }
        glanceLoop();
      }, 3000 + Math.random() * 3000);
    }

    function destroy() {
      destroyed = true;
      cancel(blinkTimer); blinkTimer = null;
      cancel(glanceTimer); glanceTimer = null;
      svg.classList.remove("blink");
      return true;
    }

    if (opts.autoStart !== false) {
      glanceLoop();
    }

    return {
      setExpression: setExpression,
      setSpeaking: setSpeaking,
      setMouthLevel: setMouthLevel,
      triggerBlink: triggerBlink,
      setIdleState: setIdleState,
      destroy: destroy,
      supportsExpression: supportsExpression,
      supportedExpressions: expressions ? expressions.supportedNames.slice() : ["neutral", "happy", "speaking"],
      getExpression: function () { return expression; }
    };
  }

  root.BliziSvgRenderer = { create: create };
})(typeof window !== "undefined" ? window : globalThis);
