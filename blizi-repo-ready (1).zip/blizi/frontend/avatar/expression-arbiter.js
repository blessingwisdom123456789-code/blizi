(function (root) {
  "use strict";

  var DEFAULT_PRIORITY = { "user-command": 4, "reply-tag": 3, interaction: 2, mood: 1 };
  var DEFAULT_HOLD = { "user-command": 8000, "reply-tag": 5000, interaction: 1200, mood: 0 };

  function create(options) {
    options = options || {};
    var avatar = options.avatar, map = root.BliziExpressionMap, now = options.now || Date.now;
    var setTimer = options.setTimeout || (root.setTimeout ? root.setTimeout.bind(root) : setTimeout);
    var clearTimer = options.clearTimeout || (root.clearTimeout ? root.clearTimeout.bind(root) : clearTimeout);
    var layers = Object.create(null), timer = null, current = avatar && avatar.getExpression ? avatar.getExpression() : "neutral", currentSource = "initial", listeners = [];
    var priorities = Object.assign({}, DEFAULT_PRIORITY, options.priorities || {}), holds = Object.assign({}, DEFAULT_HOLD, options.holds || {});
    var debug = options.debug === true;
    function trace(event) { if (!debug) return; try { if (root.console && typeof root.console.debug === "function") root.console.debug("[BLIZI face]", event); } catch (_) {} }

    function emit(reason) {
      var event = { expression: current, source: currentSource, reason: reason || "changed" };
      trace(event);
      listeners.slice().forEach(function (fn) { try { fn(event); } catch (_) {} });
      return event;
    }
    function valid(name) { return map && typeof map.isSupported === "function" && map.isSupported(name); }
    function active(entry, at) { return entry && (!entry.expiresAt || entry.expiresAt > at); }
    function winner(at) {
      var best = null;
      Object.keys(layers).forEach(function (source) {
        var entry = layers[source];
        if (!active(entry, at)) { delete layers[source]; return; }
        if (!best || entry.priority > best.priority || (entry.priority === best.priority && entry.updatedAt > best.updatedAt)) best = entry;
      });
      return best;
    }
    function schedule() {
      if (timer !== null) { clearTimer(timer); timer = null; }
      var soon = null, at = Number(now());
      Object.keys(layers).forEach(function (source) { var e = layers[source]; if (e && e.expiresAt && e.expiresAt > at && (soon === null || e.expiresAt < soon)) soon = e.expiresAt; });
      if (soon !== null) timer = setTimer(function () { timer = null; apply("expired"); }, Math.max(0, soon - at));
    }
    function apply(reason) {
      var entry = winner(Number(now())), next = entry ? entry.expr : "neutral", source = entry ? entry.source : "default";
      if (!valid(next)) next = "neutral";
      if (avatar && typeof avatar.supportsExpression === "function" && !avatar.supportsExpression(next)) {
        if (entry) { delete layers[entry.source]; schedule(); }
        var rejected = { ok: false, reason: "unsupported_renderer", expression: next, source: source };
        trace(rejected); return rejected;
      }
      var applied = avatar && typeof avatar.setExpression === "function" ? avatar.setExpression(next) : next;
      if (applied !== next) {
        if (entry) delete layers[entry.source];
        schedule();
        var failed = { ok: false, reason: "unsupported_renderer", expression: next, source: source, applied: applied };
        trace(failed); return failed;
      }
      var changed = current !== next || currentSource !== source;
      current = next; currentSource = source;
      schedule();
      if (changed) emit(reason || "changed");
      var result = { ok: true, expression: current, source: currentSource, changed: changed };
      trace(result); return result;
    }
    function request(input) {
      input = input || {};
      var source = String(input.source || "reply-tag");
      var requested = typeof input.expr === "string" ? input.expr.toLowerCase().trim() : "";
      if (!valid(requested)) { var rejected = { ok: false, reason: "unknown_expression", expression: requested || null, source: source }; trace(rejected); return rejected; }
      var at = Number(now()), hold = input.holdMs === undefined ? (holds[source] || 0) : Math.max(0, Number(input.holdMs) || 0);
      layers[source] = { source: source, expr: map.normalize(requested), priority: Number(input.priority === undefined ? (priorities[source] || 0) : input.priority), updatedAt: at, expiresAt: hold ? at + hold : 0 };
      var result = apply("request");
      if (!result.ok) return result;
      result.heldMs = hold;
      return result;
    }
    // Re-arm an ACTIVE layer's expiry (used to hold an emotion while she is speaking, then let it linger briefly).
    function extend(source, holdMs) {
      var at = Number(now()), entry = layers[source];
      if (!active(entry, at)) return { ok: false, reason: "no_active_layer", source: source };
      var ms = Math.max(0, Number(holdMs) || 0);
      entry.expiresAt = ms ? at + ms : 0;
      schedule();
      return { ok: true, source: source, heldMs: ms };
    }
    function clear(source) { if (source) delete layers[source]; else Object.keys(layers).forEach(function (key) { delete layers[key]; }); return apply("cleared"); }
    function onChange(fn) { if (typeof fn !== "function") return function () {}; listeners.push(fn); return function () { listeners = listeners.filter(function (item) { return item !== fn; }); }; }
    function getState() { var entry = winner(Number(now())); return { expression: current, source: currentSource, active: entry ? { source: entry.source, expression: entry.expr, expiresAt: entry.expiresAt || null } : null }; }
    function explain() {
      var at = Number(now()), state = getState(), entries = [];
      Object.keys(layers).forEach(function (source) { var e = layers[source]; if (active(e, at)) entries.push({ source: source, expression: e.expr, priority: e.priority, updatedAt: e.updatedAt, expiresAt: e.expiresAt || null, active: true }); });
      entries.sort(function (a, b) { return b.priority - a.priority || b.updatedAt - a.updatedAt; });
      return { current: state.expression, winner: state.source, layers: entries, debug: debug };
    }
    return { request: request, extend: extend, clear: clear, apply: apply, onChange: onChange, getState: getState, explain: explain, current: function () { return current; } };
  }

  root.BliziExpressionArbiter = { create: create, priorities: Object.freeze(Object.assign({}, DEFAULT_PRIORITY)) };
})(typeof window !== "undefined" ? window : globalThis);
