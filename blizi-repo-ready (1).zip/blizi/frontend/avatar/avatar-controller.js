(function (root) {
  "use strict";

  function AvatarController(options) {
    var opts = options || {};
    var renderer = opts.renderer || opts.svgRenderer || root.BliziSvgRenderer.create(opts.svg, opts.svgOptions);
    var body3d = opts.body3d || null;
    var expressions = root.BliziExpressionMap;
    var initial = renderer.getExpression ? renderer.getExpression() : "happy";
    var expression = expressions ? expressions.normalize(initial) : initial;
    var blinkScheduler = null;
    var destroyed = false;

    function supports(name) {
      try {
        if (typeof renderer.supportsExpression === "function") return renderer.supportsExpression(name) !== false;
        if (Array.isArray(renderer.supportedExpressions)) return renderer.supportedExpressions.indexOf(name) !== -1;
      } catch (_) {}
      return true;
    }

    function fallbackExpression() {
      var configured = typeof renderer.fallbackExpression === "string" ? renderer.fallbackExpression : "";
      var candidates = [configured, "neutral", "happy"];
      if (Array.isArray(renderer.supportedExpressions)) candidates = candidates.concat(renderer.supportedExpressions);
      for (var i = 0; i < candidates.length; i++) {
        var candidate = candidates[i];
        if (!candidate) continue;
        candidate = expressions ? expressions.normalize(candidate) : candidate;
        if (supports(candidate)) return candidate;
      }
      return "neutral";
    }

    function resolve(name) {
      var candidate = expressions ? expressions.normalize(name) : (typeof name === "string" && name ? name : "neutral");
      return supports(candidate) ? candidate : fallbackExpression();
    }

    function updateBodyExpression(name) {
      if (body3d && typeof body3d.state === "function") body3d.state(name);
    }

    function commitExpression(name, rendererAlreadyChanged) {
      var next = resolve(name);
      if (typeof renderer.setExpression === "function" && !rendererAlreadyChanged) {
        var result;
        try { result = renderer.setExpression(next); } catch (_) { result = false; }
        if (result === false) {
          next = fallbackExpression();
          try { renderer.setExpression(next); } catch (_) {}
        } else if (typeof result === "string") {
          var reported = resolve(result);
          if (reported !== result || !supports(result)) {
            next = fallbackExpression();
            try { renderer.setExpression(next); } catch (_) {}
          } else next = reported;
        }
      }
      expression = next;
      if (blinkScheduler) blinkScheduler.setExpression(expression);
      updateBodyExpression(expression);
      return expression;
    }

    function setExpression(name) {
      return commitExpression(name, false);
    }

    function setSpeaking(active) {
      var base = expression, result = true;
      if (typeof renderer.setSpeaking === "function") {
        try { result = renderer.setSpeaking(!!active); } catch (_) { result = false; }
      }
      if (body3d && typeof body3d.talk === "function") {
        try { body3d.talk(!!active); } catch (_) {}
        if (typeof body3d.state === "function") body3d.state(base);
      } else if (body3d && typeof body3d.state === "function") body3d.state(active ? "speaking" : base);
      if (result === false && typeof renderer.setSpeaking !== "function") return base;
      return base;
    }

    function setMouthLevel(value) {
      var level = typeof renderer.setMouthLevel === "function" ? renderer.setMouthLevel(value) : null;
      if (body3d && typeof body3d.mouth === "function") {
        body3d.mouth(value === null || value === undefined ? null : level);
      }
      return level;
    }

    function triggerBlink(durationMs) {
      var info = null;
      try { if (body3d && typeof body3d.info === "function") info = body3d.info(); } catch (_) {}
      if (info && info.active && info.ready) {
        if (info.kind !== "vrm" || typeof body3d.triggerBlink !== "function") return false;
        try { return body3d.triggerBlink(durationMs) === true; } catch (_) { return false; }
      }
      var started = false;
      try { started = typeof renderer.triggerBlink === "function" && renderer.triggerBlink(durationMs) === true; }
      catch (_) {}
      if (body3d && typeof body3d.triggerBlink === "function") {
        try { started = body3d.triggerBlink(durationMs) === true || started; } catch (_) {}
      }
      return started;
    }

    function setIdleState(state) {
      var result = typeof renderer.setIdleState === "function"
        ? renderer.setIdleState(state)
        : (state === true || state === "idle" ? "idle" : "paused");
      if (blinkScheduler) blinkScheduler.setIdleState(state);
      if (body3d && typeof body3d.setIdleState === "function") {
        try { body3d.setIdleState(state); } catch (_) {}
      }
      return result;
    }

    function destroy() {
      if (destroyed) return false;
      destroyed = true;
      if (blinkScheduler) { try { blinkScheduler.destroy(); } catch (_) {} blinkScheduler = null; }
      try { if (typeof renderer.destroy === "function") renderer.destroy(); } catch (_) {}
      return true;
    }

    // Scheduler is optional: if the script is missing or throws, the avatar still works (it just stops auto-blinking).
    if (root.BliziBlinkScheduler && typeof root.BliziBlinkScheduler.create === "function") {
      try {
        blinkScheduler = root.BliziBlinkScheduler.create({
          expression: expression,
          config: opts.blinkConfig,
          random: opts.blinkRandom,
          setTimeout: opts.blinkSetTimeout,
          clearTimeout: opts.blinkClearTimeout,
          now: opts.blinkNow,
          onBlink: function (durationMs) { return destroyed ? false : triggerBlink(durationMs); }
        });
      } catch (_) { blinkScheduler = null; }
    }

    return {
      setExpression: setExpression,
      supportsExpression: supports,
      setSpeaking: setSpeaking,
      setMouthLevel: setMouthLevel,
      triggerBlink: triggerBlink,
      setIdleState: setIdleState,
      destroy: destroy,
      getExpression: function () { return expression; }
    };
  }

  root.AvatarController = AvatarController;
})(typeof window !== "undefined" ? window : globalThis);
