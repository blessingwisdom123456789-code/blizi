(function (root) {
  "use strict";

  var CANONICAL = [
    "neutral", "happy", "excited", "embarrassed", "confused",
    "sad", "angry", "thinking", "sleepy", "speaking"
  ];

  // Keep the old names supported for saved settings, mood tags and existing callers.
  var DEFINITIONS = {
    neutral:     { label: "Feeling neutral",     vrm: {} },
    happy:       { label: "Feeling happy",       vrm: { joy: 0.8 } },
    excited:     { label: "Feeling excited",     vrm: { joy: 1, fun: 0.35, a: 0.12 } },
    embarrassed:{ label: "Feeling embarrassed", vrm: { fun: 0.25, joy: 0.12 } },
    confused:    { label: "Feeling confused",    vrm: { fun: 0.12 } },
    sad:         { label: "Feeling sad",         vrm: { sorrow: 0.7 } },
    angry:       { label: "Feeling angry",       vrm: { angry: 0.7 } },
    thinking:    { label: "Thinking",            vrm: { fun: 0.3 } },
    sleepy:      { label: "Feeling sleepy",      vrm: { blink: 0.58 } },
    speaking:    { label: "Speaking",            vrm: { joy: 0.2, a: 0.05 } },
    surprised:   { label: "Feeling surprised",   vrm: { a: 0.5 } },
    serious:     { label: "Feeling serious",     vrm: { angry: 0.35 } },
    listening:   { label: "Listening",           vrm: { fun: 0.25 } }
  };

  var SUPPORTED = Object.keys(DEFINITIONS);

  function isSupported(name) {
    return typeof name === "string" && Object.prototype.hasOwnProperty.call(DEFINITIONS, name.toLowerCase().trim());
  }

  function normalize(name) {
    if (typeof name !== "string") return "neutral";
    var key = name.toLowerCase().trim();
    return Object.prototype.hasOwnProperty.call(DEFINITIONS, key) ? key : "neutral";
  }

  function copyWeights(weights) {
    var copy = {};
    Object.keys(weights || {}).forEach(function (key) { copy[key] = weights[key]; });
    return copy;
  }

  function get(name) {
    var key = normalize(name), def = DEFINITIONS[key];
    return { name: key, label: def.label, vrm: copyWeights(def.vrm) };
  }

  var labels = {};
  SUPPORTED.forEach(function (name) { labels[name] = DEFINITIONS[name].label; });

  root.BliziExpressionMap = Object.freeze({
    canonicalNames: Object.freeze(CANONICAL.slice()),
    supportedNames: Object.freeze(SUPPORTED.slice()),
    labels: Object.freeze(labels),
    isSupported: isSupported,
    normalize: normalize,
    get: get,
    toVrm: function (name) { return copyWeights(DEFINITIONS[normalize(name)].vrm); }
  });
})(typeof window !== "undefined" ? window : globalThis);
