(function (root) {
  "use strict";

  // Edit these values to tune blink cadence and duration without changing scheduler logic.
  root.BliziBlinkConfig = Object.freeze({
    baseMinIntervalMs: 2000,
    baseMaxIntervalMs: 6000,
    thinkingIntervalMultiplier: 1.08,
    sleepyIntervalMultiplier: 0.62,
    speakingIntervalMultiplier: 1.25,
    baseDurationMs: 130,
    thinkingDurationMultiplier: 1.35,
    doubleBlinkChance: 0.14,
    doubleBlinkDelayMinMs: 230,
    doubleBlinkDelayMaxMs: 360
  });
})(typeof window !== "undefined" ? window : globalThis);
