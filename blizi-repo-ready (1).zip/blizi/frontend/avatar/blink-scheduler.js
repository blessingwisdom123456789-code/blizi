(function (root) {
  "use strict";

  var BUILT_IN_DEFAULTS = {
    baseMinIntervalMs: 2000,
    baseMaxIntervalMs: 6000,
    thinkingIntervalMultiplier: 1.08,
    sleepyIntervalMultiplier: 0.62,
    speakingIntervalMultiplier: 1.25,
    baseDurationMs: 130,
    thinkingDurationMultiplier: 1.35,
    doubleBlinkChance: 0.14,
    doubleBlinkDelayMinMs: 230,
    doubleBlinkDelayMaxMs: 360
  };
  var DEFAULTS = Object.freeze(Object.assign({}, BUILT_IN_DEFAULTS, root.BliziBlinkConfig || {}));

  function create(options) {
    var opts = options || {};
    var config = {};
    Object.keys(DEFAULTS).forEach(function (key) {
      var value = opts.config && Number(opts.config[key]);
      config[key] = isFinite(value) ? value : DEFAULTS[key];
    });

    config.baseMinIntervalMs = Math.max(1, config.baseMinIntervalMs);
    config.baseMaxIntervalMs = Math.max(config.baseMinIntervalMs, config.baseMaxIntervalMs);
    config.thinkingIntervalMultiplier = Math.max(0.1, config.thinkingIntervalMultiplier);
    config.sleepyIntervalMultiplier = Math.max(0.1, config.sleepyIntervalMultiplier);
    config.speakingIntervalMultiplier = Math.max(1, config.speakingIntervalMultiplier);
    config.baseDurationMs = Math.max(1, config.baseDurationMs);
    config.thinkingDurationMultiplier = Math.max(1, config.thinkingDurationMultiplier);
    config.doubleBlinkChance = Math.max(0, Math.min(1, config.doubleBlinkChance));
    config.doubleBlinkDelayMinMs = Math.max(1, config.doubleBlinkDelayMinMs);
    config.doubleBlinkDelayMaxMs = Math.max(config.doubleBlinkDelayMinMs, config.doubleBlinkDelayMaxMs);

    var map = root.BliziExpressionMap;
    var expression = normalize(opts.expression || "happy");
    var callback = typeof opts.onBlink === "function" ? opts.onBlink : function () { return false; };
    var random = typeof opts.random === "function" ? opts.random : Math.random;
    var setTimer = typeof opts.setTimeout === "function"
      ? opts.setTimeout
      : function (fn, delay) { return root.setTimeout(fn, delay); };
    var clearTimer = typeof opts.clearTimeout === "function"
      ? opts.clearTimeout
      : function (id) { return root.clearTimeout(id); };
    var now = typeof opts.now === "function" ? opts.now : function () { return Date.now(); };
    var timer = null;
    var running = false;
    var destroyed = false;
    var phase = "stopped";
    var dueAt = 0;
    var scheduledMultiplier = 1;

    function normalize(name) {
      if (map) return map.normalize(name);
      return typeof name === "string" && name ? name.toLowerCase().trim() : "neutral";
    }

    function randomValue() {
      var value = Number(random());
      if (!isFinite(value)) return 0;
      return Math.max(0, Math.min(0.999999999, value));
    }

    function intervalMultiplier(name) {
      if (name === "sleepy") return config.sleepyIntervalMultiplier;
      if (name === "speaking") return config.speakingIntervalMultiplier;
      if (name === "thinking") return config.thinkingIntervalMultiplier;
      return 1;
    }

    function getIntervalRange(name) {
      var multiplier = intervalMultiplier(normalize(name === undefined ? expression : name));
      return {
        min: Math.round(config.baseMinIntervalMs * multiplier),
        max: Math.round(config.baseMaxIntervalMs * multiplier)
      };
    }

    function getNextInterval(name) {
      var range = getIntervalRange(name);
      if (range.max <= range.min) return range.min;
      return Math.floor(range.min + randomValue() * (range.max - range.min));
    }

    function getBlinkDuration(name) {
      var target = normalize(name === undefined ? expression : name);
      return Math.round(config.baseDurationMs * (target === "thinking" ? config.thinkingDurationMultiplier : 1));
    }

    function getDoubleBlinkDelay() {
      var range = { min: config.doubleBlinkDelayMinMs, max: config.doubleBlinkDelayMaxMs };
      if (range.max <= range.min) return range.min;
      return Math.floor(range.min + randomValue() * (range.max - range.min));
    }

    function clearPending() {
      if (timer !== null && timer !== undefined) clearTimer(timer);
      timer = null;
    }

    function blink() {
      try { return callback(getBlinkDuration()); } catch (_) { return false; }
    }

    // Single choke point for timers: never leaves a stale id behind and never throws into the caller.
    function arm(delay, nextPhase, fn) {
      if (!running || destroyed || timer !== null) return false;
      try {
        timer = setTimer(function () {
          timer = null;
          if (!running || destroyed) return;
          fn();
        }, delay);
      } catch (_) {
        timer = null;
        running = false;
        phase = "stopped";
        return false;
      }
      phase = nextPhase;
      dueAt = now() + delay;
      scheduledMultiplier = intervalMultiplier(expression);
      return true;
    }

    function scheduleInterval(delay) {
      return arm(delay === undefined ? getNextInterval() : delay, "interval", function () {
        blink();
        if (randomValue() < config.doubleBlinkChance) scheduleDoubleBlink();
        else scheduleInterval();
      });
    }

    function scheduleDoubleBlink() {
      return arm(getDoubleBlinkDelay(), "double-blink", function () {
        blink();
        scheduleInterval();
      });
    }

    function start() {
      if (running || destroyed) return false;
      running = true;
      return scheduleInterval() || running;
    }

    function stop() {
      var wasRunning = running || timer !== null;
      running = false;
      clearPending();
      phase = "stopped";
      return wasRunning;
    }

    // Permanent teardown: after this the instance can never create another timer.
    function destroy() {
      var had = stop();
      destroyed = true;
      callback = function () { return false; };
      return had;
    }

    function setIdleState(state) {
      var idle = state === true || state === "idle";
      if (idle) start();
      else stop();
      return idle ? "idle" : "paused";
    }

    function setExpression(name) {
      var next = normalize(name);
      if (next === expression) return expression;
      expression = next;
      if (running && phase === "interval" && timer !== null) {
        var factor = intervalMultiplier(expression) / scheduledMultiplier;
        if (factor !== 1) {
          // Keep the elapsed time: rescale what is left instead of restarting the wait,
          // so rapid expression changes (e.g. speech start/stop) can never starve blinking.
          var remaining = Math.max(0, dueAt - now());
          clearPending();
          scheduleInterval(Math.round(remaining * factor));
        }
      }
      return expression;
    }

    if (opts.autoStart !== false) start();

    return {
      start: start,
      stop: stop,
      destroy: destroy,
      setIdleState: setIdleState,
      setExpression: setExpression,
      getIntervalRange: getIntervalRange,
      getNextInterval: getNextInterval,
      getBlinkDuration: getBlinkDuration,
      getDoubleBlinkDelay: getDoubleBlinkDelay,
      getConfig: function () {
        var copy = {};
        Object.keys(config).forEach(function (key) { copy[key] = config[key]; });
        return copy;
      },
      getState: function () { return { running: running, destroyed: destroyed, expression: expression, phase: phase, timerPending: timer !== null }; }
    };
  }

  root.BliziBlinkScheduler = { create: create, defaults: DEFAULTS };
})(typeof window !== "undefined" ? window : globalThis);
