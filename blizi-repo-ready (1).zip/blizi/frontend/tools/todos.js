(function (root) {
  "use strict";

  /* BLIZI todos: a tiny clock-injected list. Storage is injected so tests and Core State can both back it. */

  var MAX = 200;
  function create(store) {
    var seq = 0;
    function load() { var a = store.get(); return Array.isArray(a) ? a : []; }
    return {
      add: function (text, now) {
        var t = String(text == null ? "" : text).replace(/[\u0000-\u001f]/g, " ").replace(/\s+/g, " ").trim().slice(0, 140);
        if (!t) return null;
        var a = load();
        if (a.filter(function (x) { return !x.done; }).length >= MAX) return null;
        var item = { id: "td_" + (now || 0).toString(36) + "_" + (seq++), text: t, done: false, created: now || 0 };
        a.push(item); store.set(a); return item;
      },
      list: function (all) { return load().filter(function (x) { return all || !x.done; }); },
      done: function (id) { var a = load(), hit = false; a.forEach(function (x) { if (x.id === id && !x.done) { x.done = true; hit = true; } }); if (hit) store.set(a); return hit; },
      remove: function (id) { var a = load(), n = a.length; a = a.filter(function (x) { return x.id !== id; }); store.set(a); return a.length < n; }
    };
  }
  root.BliziTodos = { create: create, MAX: MAX };
})(typeof window !== "undefined" ? window : this);
