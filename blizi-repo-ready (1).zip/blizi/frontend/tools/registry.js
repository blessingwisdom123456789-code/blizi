(function (root) {
  "use strict";

  /*
   * BLIZI tool registry (the "actions" layer, inspired by Jarvis' tool service).
   *
   * The AI never runs anything directly. It may only *request* a tool by name with JSON arguments.
   * The registry validates the request strictly (known tool, known keys, right types, capped sizes),
   * gates risky tools behind a confirmation card, and only then calls the tool's run().
   * Pure logic: no DOM, no timers, no network. Tools receive what they need through ctx.
   */

  var MAX_CALLS = 3;
  var tools = {};

  function clean(s, max) {
    return String(s == null ? "" : s).replace(/[\u0000-\u001f\u007f]/g, " ").replace(/\s+/g, " ").trim().slice(0, max);
  }

  function register(def) {
    if (!def || !/^[a-z][a-z0-9_]{1,31}$/.test(def.name || "")) throw new Error("bad_tool_name");
    if (typeof def.run !== "function") throw new Error("bad_tool_run");
    if (tools[def.name]) throw new Error("duplicate_tool");
    tools[def.name] = {
      name: def.name,
      description: clean(def.description, 120),
      risk: def.risk === "confirm" ? "confirm" : "safe",
      params: def.params || {},
      run: def.run,
      describe: typeof def.describe === "function" ? def.describe : null
    };
  }

  function validate(def, args) {
    if (args === null || typeof args !== "object" || Array.isArray(args)) return { ok: false, error: "bad_args" };
    var out = {}, k;
    for (k in args) {
      if (!Object.prototype.hasOwnProperty.call(args, k)) continue;
      if (!Object.prototype.hasOwnProperty.call(def.params, k)) return { ok: false, error: "unknown_arg:" + clean(k, 20) };
    }
    for (k in def.params) {
      if (!Object.prototype.hasOwnProperty.call(def.params, k)) continue;
      var p = def.params[k], v = Object.prototype.hasOwnProperty.call(args, k) ? args[k] : undefined;
      if (v === undefined || v === null) {
        if (p.required) return { ok: false, error: "missing_arg:" + k };
        continue;
      }
      if (p.type === "string") {
        if (typeof v !== "string") return { ok: false, error: "bad_type:" + k };
        v = clean(v, p.max || 200);
        if (p.required && !v) return { ok: false, error: "missing_arg:" + k };
      } else if (p.type === "number") {
        if (typeof v !== "number" || !isFinite(v)) return { ok: false, error: "bad_type:" + k };
        if (p.min != null && v < p.min) return { ok: false, error: "out_of_range:" + k };
        if (p.max != null && v > p.max) return { ok: false, error: "out_of_range:" + k };
      } else if (p.type === "boolean") {
        if (typeof v !== "boolean") return { ok: false, error: "bad_type:" + k };
      } else if (p.type === "enum") {
        if (!p.values || p.values.indexOf(v) < 0) return { ok: false, error: "bad_value:" + k };
      } else return { ok: false, error: "bad_schema:" + k };
      out[k] = v;
    }
    return { ok: true, args: out };
  }

  // Returns {ok, result} | {ok:false, error} | {ok:false, needsConfirm:true, card}.
  function execute(name, args, ctx) {
    ctx = ctx || {};
    if (!Object.prototype.hasOwnProperty.call(tools, name)) return { ok: false, error: "unknown_tool" };
    var def = tools[name], v = validate(def, args);
    if (!v.ok) return v;
    if (def.risk === "confirm" && ctx.confirmed !== true) {
      return { ok: false, needsConfirm: true, card: { tool: name, title: def.description, summary: clean(def.describe ? def.describe(v.args) : JSON.stringify(v.args), 200), args: v.args } };
    }
    try { return { ok: true, result: def.run(v.args, ctx) }; }
    catch (e) { return { ok: false, error: "tool_failed" }; }
  }

  // Finds [[tool name {json}]] markers in model output. Bad JSON or odd names are ignored, never executed.
  function extractCalls(text) {
    var calls = [], re = /\[\[tool\s+([a-z][a-z0-9_]{1,31})\s*(\{[^\[\]]*\})?\s*\]\]/g, m;
    var s = String(text == null ? "" : text);
    while ((m = re.exec(s)) && calls.length < MAX_CALLS) {
      var args = {};
      if (m[2]) {
        try { args = JSON.parse(m[2]); } catch (e) { continue; }
        if (args === null || typeof args !== "object" || Array.isArray(args)) continue;
      }
      calls.push({ name: m[1], args: args });
    }
    return { calls: calls, text: s.replace(/\[\[tool[^\]]*\]\]/g, "").replace(/\s{2,}/g, " ").trim() };
  }

  // Short list for the system prompt (kept small: the backend caps prompts at 3000 chars).
  function manifest() {
    var lines = [], n;
    for (n in tools) if (Object.prototype.hasOwnProperty.call(tools, n)) {
      var keys = Object.keys(tools[n].params).join(",");
      lines.push(n + "(" + keys + "): " + tools[n].description);
    }
    return lines.length ? "Tools (request with [[tool name {\"arg\":\"value\"}]], one per line, only when the user asks):\n" + lines.join("\n") : "";
  }

  function names() { return Object.keys(tools); }
  function reset() { tools = {}; }

  root.BliziTools = { register: register, execute: execute, extractCalls: extractCalls, manifest: manifest, names: names, validate: validate, _reset: reset };
})(typeof window !== "undefined" ? window : this);
