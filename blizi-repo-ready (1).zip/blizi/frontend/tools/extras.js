(function (root) {
  "use strict";

  /*
   * BLIZI extras: notes, spending tracker, calculator and brain-dump splitter.
   * Anchored local commands, clock- and storage-injected, no DOM, no network, no AI calls.
   */

  var KEY_N = "blizi.notes.v2", KEY_F = "blizi.spending.v1", MAX_N = 200, MAX_F = 1000;
  var RE_NOTE = /^\s*(?:note|save note|take a note)\s*[:\-]\s*(.+?)\s*$/i;
  var RE_NOTES = /^\s*(?:(?:show|list)\s+)?(?:me\s+)?(?:my\s+)?notes\s*\??\s*$/i;
  var RE_DELNOTE = /^\s*(?:delete|remove)\s+note\s+(\d{1,3})\s*$/i;
  var RE_SPENT = /^\s*(?:i\s+)?(?:spent|paid)\s+[$€£₦¥]?\s*(\d{1,9}(?:[.,]\d{1,2})?)\s*(?:on|for)\s+(.+?)\s*$/i;
  var RE_SPEND = /^\s*(?:(?:show|what(?:'s| is| are))\s+)?(?:me\s+)?(?:my\s+)?(?:spending|expenses)(?:\s+(today|this month))?\s*\??\s*$/i;
  var RE_CALC = /^\s*(?:calc(?:ulate)?|what(?:'s| is))\s+([0-9\s.+\-*\/^%()x×÷,]+?)\s*[?=]?\s*$/i;

  function clean(s, max) { return String(s == null ? "" : s).replace(/[\u0000-\u001f\u007f]/g, " ").replace(/\s+/g, " ").trim().slice(0, max); }
  function pad(n) { return n < 10 ? "0" + n : String(n); }
  function dkey(ms) { var d = new Date(ms); return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate()); }
  function money(n) { return (Math.round(n * 100) / 100).toFixed(2); }

  // Safe arithmetic: numbers, + - * / ^ % and parentheses. No eval, no identifiers.
  function calc(expr) {
    var s = String(expr).replace(/[x×]/gi, "*").replace(/÷/g, "/").replace(/,/g, "").replace(/\s+/g, "");
    if (!s || s.length > 80 || !/^[0-9.+\-*\/^%()]+$/.test(s) || !/[0-9]/.test(s)) return null;
    var pos = 0, steps = 0;
    function peek() { return s.charAt(pos); }
    function guard() { if (++steps > 400) throw new Error("complex"); }
    function number() {
      guard();
      var m = /^\d+(?:\.\d+)?|^\.\d+/.exec(s.slice(pos));
      if (!m) throw new Error("num");
      pos += m[0].length; return parseFloat(m[0]);
    }
    function atom() {
      guard();
      if (peek() === "-") { pos++; return -power(); }
      if (peek() === "+") { pos++; return power(); }
      if (peek() === "(") { pos++; var v = add(); if (peek() !== ")") throw new Error("paren"); pos++; return v; }
      return number();
    }
    function power() { var b = atom(); if (peek() === "^") { pos++; var e = power(); b = Math.pow(b, e); } return b; }
    function mul() {
      var v = power();
      while (peek() === "*" || peek() === "/" || peek() === "%") {
        var op = s.charAt(pos++), r = power();
        if (op === "*") v *= r; else if (op === "/") { if (r === 0) throw new Error("div0"); v /= r; } else { if (r === 0) throw new Error("div0"); v %= r; }
      }
      return v;
    }
    function add() { var v = mul(); while (peek() === "+" || peek() === "-") { var op = s.charAt(pos++), r = mul(); v = op === "+" ? v + r : v - r; } return v; }
    try { var out = add(); if (pos !== s.length || !isFinite(out)) return null; return out; } catch (e) { return null; }
  }

  // Splits a "brain dump" into short task items.
  function splitDump(text) {
    var parts = String(text == null ? "" : text).slice(0, 600).split(/\n|;|,?\s+and then\s+|,\s+(?:and\s+)?|\s+and\s+(?=(?:call|buy|pay|send|book|email|text|clean|fix|finish|write|read|get|make|check|pick|order|schedule|renew|cancel|return)\b)/i);
    var out = [];
    parts.forEach(function (p) { p = clean(p, 100).replace(/^(?:also|then|and|to)\s+/i, ""); if (p.length > 1 && out.length < 12) out.push(p); });
    return out;
  }

  function create(deps) {
    var now = deps.now;
    function store(key) {
      return {
        get: function () { try { var v = deps.load(key); return Array.isArray(v) ? v : []; } catch (e) { return []; } },
        set: function (v) { try { deps.save(key, v); } catch (e) {} }
      };
    }
    var notes = store(KEY_N), spend = store(KEY_F), seq = 0;

    function totals(t) {
      var all = spend.get(), day = dkey(t), mon = day.slice(0, 7), d = 0, m = 0;
      all.forEach(function (x) { var k = dkey(x.at); if (k === day) d += x.amt; if (k.slice(0, 7) === mon) m += x.amt; });
      return { day: d, month: m, count: all.length };
    }

    function handle(text) {
      var s = String(text == null ? "" : text).slice(0, 500), m, t = now();
      if ((m = RE_NOTE.exec(s))) {
        var a = notes.get(); if (a.length >= MAX_N) return { reply: "Your notes are full. Delete one first.", face: "serious" };
        var body = clean(m[1], 500); if (!body) return null;
        a.push({ id: "nt_" + t.toString(36) + "_" + (seq++), text: body, at: t }); notes.set(a);
        return { reply: "Saved your note.", face: "happy" };
      }
      if (RE_NOTES.test(s)) {
        var l = notes.get().slice(-10);
        return l.length ? { reply: "Your notes:\n" + l.map(function (n, i) { return (i + 1) + ". " + n.text; }).join("\n"), face: "happy" } : { reply: "You have no notes yet.", face: "neutral" };
      }
      if ((m = RE_DELNOTE.exec(s))) {
        var all = notes.get(), idx = parseInt(m[1], 10) - 1, shown = all.slice(-10), hit = shown[idx];
        if (!hit) return { reply: "I couldn’t find that note number.", face: "thinking" };
        notes.set(all.filter(function (n) { return n.id !== hit.id; }));
        return { reply: "Deleted that note.", face: "neutral" };
      }
      if ((m = RE_SPENT.exec(s))) {
        var amt = parseFloat(m[1].replace(",", ".")), what = clean(m[2], 60);
        if (!(amt > 0) || !what) return null;
        var f = spend.get(); f.push({ id: "sp_" + t.toString(36) + "_" + (seq++), amt: amt, what: what, at: t }); spend.set(f.slice(-MAX_F));
        var tt = totals(t);
        return { reply: "Logged " + money(amt) + " for " + what + ". Today: " + money(tt.day) + ". This month: " + money(tt.month) + ".", face: "happy" };
      }
      if ((m = RE_SPEND.exec(s))) {
        var tot = totals(t);
        if (!tot.count) return { reply: "You haven’t logged any spending yet. Try “spent 20 on lunch”.", face: "neutral" };
        return { reply: (m[1] && m[1].toLowerCase() === "today" ? "Today you’ve spent " + money(tot.day) + "." : "Today: " + money(tot.day) + ". This month: " + money(tot.month) + "."), face: "happy" };
      }
      if ((m = RE_CALC.exec(s))) {
        if (!/[+\-*\/^%x×÷]/i.test(m[1].replace(/^\s*-/, ""))) return null;
        var r = calc(m[1]);
        if (r === null) return { reply: "I couldn’t work that out. Try something like 12 * (3 + 4).", face: "thinking" };
        return { reply: m[1].trim() + " = " + String(Math.round(r * 1e9) / 1e9), face: "happy" };
      }
      return null;
    }

    return { handle: handle, todayTotal: function () { return totals(now()).day; }, _notes: notes, _spend: spend };
  }

  root.BliziExtras = { create: create, calc: calc, splitDump: splitDump, KEY_N: KEY_N, KEY_F: KEY_F };
})(typeof window !== "undefined" ? window : this);
