(function (root) {
  "use strict";

  /*
   * BLIZI device info (Jarvis' charging telemetry, diagnostics, location, network audit, web edition).
   * Each call resolves to a plain-text reply and never rejects: unsupported browsers, denied permission
   * and timeouts all produce an honest message. The navigator is injected so tests can fake any browser.
   */

  function pct(x) { return Math.round(x * 100); }
  function fmtTime(sec) { if (!isFinite(sec) || sec <= 0) return ""; var h = Math.floor(sec / 3600), m = Math.round((sec % 3600) / 60); return h ? h + "h " + m + "m" : m + "m"; }
  function withTimeout(p, ms) { return new Promise(function (res, rej) { var d = false, t = setTimeout(function () { if (!d) { d = true; rej(new Error("timeout")); } }, ms); Promise.resolve(p).then(function (v) { if (!d) { d = true; clearTimeout(t); res(v); } }, function (e) { if (!d) { d = true; clearTimeout(t); rej(e); } }); }); }

  function create(nav) {
    nav = nav || {};
    function battery() {
      if (typeof nav.getBattery !== "function") return Promise.resolve("This browser doesn’t share battery info. The Blizi app will be able to.");
      return withTimeout(nav.getBattery(), 3000).then(function (b) {
        var lvl = pct(b.level), line = "Battery is at " + lvl + "%";
        if (b.charging) { var f = fmtTime(b.chargingTime); line += ", charging" + (f ? " (full in about " + f + ")" : ""); }
        else { var d = fmtTime(b.dischargingTime); line += ", on battery" + (d ? " (about " + d + " left)" : ""); }
        if (!b.charging && lvl <= 20) line += ". That’s low, find a charger soon.";
        return line + ".";
      }).catch(function () { return "I couldn’t read the battery just now."; });
    }
    function location() {
      var g = nav.geolocation;
      if (!g || typeof g.getCurrentPosition !== "function") return Promise.resolve("This browser can’t share your location.");
      return withTimeout(new Promise(function (ok, no) { g.getCurrentPosition(ok, no, { enableHighAccuracy: false, timeout: 8000, maximumAge: 60000 }); }), 10000).then(function (p) {
        var c = p.coords || {}, la = Number(c.latitude), lo = Number(c.longitude);
        if (!isFinite(la) || !isFinite(lo)) return "I got an unusable location reading.";
        return "You’re near " + la.toFixed(3) + ", " + lo.toFixed(3) + (isFinite(c.accuracy) ? " (accurate to about " + Math.round(c.accuracy) + " m)" : "") + ".";
      }).catch(function (e) { return e && e.code === 1 ? "Location permission was denied. You can allow it in your browser settings." : "I couldn’t get your location right now."; });
    }
    function system() {
      var lines = ["Online: " + (nav.onLine === false ? "no" : "yes")];
      var c = nav.connection;
      if (c) lines.push("Network: " + (c.effectiveType || "unknown") + (isFinite(c.downlink) ? ", about " + c.downlink + " Mbps" : "") + (c.saveData ? ", data saver on" : ""));
      if (isFinite(nav.deviceMemory)) lines.push("Memory: about " + nav.deviceMemory + " GB");
      if (isFinite(nav.hardwareConcurrency)) lines.push("CPU threads: " + nav.hardwareConcurrency);
      var parts = [Promise.resolve()];
      var st = nav.storage && typeof nav.storage.estimate === "function" ? withTimeout(nav.storage.estimate(), 2000).then(function (e) { if (e && e.quota) lines.push("Blizi storage: " + (e.usage / 1048576).toFixed(1) + " MB used of " + Math.round(e.quota / 1048576) + " MB"); }).catch(function () {}) : null;
      if (st) parts.push(st);
      return Promise.all(parts).then(function () { return battery(); }).then(function (b) { lines.push(b); return "System check:\n" + lines.join("\n"); });
    }
    function coords() {
      var g = nav.geolocation;
      if (!g || typeof g.getCurrentPosition !== "function") return Promise.resolve(null);
      return withTimeout(new Promise(function (ok, no) { g.getCurrentPosition(ok, no, { enableHighAccuracy: false, timeout: 8000, maximumAge: 300000 }); }), 10000).then(function (p) {
        var la = Number(p && p.coords && p.coords.latitude), lo = Number(p && p.coords && p.coords.longitude);
        return isFinite(la) && isFinite(lo) ? { lat: la, lon: lo } : null;
      }).catch(function () { return null; });
    }
    // Rough, uncalibrated loudness from the mic (relative to full scale), sampled for ms milliseconds.
    function noise(AC, ms) {
      var md = nav.mediaDevices;
      if (!md || typeof md.getUserMedia !== "function" || !AC) return Promise.resolve("This browser can’t listen to the microphone.");
      var stream = null, ctx = null;
      function stop() { try { stream && stream.getTracks().forEach(function (t) { t.stop(); }); } catch (e) {} try { ctx && ctx.close && ctx.close(); } catch (e) {} }
      return withTimeout(md.getUserMedia({ audio: true }), 10000).then(function (s) {
        stream = s; ctx = new AC();
        var an = ctx.createAnalyser(); an.fftSize = 1024; ctx.createMediaStreamSource(s).connect(an);
        var buf = new Float32Array(an.fftSize), peak = 0, sum = 0, n = 0;
        return new Promise(function (res) {
          var iv = setInterval(function () { an.getFloatTimeDomainData(buf); var e = 0, i; for (i = 0; i < buf.length; i++) e += buf[i] * buf[i]; var r = Math.sqrt(e / buf.length); sum += r; n++; if (r > peak) peak = r; }, 50);
          setTimeout(function () { clearInterval(iv); res({ avg: n ? sum / n : 0, peak: peak }); }, ms || 1500);
        });
      }).then(function (m) {
        stop();
        var db = m.avg > 0 ? 20 * Math.log(m.avg) / Math.LN10 : -100;
        var label = db > -20 ? "very loud" : db > -35 ? "loud" : db > -50 ? "moderate" : "quiet";
        return "It sounds " + label + " around you (about " + Math.round(db) + " dB relative to full scale; this is not a calibrated meter).";
      }).catch(function (e) { stop(); return e && /denied|permission|notallowed/i.test(String(e.name || e.message)) ? "Microphone permission was denied." : "I couldn’t listen just now."; });
    }
    return { battery: battery, location: location, system: system, coords: coords, noise: noise };
  }

  root.BliziDevice = { create: create };
})(typeof window !== "undefined" ? window : this);
