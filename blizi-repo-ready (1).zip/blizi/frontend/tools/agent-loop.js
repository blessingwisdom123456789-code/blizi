(function (root) {
  "use strict";

  /*
   * BLIZI agent loop: model reply -> [[tool ...]] requests -> run them -> feed results back -> repeat.
   * Hard step cap, abort between steps, risky tools gated by confirm(). Pure logic; everything is injected.
   */

  var MAX_STEPS = 5, MAX_MESSAGES = 20, MAX_RESULT = 1500;

  function cap(s, n) { s = String(s == null ? "" : s); return s.length > n ? s.slice(0, n - 1) + "…" : s; }
  function aborted(signal) { return !!(signal && signal.aborted); }
  function abortErr() { return { code: "aborted", message: "Stopped." }; }

  function runOne(T, call, confirm, maxResult) {
    var r = T.execute(call.name, call.args, {});
    var p;
    if (r.needsConfirm) {
      p = Promise.resolve().then(function () { return confirm ? confirm(r.card) : false; }).then(function (yes) {
        if (yes !== true) return { status: "declined", text: "error: user_declined" };
        var r2 = T.execute(call.name, call.args, { confirmed: true });
        return settle(r2);
      });
    } else p = Promise.resolve(settle(r));
    return p.then(function (o) { o.text = cap(o.text, maxResult); return o; });
  }

  function settle(r) {
    if (!r.ok) return { status: "error", text: "error: " + (r.error || "failed") };
    return Promise.resolve(r.result).then(function (v) {
      var t = String(v == null ? "done" : v);
      return { status: /^error:/.test(t) ? "error" : "ok", text: t };
    }, function (e) { return { status: "error", text: "error: tool_failed: " + cap(e && e.message, 80) }; });
  }

  // o: {messages, system, complete(msgs,{system,signal}), tools, confirm, onStep, signal, maxSteps, maxMessages, maxResult}
  // Resolves {text, steps, capped}. Rejects with whatever complete() rejects, or {code:"aborted"}.
  function run(o) {
    var T = o.tools, msgs = o.messages.slice(), steps = [];
    var maxSteps = o.maxSteps != null ? o.maxSteps : MAX_STEPS, maxMsgs = o.maxMessages || MAX_MESSAGES, maxResult = o.maxResult || MAX_RESULT;

    function turn(i) {
      if (aborted(o.signal)) return Promise.reject(abortErr());
      return Promise.resolve(o.complete(msgs, { system: o.system, signal: o.signal })).then(function (r) {
        var text = String((r && r.text) || ""), ex = T.extractCalls(text);
        if (!ex.calls.length) return { text: text, steps: steps, capped: false };
        if (i >= maxSteps) return { text: (ex.text || "") + " (I stopped after " + maxSteps + " steps without finishing.)", steps: steps, capped: true };
        var results = [], chain = Promise.resolve();
        ex.calls.forEach(function (call) {
          chain = chain.then(function () {
            if (aborted(o.signal)) throw abortErr();
            return runOne(T, call, o.confirm, maxResult).then(function (out) {
              var step = { name: call.name, args: call.args, status: out.status, text: out.text };
              steps.push(step); results.push(call.name + ": " + out.text);
              if (o.onStep) { try { o.onStep(step); } catch (e) {} }
            });
          });
        });
        return chain.then(function () {
          msgs.push({ role: "assistant", content: cap(text, 1900) });
          msgs.push({ role: "user", content: cap("[tool results]\n" + results.join("\n"), maxResult) });
          while (msgs.length > maxMsgs) msgs.splice(0, 2);
          return turn(i + 1);
        });
      });
    }
    return turn(0);
  }

  root.BliziAgent = { run: run, MAX_STEPS: MAX_STEPS };
})(typeof window !== "undefined" ? window : this);
