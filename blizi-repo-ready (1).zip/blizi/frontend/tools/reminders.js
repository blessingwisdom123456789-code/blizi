(function (root) {
  "use strict";

  /*
   * BLIZI reminders: a phrase parser plus a small scheduler. Pure and clock-injected.
   * The page owns the timer and shows the notification; this module decides what is due.
   * Catch-up: reminders that came due while the app was closed fire once, marked late.
   */

  var MAX = 100, KEEP_FIRED_MS = 7 * 24 * 3600 * 1000, LATE_MS = 60 * 1000;
  var UNIT = { second: 1000, sec: 1000, minute: 60000, min: 60000, hour: 3600000, hr: 3600000, day: 86400000 };
  var WORDNUM = { a: 1, an: 1, one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9, ten: 10, fifteen: 15, twenty: 20, thirty: 30 };

  function dayStart(ms) { var d = new Date(ms); return new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime(); }
  function atHour(dayMs, h, m) { var d = new Date(dayMs); return new Date(d.getFullYear(), d.getMonth(), d.getDate(), h, m, 0, 0).getTime(); }
  function addDays(dayMs, n) { var d = new Date(dayMs); return new Date(d.getFullYear(), d.getMonth(), d.getDate() + n).getTime(); }

  function tidy(s) {
    s = s.replace(/\s+/g, " ").replace(/^[\s,.:;-]+|[\s,.:;-]+$/g, "");
    s = s.replace(/^(?:to|that|about|please)\s+/i, "").replace(/\s+(?:please|to)$/i, "");
    return s.trim();
  }

  // parse("remind me to call mum in 10 minutes", now) -> {at, text} or null
  function parse(input, now) {
    var s = String(input == null ? "" : input).replace(/[\u0000-\u001f]/g, " ").slice(0, 300).trim();
    var prev;
    do { prev = s; s = s.replace(/^(?:hey blizi|blizi|please|can you|could you|set a reminder|set reminder|remind me|reminder)\b[\s,:]*/i, ""); } while (s !== prev);
    var m, at = null, rest = s;

    m = /\bin\s+(\d{1,4}|an?|one|two|three|four|five|ten|fifteen|twenty|thirty)\s*(seconds?|secs?|minutes?|mins?|hours?|hrs?|days?)\b/i.exec(s);
    if (m) {
      var n = /^\d/.test(m[1]) ? parseInt(m[1], 10) : WORDNUM[m[1].toLowerCase()];
      var unit = UNIT[m[2].toLowerCase().replace(/s$/, "")];
      if (n > 0 && unit && n * unit <= 30 * 86400000) { at = now + n * unit; rest = s.replace(m[0], " "); }
    }
    if (at === null) {
      var dayWord = /\b(tomorrow|tonight|today)\b/i.exec(s);
      // A bare number only counts as a time with "at", a colon or am/pm ("buy 2 eggs" is not a time).
      var tm = null, re = /\b(at\s+)?(\d{1,2})(?::(\d{2}))?\s*(am|pm|a\.m\.|p\.m\.)?(?![\d:])/ig, x;
      while ((x = re.exec(s))) { if (x[1] || x[3] || x[4]) { tm = x; break; } }
      if (tm) {
        var h = parseInt(tm[2], 10), mi = tm[3] ? parseInt(tm[3], 10) : 0, mer = tm[4] ? tm[4].toLowerCase().charAt(0) : "";
        if (mi > 59 || h > 23 || (mer && (h < 1 || h > 12))) return null;
        var today = dayStart(now), word = dayWord ? dayWord[1].toLowerCase() : "";
        var base = word === "tomorrow" ? addDays(today, 1) : today;
        if (mer) { h = h % 12 + (mer === "p" ? 12 : 0); at = atHour(base, h, mi); if (at <= now && word !== "tomorrow") at = atHour(addDays(today, 1), h, mi); }
        else if (h >= 13 || h === 0 || tm[3] && h > 12) { at = atHour(base, h, mi); if (at <= now && word !== "tomorrow") at = atHour(addDays(today, 1), h, mi); }
        else {
          // Ambiguous 1-12: choose the sooner future of AM or PM (or PM for "tonight").
          var am = atHour(base, h % 12, mi), pm = atHour(base, h % 12 + 12, mi), c = [];
          if (word === "tonight") c = [pm];
          else if (word === "tomorrow") c = [h >= 7 && h <= 11 ? am : pm];
          else c = [am, pm].filter(function (v) { return v > now; });
          if (!c.length) c = [atHour(addDays(today, 1), h % 12, mi)];
          at = Math.min.apply(null, c);
        }
        rest = s.replace(tm[0], " ").replace(dayWord ? dayWord[0] : "", " ");
      } else if (dayWord && dayWord[1].toLowerCase() === "tomorrow") {
        at = atHour(addDays(dayStart(now), 1), 9, 0); rest = s.replace(dayWord[0], " ");
      }
    }
    if (at === null || at <= now) return null;
    var text = tidy(rest);
    return { at: at, text: text ? text.slice(0, 140) : "Reminder" };
  }

  function create(store, opts) {
    var id = 0;
    function load() { var a = store.get(); return Array.isArray(a) ? a : []; }
    function save(a) { store.set(a.slice(-MAX)); }
    return {
      add: function (text, at, now) {
        var a = load();
        if (a.filter(function (r) { return !r.fired; }).length >= MAX) return null;
        var r = { id: "rm_" + (now || 0).toString(36) + "_" + (id++), text: String(text).slice(0, 140), at: at, fired: false };
        a.push(r); save(a); return r;
      },
      list: function () { return load().filter(function (r) { return !r.fired; }).sort(function (p, q) { return p.at - q.at; }); },
      cancel: function (id2) { var a = load(), n = a.length; a = a.filter(function (r) { return r.id !== id2; }); save(a); return a.length < n; },
      due: function (now) {
        var a = load(), out = [];
        a.forEach(function (r) { if (!r.fired && r.at <= now) { r.fired = true; r.firedAt = now; out.push({ id: r.id, text: r.text, at: r.at, late: now - r.at > LATE_MS }); } });
        a = a.filter(function (r) { return !r.fired || now - r.firedAt < KEEP_FIRED_MS; });
        if (out.length) save(a);
        return out.sort(function (p, q) { return p.at - q.at; });
      },
      nextAt: function () { var l = this.list(); return l.length ? l[0].at : null; }
    };
  }

  root.BliziReminders = { parse: parse, create: create, MAX: MAX };
})(typeof window !== "undefined" ? window : this);
