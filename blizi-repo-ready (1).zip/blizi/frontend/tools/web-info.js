(function (root) {
  "use strict";

  /*
   * BLIZI live info (Jarvis' tools service, airspace radar, crypto tracker and commute planner, web edition).
   * Public, key-less APIs only. Every method resolves to plain text and never rejects. fetch is injected.
   * Inputs are length-capped and encoded; responses are size-checked and shape-checked before use.
   */

  var COINS = { bitcoin: "bitcoin", btc: "bitcoin", ethereum: "ethereum", eth: "ethereum", solana: "solana", sol: "solana", dogecoin: "dogecoin", doge: "dogecoin", ripple: "ripple", xrp: "ripple", cardano: "cardano", ada: "cardano", litecoin: "litecoin", ltc: "litecoin", bnb: "binancecoin", toncoin: "the-open-network", tron: "tron", polkadot: "polkadot", dot: "polkadot" };
  var MAX_BODY = 300000;

  function enc(s, max) { return encodeURIComponent(String(s == null ? "" : s).replace(/[\u0000-\u001f]/g, " ").replace(/\s+/g, " ").trim().slice(0, max || 60)); }
  function num(x) { return typeof x === "number" && isFinite(x); }
  function fmt(n, d) { return Number(n).toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d }); }
  function validCoords(c) { return c && num(c.lat) && num(c.lon) && Math.abs(c.lat) <= 90 && Math.abs(c.lon) <= 180; }

  function create(deps) {
    var timeoutMs = deps.timeoutMs || 8000;

    function getJson(url) {
      return new Promise(function (resolve, reject) {
        var done = false, ac = typeof AbortController !== "undefined" ? new AbortController() : null;
        var t = setTimeout(function () { if (!done) { done = true; if (ac) ac.abort(); reject(new Error("timeout")); } }, timeoutMs);
        Promise.resolve().then(function () { return deps.fetch(url, ac ? { signal: ac.signal } : {}); }).then(function (r) {
          if (!r || !r.ok) { var e = new Error("http"); e.status = r && r.status; throw e; }
          return r.text();
        }).then(function (txt) {
          if (typeof txt !== "string" || txt.length > MAX_BODY) throw new Error("size");
          var j = JSON.parse(txt);
          if (!done) { done = true; clearTimeout(t); resolve(j); }
        }).catch(function (e) { if (!done) { done = true; clearTimeout(t); reject(e); } });
      });
    }
    function fail(what) { return function () { return "I couldn’t reach " + what + " right now."; }; }

    function weather(place, coords) {
      var q = place ? enc(place) : validCoords(coords) ? coords.lat.toFixed(3) + "," + coords.lon.toFixed(3) : "";
      if (!q) return Promise.resolve("Tell me a place, like “weather in Lagos”, or allow location and say “weather”.");
      return getJson("https://wttr.in/" + q + "?format=j1").then(function (j) {
        var c = j && j.current_condition && j.current_condition[0], t = c && parseFloat(c.temp_C);
        if (!c || !isFinite(t)) return "I couldn’t read the weather for that place.";
        var area = j.nearest_area && j.nearest_area[0] && j.nearest_area[0].areaName && j.nearest_area[0].areaName[0] && j.nearest_area[0].areaName[0].value;
        var desc = c.weatherDesc && c.weatherDesc[0] && c.weatherDesc[0].value;
        var day = j.weather && j.weather[0], out = (place ? String(place).slice(0, 40) : area || "Your location") + ": " + Math.round(t) + "°C";
        if (isFinite(parseFloat(c.FeelsLikeC))) out += " (feels like " + Math.round(parseFloat(c.FeelsLikeC)) + "°C)";
        if (desc) out += ", " + String(desc).slice(0, 40).toLowerCase();
        if (isFinite(parseFloat(c.humidity))) out += ", humidity " + parseInt(c.humidity, 10) + "%";
        if (isFinite(parseFloat(c.windspeedKmph))) out += ", wind " + Math.round(parseFloat(c.windspeedKmph)) + " km/h";
        if (day && isFinite(parseFloat(day.maxtempC)) && isFinite(parseFloat(day.mintempC))) out += ". Today ranges " + Math.round(parseFloat(day.mintempC)) + " to " + Math.round(parseFloat(day.maxtempC)) + "°C";
        return out + ".";
      }).catch(fail("the weather service"));
    }

    function wiki(topic) {
      var t = String(topic == null ? "" : topic).trim().slice(0, 60);
      if (!t) return Promise.resolve("What should I look up?");
      return getJson("https://en.wikipedia.org/api/rest_v1/page/summary/" + enc(t.replace(/\s+/g, "_"))).then(function (j) {
        if (!j || typeof j.extract !== "string" || !j.extract) return "I couldn’t find a Wikipedia page for “" + t + "”.";
        if (j.type === "disambiguation") return "“" + t + "” could mean several things. Try being more specific.";
        var ex = j.extract.replace(/\s+/g, " ").trim(), cut = ex.slice(0, 360), end = Math.max(cut.lastIndexOf(". "), cut.lastIndexOf(".") === cut.length - 1 ? cut.length - 1 : -1);
        return (end > 80 ? cut.slice(0, end + 1) : ex.length > 360 ? cut.replace(/\s+\S*$/, "") + "…" : ex) + " (Wikipedia)";
      }).catch(function (e) { return e && e.status === 404 ? "I couldn’t find a Wikipedia page for “" + t + "”." : "I couldn’t reach Wikipedia right now."; });
    }

    function crypto(name) {
      var id = COINS[String(name || "").toLowerCase()];
      if (!id) return Promise.resolve("I only track a few coins: bitcoin, ethereum, solana, dogecoin, ripple, cardano, litecoin, bnb, toncoin, tron and polkadot.");
      return getJson("https://api.coingecko.com/api/v3/simple/price?ids=" + id + "&vs_currencies=usd&include_24hr_change=true").then(function (j) {
        var r = j && j[id];
        if (!r || !num(r.usd)) return "I couldn’t read that price.";
        var label = String(name).toLowerCase(); label = label.charAt(0).toUpperCase() + label.slice(1);
        return label + ": $" + fmt(r.usd, r.usd >= 100 ? 2 : 4) + (num(r.usd_24h_change) ? " (" + (r.usd_24h_change >= 0 ? "+" : "") + r.usd_24h_change.toFixed(1) + "% in 24h)" : "") + ".";
      }).catch(fail("the price service"));
    }

    function iss() {
      return getJson("https://api.wheretheiss.at/v1/satellites/25544").then(function (j) {
        if (!j || !num(j.latitude) || !num(j.longitude)) return "I couldn’t read the space station’s position.";
        return "The ISS is over " + j.latitude.toFixed(1) + ", " + j.longitude.toFixed(1) + (num(j.altitude) ? " at about " + Math.round(j.altitude) + " km" : "") + (num(j.velocity) ? ", moving about " + fmt(j.velocity, 0) + " km/h" : "") + ".";
      }).catch(fail("the space station tracker"));
    }

    function aircraft(coords) {
      if (!validCoords(coords)) return Promise.resolve("I need your location for that. Allow location, then ask again.");
      var d = 0.4, url = "https://opensky-network.org/api/states/all?lamin=" + (coords.lat - d).toFixed(3) + "&lamax=" + (coords.lat + d).toFixed(3) + "&lomin=" + (coords.lon - d).toFixed(3) + "&lomax=" + (coords.lon + d).toFixed(3);
      return getJson(url).then(function (j) {
        var s = j && Array.isArray(j.states) ? j.states : [];
        if (!s.length) return "I don’t see any aircraft within about 40 km of you right now.";
        var list = s.slice(0, 3).map(function (a) {
          var cs = typeof a[1] === "string" && a[1].trim() ? a[1].trim().slice(0, 8) : "unknown", alt = num(a[7]) ? Math.round(a[7]) + " m" : "altitude unknown";
          return cs + " (" + (typeof a[2] === "string" ? a[2].slice(0, 30) : "?") + ", " + alt + ")";
        });
        return s.length + " aircraft within about 40 km: " + list.join("; ") + (s.length > 3 ? " and " + (s.length - 3) + " more" : "") + ".";
      }).catch(fail("the aircraft tracker"));
    }

    function geocode(q) {
      return getJson("https://nominatim.openstreetmap.org/search?format=json&limit=1&q=" + enc(q)).then(function (a) {
        var p = Array.isArray(a) && a[0], la = p && parseFloat(p.lat), lo = p && parseFloat(p.lon);
        return isFinite(la) && isFinite(lo) ? { lat: la, lon: lo } : null;
      });
    }
    function route(from, to) {
      return Promise.all([geocode(from), geocode(to)]).then(function (pts) {
        if (!pts[0] || !pts[1]) return "I couldn’t find one of those places.";
        return getJson("https://router.project-osrm.org/route/v1/driving/" + pts[0].lon + "," + pts[0].lat + ";" + pts[1].lon + "," + pts[1].lat + "?overview=false").then(function (j) {
          var r = j && j.routes && j.routes[0];
          if (!r || !num(r.distance) || !num(r.duration)) return "I couldn’t work out a driving route between them.";
          var min = Math.round(r.duration / 60), t = min >= 60 ? Math.floor(min / 60) + "h " + (min % 60) + "m" : min + " min";
          return "About " + (r.distance / 1000).toFixed(1) + " km, roughly " + t + " by car (no live traffic).";
        });
      }).catch(fail("the routing service"));
    }

    return { weather: weather, wiki: wiki, crypto: crypto, iss: iss, aircraft: aircraft, route: route, coins: COINS };
  }

  root.BliziWeb = { create: create, COINS: COINS };
})(typeof window !== "undefined" ? window : this);
