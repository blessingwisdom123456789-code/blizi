(function (root) {
  "use strict";

  /*
   * BLIZI native bridge. In the browser every native-only feature reports "unavailable_on_web".
   * When Blizi is wrapped as an app (Capacitor/Kotlin), the shell registers real implementations
   * for the same feature names, and tools keep working without any change.
   *
   * Features that need the native shell: accessibility (screen automation), notification_listener,
   * wake_word, overlay, app_launch, sentry (background watch), call_sms.
   */

  var FEATURES = ["accessibility", "notification_listener", "wake_word", "overlay", "app_launch", "sentry", "call_sms"];
  var impl = {};

  function register(feature, fn) {
    if (FEATURES.indexOf(feature) < 0) throw new Error("unknown_feature");
    if (typeof fn !== "function") throw new Error("bad_impl");
    impl[feature] = fn;
  }
  function has(feature) { return Object.prototype.hasOwnProperty.call(impl, feature); }
  function call(feature, args) {
    if (FEATURES.indexOf(feature) < 0) return { ok: false, error: "unknown_feature" };
    if (!has(feature)) return { ok: false, error: "unavailable_on_web" };
    try { return { ok: true, result: impl[feature](args || {}) }; } catch (e) { return { ok: false, error: "native_failed" }; }
  }
  function capabilities() {
    var out = { native: Object.keys(impl).length > 0, features: {} };
    FEATURES.forEach(function (f) { out.features[f] = has(f); });
    return out;
  }

  root.BliziNative = { FEATURES: FEATURES, register: register, has: has, call: call, capabilities: capabilities, _reset: function () { impl = {}; } };
})(typeof window !== "undefined" ? window : this);
