(function (root) {
  "use strict";

  /*
   * BLIZI phone tools: registers the Capacitor plugin "BliziNativeBridge" as BliziTools entries,
   * so the one brain (the LLM) can act through the phone body. Installs nothing on the web.
   * Every tool resolves to a short plain string. Failures are returned as "error: <code>", never hidden.
   */

  var MAX_RESULT = 1500;
  var installed = false, plug = null, sleepFn = null;

  function defaultSleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

  function getPlugin(win) {
    var C = win && win.Capacitor;
    if (!C) return null;
    try { if (typeof C.isNativePlatform === "function" && !C.isNativePlatform()) return null; } catch (e) { return null; }
    try { if (C.Plugins && C.Plugins.BliziNativeBridge) return C.Plugins.BliziNativeBridge; } catch (e) {}
    try { if (typeof C.registerPlugin === "function") return C.registerPlugin("BliziNativeBridge"); } catch (e) {}
    return null;
  }

  function fmtNodes(nodes, max) {
    var lines = [], len = 0, i, n, label, flags, line, shown = 0;
    for (i = 0; i < nodes.length; i++) {
      n = nodes[i] || {};
      label = String(n.text || n.contentDescription || (n.viewId ? String(n.viewId).split("/").pop() : "") || n.className || "").replace(/\s+/g, " ").trim().slice(0, 50);
      flags = (n.isClickable ? "c" : "") + (n.isEditable ? "e" : "") + (n.isScrollable ? "s" : "");
      line = n.index + "|" + label + "|" + n.centerX + "," + n.centerY + (flags ? "|" + flags : "");
      if (len + line.length + 1 > max - 130) break;
      lines.push(line); len += line.length + 1; shown++;
    }
    if (!lines.length) return "screen is empty or unreadable";
    return "index|label|x,y|flags(c=clickable,e=editable,s=scrollable)\n" + lines.join("\n") + (shown < nodes.length ? "\n(+" + (nodes.length - shown) + " more items not shown)" : "");
  }

  function fail(r) { return "error: " + String(r && r.error ? r.error : "unknown_error"); }

  // Runs one plugin call; resolves a string. A rejected promise becomes "error: bridge_failed: ...".
  function via(method, args, okText, settleMs) {
    return Promise.resolve().then(function () { return plug[method](args || {}); }).then(function (r) {
      if (!r || r.ok !== true) return fail(r);
      var text = typeof okText === "function" ? okText(r) : okText;
      return settleMs ? sleepFn(settleMs).then(function () { return text; }) : text;
    }, function (e) {
      return "error: bridge_failed: " + String(e && e.message ? e.message : e).slice(0, 120);
    });
  }

  function define(T, opts) {
    var P = function (a) { return { type: "number", required: true, min: 0, max: 10000 }; };
    T.register({ name: "phone_status", description: "Check whether screen control and notification access are enabled", params: {},
      run: function () { return via("getStatus", {}, function (r) {
        return "screen_control=" + (r.accessibilityConnected ? "on" : "off") + (r.accessibilityEnabledInSettings && !r.accessibilityConnected ? " (enabled but not connected)" : "") +
          "; notification_access=" + (r.notificationListenerEnabled ? "on" : "off");
      }); } });
    T.register({ name: "open_settings", description: "Open the Android screen to enable screen control or notification access", params: { which: { type: "enum", values: ["accessibility", "notifications"], required: true } },
      run: function (a) { return via(a.which === "accessibility" ? "openAccessibilitySettings" : "openNotificationSettings", {}, "settings opened; the user must switch Blizi on", 0); } });
    T.register({ name: "open_app", description: "Open an installed app by name, e.g. WhatsApp", params: { name: { type: "string", required: true, max: 60 } },
      run: function (a) { return via("openApp", { name: a.name }, function (r) { return "opened " + (r.package || a.name); }, opts.settleLong); } });
    T.register({ name: "read_screen", description: "List what is visible on the phone screen with tap coordinates", params: {},
      run: function () {
        return Promise.resolve().then(function () { return plug.readScreen({}); }).then(function (r) {
          if (!r || r.ok !== true) return fail(r);
          return fmtNodes(Array.isArray(r.nodes) ? r.nodes : [], opts.maxResult);
        }, function (e) { return "error: bridge_failed: " + String(e && e.message ? e.message : e).slice(0, 120); });
      } });
    T.register({ name: "tap", description: "Tap the screen at x,y taken from read_screen", params: { x: P(), y: P() },
      run: function (a) { return via("tap", { x: a.x, y: a.y }, "tap sent (check read_screen to confirm it worked)", opts.settle); } });
    T.register({ name: "type_text", description: "Type text into the focused or first text field", params: { text: { type: "string", required: true, max: 300 } },
      run: function (a) { return via("typeText", { text: a.text }, "text entered", opts.settle); } });
    T.register({ name: "scroll", description: "Scroll the screen", params: { direction: { type: "enum", values: ["up", "down", "left", "right"], required: true } },
      run: function (a) { return via("scroll", { direction: a.direction }, "scrolled " + a.direction, opts.settle); } });
    T.register({ name: "press_key", description: "Press back, home, recents, notifications or enter", params: { key: { type: "enum", values: ["back", "home", "recents", "notifications", "enter"], required: true } },
      run: function (a) { return via("pressKey", { key: a.key }, "pressed " + a.key, opts.settle); } });
    T.register({ name: "read_notifications", description: "Read recent phone notifications (messages, mail)", params: { limit: { type: "number", min: 1, max: 20 } },
      run: function (a) {
        return Promise.resolve().then(function () { return plug.getNotifications({ limit: a.limit || 8 }); }).then(function (r) {
          if (!r || r.ok !== true) return fail(r);
          var l = Array.isArray(r.notifications) ? r.notifications : [];
          if (!l.length) return "no recent notifications";
          var out = l.map(function (n) { return String(n.package || "").split(".").pop() + "|" + String(n.title || "").slice(0, 40) + "|" + String(n.text || "").slice(0, 100); }).join("\n");
          return out.slice(0, opts.maxResult);
        }, function (e) { return "error: bridge_failed: " + String(e && e.message ? e.message : e).slice(0, 120); });
      } });
    T.register({ name: "compose_sms", description: "Open the SMS app with a message ready; the user taps Send", risk: "confirm",
      params: { number: { type: "string", required: true, max: 30 }, message: { type: "string", required: true, max: 300 } },
      describe: function (a) { return "Open a text to " + a.number + ": " + a.message; },
      run: function (a) { return via("composeSms", { number: a.number, message: a.message }, "SMS app opened with the message; NOT sent until the user taps Send", 0); } });
  }

  // Registers the tools when running inside the native app. Safe to call repeatedly.
  function install(o) {
    o = o || {};
    if (installed) return true;
    var T = o.tools || root.BliziTools;
    if (!T) return false;
    plug = o.plugin || getPlugin(o.win || root);
    if (!plug) return false;
    sleepFn = o.sleep || defaultSleep;
    var maxResult = o.maxResult || (root.BLIZI_CONFIG && root.BLIZI_CONFIG.maxToolResultChars) || MAX_RESULT;
    define(T, { maxResult: maxResult, settle: o.settle != null ? o.settle : 500, settleLong: o.settleLong != null ? o.settleLong : 1500 });
    installed = true;
    return true;
  }

  function active() { return installed || install(); }

  // Prompt block for the model. Only the phone tool list; the caller trims the base prompt to fit.
  function promptLine() {
    var T = root.BliziTools;
    if (!installed || !T) return "";
    return "You can operate this phone with tools. Request one with [[tool name {\"arg\":value}]] (max 3 per reply), then wait for the tool result. " +
      "Typical flow: open_app, read_screen, tap using x,y from read_screen, read_screen again to verify. If a tool says error: accessibility_not_enabled, use open_settings. " +
      "Never say an action worked unless a tool result confirms it. Only act when the user asks.\n" + T.manifest().replace(/^Tools \([^)]*\):\n/, "");
  }

  function fitSystem(base, max) {
    var extra = promptLine();
    if (!extra) return base;
    var room = Math.max(0, max - extra.length - 1);
    return String(base || "").slice(0, room) + "\n" + extra;
  }

  root.BliziNativeTools = { install: install, active: active, promptLine: promptLine, fitSystem: fitSystem, _fmtNodes: fmtNodes, _reset: function () { installed = false; plug = null; } };
})(typeof window !== "undefined" ? window : this);
