# BLIZI PWA icons

`blizi-192.png` and `blizi-512.png` are rasterized from the existing BLIZI SVG in `../index.html`; they do not introduce or replace character artwork. The 512px icon is also declared as maskable in the manifest. Regenerate only from the in-project character SVG if that art changes.
