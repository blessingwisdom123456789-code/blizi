(function (root) {
  "use strict";

  var SC = root.BliziCoreSchema, STORE = "relationship", PROFILE = SC ? SC.PROFILE_ID : "prof_main", ID = "rel_" + PROFILE;
  var RAPPORT_BASELINE = 0.5, RAPPORT_HALF_LIFE = 30 * 24 * 60 * 60 * 1000, MAX_HISTORY = 180, MAX_RITUALS = 32;
  function copy(value) { return SC ? SC.clone(value) : JSON.parse(JSON.stringify(value)); }
  function nowValue(now) { return typeof now === "function" ? now() : (now === undefined ? Date.now() : now); }
  function iso(value) { return new Date(value).toISOString(); }
  function clamp(value, min, max) { return Math.max(min, Math.min(max, Number(value) || 0)); }
  function pref(value, source, confidence) { return { value: String(value == null ? "" : value).slice(0, 120), source: source === "inferred" ? "inferred" : "stated", confidence: clamp(confidence === undefined ? (source === "stated" ? 1 : 0.5) : confidence, 0, 1) }; }
  function emptyRecord(at) {
    var time = iso(at);
    return { id: ID, profileId: PROFILE, identityId: "idn_main", familiarity: 0, weightedSessions: 0, rapport: RAPPORT_BASELINE, trust: { score: 0.5, basis: { kept: 0, broken: 0 } }, communication: { tone: pref("friendly", "stated", 1), voice: pref("browser", "stated", 1) }, addressing: { userCalledBy: pref("", "stated", 1) }, typicalActiveHours: Array(24).fill(0), quietHours: { start: 22, end: 7 }, interactionHistory: [], timeline: [], rituals: [], people: [], autonomy: { userCap: 0.5, earnedLevel: 0, level: 0, formula: "min(userCap, earnedLevel)", basis: { familiarity: 0, trust: 0.5 } }, lastSessionAt: null, createdAt: time, updatedAt: time };
  }
  function getPath(object, path) { return path.split(".").reduce(function (value, key) { return value == null ? undefined : value[key]; }, object); }
  function setPath(object, path, value) { var keys = path.split("."), target = object; keys.slice(0, -1).forEach(function (key) { if (!target[key] || typeof target[key] !== "object") target[key] = {}; target = target[key]; }); target[keys[keys.length - 1]] = value; }
  function legacyValues(source) {
    if (!source) return {};
    function read(key) { try { return typeof source.getItem === "function" ? source.getItem(key) : source[key]; } catch (_) { return source[key]; } }
    var settings = read("blizi.settings"), manus = read("blizi.settings.manus.v1");
    try { settings = typeof settings === "string" ? JSON.parse(settings) : (settings || {}); } catch (_) { settings = {}; }
    try { manus = typeof manus === "string" ? JSON.parse(manus) : (manus || {}); } catch (_) { manus = {}; }
    return { name: settings.name || manus.name || "", persona: settings.persona || manus.persona || "friendly", voice: settings.voice || (settings.speak === false ? "off" : "browser") };
  }
  function actionPatch(action, data) { return { kind: "relationship_" + action, state: JSON.stringify(data || {}).slice(0, 240) }; }
  function ritualId() { return "rit_" + (SC ? SC.makeId("people").slice(7) : Math.random().toString(36).slice(2, 14)); }

  function create(options) {
    options = options || {};
    var adapter = options.adapter, events = options.events, identity = options.identity, mood = options.mood, profileId = options.profileId || PROFILE, now = options.now, current = null, opened = false, isNew = false, listeners = [];
    if (!adapter) throw SC.error("storage_required");
    function notify() { var value = copy(current); listeners.slice().forEach(function (fn) { try { fn(value); } catch (_) {} }); }
    function updateDerived(record, at) {
      var days = record.lastSessionAt ? Math.max(0, at - Date.parse(record.lastSessionAt)) : 0;
      record.rapport = RAPPORT_BASELINE + (record.rapport - RAPPORT_BASELINE) * Math.pow(0.5, days / RAPPORT_HALF_LIFE);
      var familiarity = clamp(record.familiarity, 0, 1), trust = clamp(record.trust && record.trust.score, 0, 1), cap = clamp(record.autonomy && record.autonomy.userCap, 0, 1);
      var earned = clamp(familiarity * 0.6 + trust * 0.4, 0, 1);
      record.autonomy = { userCap: cap, earnedLevel: earned, level: Math.min(cap, earned), formula: "min(userCap, earnedLevel)", basis: { familiarity: familiarity, trust: trust } };
      record.updatedAt = iso(at);
      return record;
    }
    async function persist(action, data, at, actor) {
      updateDerived(current, at);
      if (events) await events.mutate({ store: STORE, op: isNew ? "create" : "update", actor: actor || (action === "preference" || action === "ritual" || action === "autonomy_cap" ? "user" : "system"), id: ID, record: current, patch: actionPatch(action, data) });
      else await adapter.put(STORE, current);
      isNew = false;
      notify();
      return copy(current);
    }
    async function open() {
      if (opened) return copy(current);
      current = await adapter.get(STORE, ID);
      var at = nowValue(now);
      if (!current) {
        current = emptyRecord(at); isNew = true;
        var legacy = legacyValues(options.legacyStorage ? options.legacyStorage() : options.legacy);
        if (legacy.name) current.addressing.userCalledBy = pref(legacy.name, "stated", 1);
        current.communication.tone = pref(legacy.persona, "stated", 1); current.communication.voice = pref(legacy.voice, "stated", 1);
        if (identity && identity.get) { var identityRecord = await identity.get(); current.identityId = identityRecord.id; }
        await persist("seed", { profileId: profileId }, at);
      }
      current.interactionHistory = current.interactionHistory || current.timeline || [];
      current.timeline = current.interactionHistory;
      current.rituals = current.rituals || [];
      if (!current.autonomy) current.autonomy = { userCap: 0.5 };
      if (current.profileId !== profileId) throw SC.error("profile_mismatch");
      opened = true;
      return copy(current);
    }
    async function get() { await open(); return copy(updateDerived(current, nowValue(now))); }
    async function setPreference(key, value, metadata) {
      await open(); metadata = metadata || {}; var existing = getPath(current, key), incoming = pref(value, metadata.source, metadata.confidence);
      if (existing && existing.source === "stated" && incoming.source === "inferred") return copy(current);
      setPath(current, key, incoming); return persist("preference", { key: key, source: incoming.source }, nowValue(now), "user");
    }
    async function recordSession(at) {
      await open(); at = nowValue(at); var hour = new Date(at).getHours(), weight = 1, entry = { type: "session", at: iso(at), weight: weight };
      current.weightedSessions += weight; current.familiarity = 1 - Math.exp(-0.08 * current.weightedSessions); current.typicalActiveHours[hour] = (current.typicalActiveHours[hour] || 0) + 1;
      current.rapport = clamp(current.rapport + 0.015, 0, 1); current.lastSessionAt = iso(at); current.interactionHistory = (current.interactionHistory || []).concat([entry]).slice(-MAX_HISTORY); current.timeline = current.interactionHistory;
      if (mood && mood.addCause) mood.addCause({ type: "session", ref: ID, delta: { valence: 0.015, arousal: 0.01 }, labelHint: "happy", note: "relationship session", halfLifeMs: 12 * 60 * 60 * 1000 }).catch(function () {});
      return persist("session", { at: at, weight: weight }, at);
    }
    async function recordInteraction(type, details, at) {
      await open(); at = nowValue(at); var entry = { type: String(type || "interaction").slice(0, 40), at: iso(at), details: copy(details || {}) };
      current.interactionHistory = (current.interactionHistory || []).concat([entry]).slice(-MAX_HISTORY); current.timeline = current.interactionHistory;
      return persist("interaction", { type: entry.type }, at);
    }
    async function isQuietNow(at) { await open(); at = nowValue(at); var hour = new Date(at).getHours(), start = current.quietHours.start, end = current.quietHours.end; return start > end ? hour >= start || hour < end : hour >= start && hour < end; }
    async function recordPromise(kept) { await open(); var key = kept ? "kept" : "broken"; current.trust.basis[key] = (current.trust.basis[key] || 0) + 1; var total = current.trust.basis.kept + current.trust.basis.broken; current.trust.score = total ? clamp(0.5 + (current.trust.basis.kept - current.trust.basis.broken) / (2 * total), 0, 1) : 0.5; return persist("promise", { kept: !!kept }, nowValue(now)); }
    async function setAutonomyCap(value) { await open(); current.autonomy.userCap = clamp(value, 0, 1); return persist("autonomy_cap", { value: current.autonomy.userCap }, nowValue(now), "user"); }
    function autonomyDetails() { var a = current && current.autonomy || { userCap: 0.5, earnedLevel: 0, level: 0, formula: "min(userCap, earnedLevel)", basis: { familiarity: 0, trust: 0.5 } }; return copy(a); }
    async function explain() { await open(); await get(); return { profileId: profileId, autonomy: autonomyDetails(), familiarity: current.familiarity, rapport: current.rapport, trust: copy(current.trust), interactionCount: (current.interactionHistory || []).length, ritualCount: (current.rituals || []).length }; }
    async function addRitual(ritual) { await open(); if (current.rituals.length >= MAX_RITUALS) throw SC.error("ritual_limit"); var item = copy(ritual || {}); item.id = item.id || ritualId(); item.name = String(item.name || "").slice(0, 120); item.cadence = String(item.cadence || "daily").slice(0, 40); item.preferredHour = Math.max(0, Math.min(23, Number(item.preferredHour) || 0)); item.enabled = item.enabled !== false; item.createdAt = iso(nowValue(now)); current.rituals.push(item); return persist("ritual", { op: "add", id: item.id }, nowValue(now), "user"); }
    async function updateRitual(id, patch) { await open(); var item = current.rituals.filter(function (r) { return r.id === id; })[0]; if (!item) throw SC.error("ritual_not_found"); Object.keys(patch || {}).forEach(function (key) { if (key !== "id") item[key] = copy(patch[key]); }); return persist("ritual", { op: "update", id: id }, nowValue(now), "user"); }
    async function removeRitual(id) { await open(); current.rituals = current.rituals.filter(function (r) { return r.id !== id; }); return persist("ritual", { op: "remove", id: id }, nowValue(now), "user"); }
    async function recordRitual(id, at) { await open(); var item = current.rituals.filter(function (r) { return r.id === id; })[0]; if (!item) throw SC.error("ritual_not_found"); item.lastPerformedAt = iso(nowValue(at)); item.performances = (item.performances || 0) + 1; return persist("ritual", { op: "perform", id: id }, nowValue(at), "user"); }
    async function addPerson(person) { await open(); var item = copy(person || {}); item.id = item.id || SC.makeId("people", { now: nowValue(now) }); item.name = String(item.name || "").slice(0, 120); current.people.push(item); return persist("person", { op: "add", id: item.id }, nowValue(now), "user"); }
    async function updatePerson(id, patch) { await open(); var item = current.people.filter(function (p) { return p.id === id; })[0]; if (!item) throw SC.error("person_not_found"); Object.keys(patch || {}).forEach(function (key) { if (key !== "id") item[key] = copy(patch[key]); }); return persist("person", { op: "update", id: id }, nowValue(now), "user"); }
    async function removePerson(id) { await open(); current.people = current.people.filter(function (p) { return p.id !== id; }); return persist("person", { op: "remove", id: id }, nowValue(now), "user"); }
    function onChange(fn) { if (typeof fn !== "function") return function () {}; listeners.push(fn); return function () { listeners = listeners.filter(function (item) { return item !== fn; }); }; }
    function autonomy() { return autonomyDetails().level; }
    return { open: open, get: get, setPreference: setPreference, recordSession: recordSession, recordInteraction: recordInteraction, isQuietNow: isQuietNow, autonomy: autonomy, autonomyDetails: autonomyDetails, setAutonomyCap: setAutonomyCap, explain: explain, recordPromise: recordPromise, onChange: onChange, people: { add: addPerson, update: updatePerson, remove: removePerson }, rituals: { add: addRitual, update: updateRitual, remove: removeRitual, record: recordRitual } };
  }
  root.BliziRelationship = { create: create };
})(typeof window !== "undefined" ? window : globalThis);
