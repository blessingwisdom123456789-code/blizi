(function (root) {
  "use strict";

  var FACE_ALIASES = {
    neutral: "neutral", normal: "neutral", calm: "neutral",
    happy: "happy", smile: "happy", smiling: "happy", cheerful: "happy", grin: "happy",
    excited: "excited", excitedly: "excited",
    embarrassed: "embarrassed", shy: "embarrassed", bashful: "embarrassed",
    confused: "confused", puzzled: "confused",
    sad: "sad", unhappy: "sad", sorrowful: "sad",
    angry: "angry", mad: "angry", annoyed: "angry",
    thinking: "thinking", thoughtful: "thinking",
    sleepy: "sleepy", tired: "sleepy",
    surprised: "surprised", shocked: "surprised",
    serious: "serious", stern: "serious"
  };
  var ACTIONS = {
    "stop talking": "stop-speaking", "stop speaking": "stop-speaking", "be quiet": "stop-speaking",
    mute: "mute", "stay quiet": "mute", "stay silent": "mute",
    speak: "speak", unmute: "speak", "talk again": "speak"
  };

  function clean(text) { return typeof text === "string" ? text.toLowerCase().replace(/[!?.,;:]+/g, " ").replace(/\s+/g, " ").trim() : ""; }
  function isQuestionAboutCurrentFace(text) { return /^(why|what|how)\b[^.?!]*\b(face|expression|look)\b/.test(text); }
  function findAlias(text) {
    var names = Object.keys(FACE_ALIASES).sort(function (a, b) { return b.length - a.length; });
    for (var i = 0; i < names.length; i++) if (new RegExp("\\b" + names[i].replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "\\b").test(text)) return FACE_ALIASES[names[i]];
    return null;
  }
  function detect(raw) {
    var text = clean(raw);
    if (!text || isQuestionAboutCurrentFace(text)) return null;
    for (var action in ACTIONS) if (Object.prototype.hasOwnProperty.call(ACTIONS, action) && new RegExp("\\b" + action + "\\b").test(text)) return { kind: "action", action: ACTIONS[action], phrase: action };

    var explicitFace = /\b(face|facial expression|expression|look|looks|looking)\b/.test(text);
    var direct = /\b(smile|smiling|grin|happy|sad|angry|mad|excited|embarrassed|confused|puzzled|sleepy|tired|surprised|shocked|serious|stern|thinking|thoughtful|neutral|calm)\b/.test(text);
    if (!explicitFace && !direct) return null;
    if (/\b(i|i am|i'm|my|the)\b[^.?!]*\bserious\s+(mistake|error|problem|issue|matter)\b/.test(text)) return null;

    var requested = findAlias(text);
    if (requested) return { kind: "expression", expression: requested, requested: requested, phrase: text };
    if (explicitFace || /\b(make|show|give|put on|wear|be|look)\b/.test(text)) {
      var unknown = text.match(/\b([a-z]+)\s+(?:face|expression|look)\b/);
      return { kind: "expression", expression: null, requested: unknown ? unknown[1] : null, phrase: text };
    }
    return null;
  }

  root.BliziBodyIntent = { detect: detect, aliases: Object.freeze(Object.assign({}, FACE_ALIASES)), actions: Object.freeze(Object.assign({}, ACTIONS)) };
})(typeof window !== "undefined" ? window : globalThis);
