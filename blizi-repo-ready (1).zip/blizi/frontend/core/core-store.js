(function (root) {
  "use strict";

  var SC = root.BliziCoreSchema;
  if (!SC) throw new Error("core_schema_required");

  function error(code, message) { return SC.error(code, message || code); }
  function copy(value) { return SC.clone(value); }
  function own(object, key) { return Object.prototype.hasOwnProperty.call(object, key); }
  function keyOf(storeName, record) {
    var def = SC.definition(storeName);
    return record && record[def.keyPath];
  }
  function emptyData() {
    var data = Object.create(null);
    SC.STORE_NAMES.forEach(function (name) { data[name] = []; });
    return data;
  }
  function matchRecord(record, options) {
    options = options || {};
    if (options.profileId && record.profileId !== options.profileId) return false;
    if (typeof options.predicate === "function" && !options.predicate(copy(record))) return false;
    return true;
  }
  function sortRecords(rows, options) {
    options = options || {};
    if (options.sortBy) {
      var key = options.sortBy, direction = options.direction === "desc" ? -1 : 1;
      rows.sort(function (a, b) {
        var av = a[key], bv = b[key];
        if (av === bv) return 0;
        if (av === undefined || av === null) return 1;
        if (bv === undefined || bv === null) return -1;
        return (av < bv ? -1 : 1) * direction;
      });
    }
    if (options.limit !== undefined) rows = rows.slice(0, Math.max(0, Math.floor(Number(options.limit) || 0)));
    return rows;
  }
  function estimateRows(data) {
    var records = 0, text = JSON.stringify(data);
    SC.STORE_NAMES.forEach(function (name) { records += (data[name] || []).length; });
    return { records: records, bytes: typeof TextEncoder === "function" ? new TextEncoder().encode(text).length : text.length * 2 };
  }
  function nextSequence(data) {
    var max = 0;
    (data.eventlog || []).forEach(function (row) { if (Number(row.seq) > max) max = Number(row.seq); });
    return max + 1;
  }

  function visibleRecord(name, row, profileId) {
    var def = SC.definition(name);
    return !!row && (def.global === true || row.profileId === profileId);
  }

  function mapApi(data, mode, seqRef, allowedNames, profileId) {
    function checkAllowed(name) {
      SC.definition(name);
      if (allowedNames.indexOf(name) < 0) throw error("store_not_in_transaction", "Object store was not included in transaction");
    }
    function checkStore(name) {
      checkAllowed(name);
      if (!data[name]) data[name] = [];
      if (mode === "readonly") throw error("readonly_transaction", "Cannot write in a readonly transaction");
    }
    function findIndex(name, key) {
      var field = SC.definition(name).keyPath, rows = data[name] || [];
      for (var i = 0; i < rows.length; i++) if (rows[i][field] === key) return i;
      return -1;
    }
    function normalized(name, record, adding) {
      var result = copy(record);
      if (name === "eventlog") {
        if (result.seq === undefined && adding) result.seq = seqRef.value++;
        else if (Number.isSafeInteger(result.seq) && result.seq >= seqRef.value) seqRef.value = result.seq + 1;
      }
      SC.validateRecord(name, result, profileId);
      return result;
    }
    return {
      get: function (name, key) { checkAllowed(name); var i = findIndex(name, key), row = i < 0 ? undefined : data[name][i]; return visibleRecord(name, row, profileId) ? copy(row) : undefined; },
      getAll: function (name) { checkAllowed(name); return (data[name] || []).filter(function (row) { return visibleRecord(name, row, profileId); }).map(copy); },
      put: function (name, record) {
        checkStore(name);
        var row = normalized(name, record, false), key = keyOf(name, row), i = findIndex(name, key);
        if (key === undefined || key === null) throw error("invalid_key", "Record has no storage key");
        if (i < 0) data[name].push(row); else data[name][i] = row;
        return copy(row);
      },
      add: function (name, record) {
        checkStore(name);
        var row = normalized(name, record, true), key = keyOf(name, row);
        if (key === undefined || key === null) throw error("invalid_key", "Record has no storage key");
        if (findIndex(name, key) >= 0) throw error("duplicate_key", "Record key already exists");
        data[name].push(row);
        return copy(row);
      },
      delete: function (name, key) {
        checkStore(name);
        var i = findIndex(name, key);
        if (i >= 0) data[name].splice(i, 1);
        return i >= 0;
      },
      clear: function (name) { checkStore(name); data[name] = []; return true; }
    };
  }

  function MemoryAdapter(options) {
    options = options || {};
    this.kind = "memory";
    this.profileId = options.profileId || SC.PROFILE_ID;
    this._data = emptyData();
    this._seq = 1;
    this._opened = false;
  }
  MemoryAdapter.prototype.open = async function () { this._opened = true; return this; };
  MemoryAdapter.prototype.close = function () { this._opened = false; };
  MemoryAdapter.prototype.transaction = async function (names, mode, callback) {
    names = Array.from(new Set(names || []));
    names.forEach(function (name) { SC.definition(name); });
    mode = mode || "readonly";
    var write = mode !== "readonly", data = write ? copy(this._data) : this._data, seq = { value: this._seq };
    var api = mapApi(data, mode, seq, names, this.profileId);
    var result = await callback(api);
    if (write) { this._data = data; this._seq = seq.value; }
    return result;
  };
  MemoryAdapter.prototype.get = function (name, key) { var self = this; return this.transaction([name], "readonly", function (tx) { return tx.get(name, key); }); };
  MemoryAdapter.prototype.getAll = function (name) { return this.transaction([name], "readonly", function (tx) { return tx.getAll(name); }); };
  MemoryAdapter.prototype.query = async function (name, options) {
    var rows = await this.getAll(name);
    rows = rows.filter(function (row) { return matchRecord(row, options); });
    return sortRecords(rows, options).map(copy);
  };
  MemoryAdapter.prototype.put = function (name, row) { return this.transaction([name], "readwrite", function (tx) { return tx.put(name, row); }); };
  MemoryAdapter.prototype.add = function (name, row) { return this.transaction([name], "readwrite", function (tx) { return tx.add(name, row); }); };
  MemoryAdapter.prototype.delete = function (name, key) { return this.transaction([name], "readwrite", function (tx) { return tx.delete(name, key); }); };
  MemoryAdapter.prototype.clear = function (name) { return this.transaction([name], "readwrite", function (tx) { return tx.clear(name); }); };
  MemoryAdapter.prototype.count = async function (name, options) { return (await this.query(name, options)).length; };
  MemoryAdapter.prototype.estimate = async function () { return estimateRows(this._data); };
  MemoryAdapter.prototype.tx = MemoryAdapter.prototype.transaction;

  function LocalStorageAdapter(storage, options) {
    options = options || {};
    this.kind = "localStorage";
    this.storage = storage;
    this.profileId = options.profileId || SC.PROFILE_ID;
    this.key = options.key || "blizi.core.fallback.v1";
    this.maxBytes = Math.max(65536, Number(options.maxBytes) || 2 * 1024 * 1024);
    this._opened = false;
  }
  LocalStorageAdapter.prototype._read = function () {
    var raw;
    try { raw = this.storage && this.storage.getItem(this.key); }
    catch (e) { throw error("storage_unavailable", "Local storage cannot be read"); }
    if (!raw) return emptyData();
    var parsed;
    try { parsed = JSON.parse(raw); } catch (e) { throw error("corrupt_fallback", "Core fallback data is invalid JSON"); }
    if (!parsed || parsed.version !== 1 || !parsed.stores || typeof parsed.stores !== "object") throw error("corrupt_fallback", "Core fallback format is not supported");
    var data = emptyData();
    SC.STORE_NAMES.forEach(function (name) { if (Array.isArray(parsed.stores[name])) data[name] = parsed.stores[name].map(copy); });
    return data;
  };
  LocalStorageAdapter.prototype._write = function (data) {
    if (!this.storage || typeof this.storage.setItem !== "function") throw error("storage_unavailable", "Local storage cannot be written");
    var raw = JSON.stringify({ version: 1, stores: data });
    var byteLength = typeof TextEncoder === "function" ? new TextEncoder().encode(raw).length : raw.length * 2;
    if (byteLength > this.maxBytes) throw error("quota_exceeded", "Core localStorage fallback is full");
    try { this.storage.setItem(this.key, raw); }
    catch (e) { throw error("quota_exceeded", "Core localStorage fallback could not be saved"); }
    return byteLength;
  };
  LocalStorageAdapter.prototype.open = async function () { this._read(); this._opened = true; return this; };
  LocalStorageAdapter.prototype.close = function () { this._opened = false; };
  LocalStorageAdapter.prototype.transaction = async function (names, mode, callback) {
    names = Array.from(new Set(names || []));
    names.forEach(function (name) { SC.definition(name); });
    mode = mode || "readonly";
    var write = mode !== "readonly", data = this._read(), seq = { value: nextSequence(data) };
    var result = await callback(mapApi(data, mode, seq, names, this.profileId));
    if (write) this._write(data);
    return result;
  };
  LocalStorageAdapter.prototype.get = function (name, key) { return this.transaction([name], "readonly", function (tx) { return tx.get(name, key); }); };
  LocalStorageAdapter.prototype.getAll = function (name) { return this.transaction([name], "readonly", function (tx) { return tx.getAll(name); }); };
  LocalStorageAdapter.prototype.query = async function (name, options) {
    var rows = await this.getAll(name);
    rows = rows.filter(function (row) { return matchRecord(row, options); });
    return sortRecords(rows, options).map(copy);
  };
  LocalStorageAdapter.prototype.put = function (name, row) { return this.transaction([name], "readwrite", function (tx) { return tx.put(name, row); }); };
  LocalStorageAdapter.prototype.add = function (name, row) { return this.transaction([name], "readwrite", function (tx) { return tx.add(name, row); }); };
  LocalStorageAdapter.prototype.delete = function (name, key) { return this.transaction([name], "readwrite", function (tx) { return tx.delete(name, key); }); };
  LocalStorageAdapter.prototype.clear = function (name) { return this.transaction([name], "readwrite", function (tx) { return tx.clear(name); }); };
  LocalStorageAdapter.prototype.count = async function (name, options) { return (await this.query(name, options)).length; };
  LocalStorageAdapter.prototype.estimate = async function () { return estimateRows(this._read()); };
  LocalStorageAdapter.prototype.tx = LocalStorageAdapter.prototype.transaction;

  function requestValue(request) {
    return new Promise(function (resolve, reject) {
      request.onsuccess = function () { resolve(request.result); };
      request.onerror = function () { reject(request.error || error("indexeddb_request_failed")); };
    });
  }
  function IndexedDbAdapter(indexedDB, options) {
    options = options || {};
    this.kind = "indexedDB";
    this.indexedDB = indexedDB;
    this.profileId = options.profileId || SC.PROFILE_ID;
    this.name = options.name || SC.DATABASE_NAME;
    this.version = Number(options.version) || SC.DATABASE_VERSION;
    this.db = null;
  }
  IndexedDbAdapter.prototype.open = function () {
    var self = this;
    if (!this.indexedDB || typeof this.indexedDB.open !== "function") return Promise.reject(error("indexeddb_unavailable"));
    return new Promise(function (resolve, reject) {
      var request;
      try { request = self.indexedDB.open(self.name, self.version); }
      catch (e) { reject(error("indexeddb_open_failed", "IndexedDB could not be opened")); return; }
      request.onupgradeneeded = function () {
        var db = request.result;
        SC.STORE_DEFS.forEach(function (def) {
          if (!db.objectStoreNames.contains(def.name)) db.createObjectStore(def.name, { keyPath: def.keyPath, autoIncrement: !!def.autoIncrement });
        });
      };
      request.onblocked = function () { reject(error("indexeddb_blocked", "Close other BLIZI tabs to finish local storage setup")); };
      request.onerror = function () { reject(error("indexeddb_open_failed", "IndexedDB could not be opened")); };
      request.onsuccess = function () {
        self.db = request.result;
        self.db.onversionchange = function () { self.db.close(); self.db = null; };
        resolve(self);
      };
    });
  };
  IndexedDbAdapter.prototype.close = function () { if (this.db) this.db.close(); this.db = null; };
  IndexedDbAdapter.prototype.transaction = async function (names, mode, callback) {
    var self = this; // without this, a browser's global `self` (window) has no profileId and every read returned nothing
    if (!this.db) throw error("indexeddb_closed", "IndexedDB is not open");
    names = Array.from(new Set(names || []));
    if (!names.length) throw error("empty_transaction", "At least one object store is required");
    names.forEach(function (name) { SC.definition(name); });
    var native;
    try { native = this.db.transaction(names, mode || "readonly"); }
    catch (e) { throw error("indexeddb_transaction_failed", "IndexedDB transaction could not start"); }
    var done = new Promise(function (resolve, reject) {
      native.oncomplete = function () { resolve(); };
      native.onabort = native.onerror = function () { reject(native.error || error("indexeddb_transaction_failed", "IndexedDB transaction failed")); };
    });
    function objectStore(name) {
      if (names.indexOf(name) < 0) throw error("store_not_in_transaction", "Object store was not included in transaction");
      return native.objectStore(name);
    }
    var txApi = {
      get: function (name, key) { SC.definition(name); return requestValue(objectStore(name).get(key)).then(function (row) { return visibleRecord(name, row, self.profileId) ? copy(row) : undefined; }); },
      getAll: function (name) { SC.definition(name); return requestValue(objectStore(name).getAll()).then(function (rows) { return rows.filter(function (row) { return visibleRecord(name, row, self.profileId); }).map(copy); }); },
      put: function (name, row) { SC.validateRecord(name, row, self.profileId); return requestValue(objectStore(name).put(copy(row))); },
      add: function (name, row) {
        var item = copy(row);
        if (name === "eventlog" && item.seq === undefined) delete item.seq;
        SC.validateRecord(name, item, self.profileId);
        return requestValue(objectStore(name).add(item)).then(function (key) { if (name === "eventlog") item.seq = key; return copy(item); });
      },
      delete: function (name, key) { SC.definition(name); return requestValue(objectStore(name).delete(key)).then(function () { return true; }); },
      clear: function (name) { SC.definition(name); return requestValue(objectStore(name).clear()).then(function () { return true; }); }
    };
    var result;
    try {
      result = callback(txApi);
      result = await result;
      await done;
      return result;
    } catch (e) {
      try { native.abort(); } catch (_) {}
      try { await done; } catch (_) {}
      throw e;
    }
  };
  IndexedDbAdapter.prototype.get = function (name, key) { return this.transaction([name], "readonly", function (tx) { return tx.get(name, key); }); };
  IndexedDbAdapter.prototype.getAll = function (name) { return this.transaction([name], "readonly", function (tx) { return tx.getAll(name); }); };
  IndexedDbAdapter.prototype.query = async function (name, options) {
    var rows = await this.getAll(name);
    rows = rows.filter(function (row) { return matchRecord(row, options); });
    return sortRecords(rows, options).map(copy);
  };
  IndexedDbAdapter.prototype.put = function (name, row) { return this.transaction([name], "readwrite", function (tx) { return tx.put(name, row); }); };
  IndexedDbAdapter.prototype.add = function (name, row) { return this.transaction([name], "readwrite", function (tx) { return tx.add(name, row); }); };
  IndexedDbAdapter.prototype.delete = function (name, key) { return this.transaction([name], "readwrite", function (tx) { return tx.delete(name, key); }); };
  IndexedDbAdapter.prototype.clear = function (name) { return this.transaction([name], "readwrite", function (tx) { return tx.clear(name); }); };
  IndexedDbAdapter.prototype.count = function (name, options) { return this.query(name, options).then(function (rows) { return rows.length; }); };
  IndexedDbAdapter.prototype.estimate = async function () {
    try {
      var estimate = root.navigator && root.navigator.storage && root.navigator.storage.estimate ? await root.navigator.storage.estimate() : null;
      return { records: null, bytes: estimate && Number(estimate.usage) || null, quotaBytes: estimate && Number(estimate.quota) || null };
    } catch (e) { return { records: null, bytes: null, quotaBytes: null }; }
  };
  IndexedDbAdapter.prototype.tx = IndexedDbAdapter.prototype.transaction;

  function createBrowserAdapter(options) {
    options = options || {};
    var idb = options.indexedDB;
    if (idb === undefined) { try { idb = root.indexedDB; } catch (e) { idb = null; } }
    var local = options.localStorage;
    if (local === undefined) { try { local = root.localStorage; } catch (e) { local = null; } }
    var indexedDBOptions = Object.assign({}, options.indexedDBOptions || {}), localStorageOptions = Object.assign({}, options.localStorageOptions || {});
    if (options.profileId) { indexedDBOptions.profileId = options.profileId; localStorageOptions.profileId = options.profileId; }
    if (idb && typeof idb.open === "function") return new IndexedDbAdapter(idb, indexedDBOptions);
    if (local) return new LocalStorageAdapter(local, localStorageOptions);
    return new MemoryAdapter({ profileId: options.profileId });
  }

  root.BliziCoreStore = {
    MemoryAdapter: MemoryAdapter,
    IndexedDbAdapter: IndexedDbAdapter,
    LocalStorageAdapter: LocalStorageAdapter,
    createBrowserAdapter: createBrowserAdapter
  };
})(window);
