(function (root) {
  "use strict";

  var SC = root.BliziCoreSchema;
  var OPS = ["create", "update", "delete", "import", "restore"];
  var ACTORS = ["user", "blizi", "system", "migration"];
  var PATCH_FIELDS = ["state", "revision", "source", "kind", "schemaVersion", "fields", "status", "count"];

  function eventError(code, message) { return SC.error(code, message || code); }
  function cleanPatch(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) throw eventError("invalid_event_patch");
    var patch = {};
    Object.keys(value).forEach(function (key) {
      if (PATCH_FIELDS.indexOf(key) < 0) throw eventError("invalid_event_patch");
      var item = value[key];
      if (key === "fields") {
        if (!Array.isArray(item) || item.length > 32 || item.some(function (field) { return typeof field !== "string" || field.length > 80; })) throw eventError("invalid_event_patch");
        patch[key] = item.slice();
      } else if (typeof item === "string" && item.length <= 120 || typeof item === "boolean" || typeof item === "number" && Number.isFinite(item)) patch[key] = item;
      else throw eventError("invalid_event_patch");
    });
    if (JSON.stringify(patch).length > 2048) throw eventError("event_patch_too_large");
    return patch;
  }
  function cleanEvent(input, options) {
    options = options || {};
    input = input || {};
    var op = String(input.op || "").toLowerCase();
    var actor = String(input.actor || "system").toLowerCase();
    var store = String(input.store || "");
    SC.definition(store);
    if (store === "eventlog" || store === "meta" || store === "snapshots") throw eventError("invalid_event_target");
    if (OPS.indexOf(op) < 0) throw eventError("invalid_event_operation");
    if (ACTORS.indexOf(actor) < 0) throw eventError("invalid_event_actor");
    var id = String(input.id || "");
    if (!id) throw eventError("invalid_event_id");
    var profileId = input.profileId || options.profileId || SC.PROFILE_ID;
    if (profileId !== SC.PROFILE_ID) throw eventError("profile_mismatch");
    var at = input.at || new Date(typeof options.now === "function" ? options.now() : Date.now()).toISOString();
    var summary = String(input.summary || "").trim().slice(0, 240);
    var event = { at: at, actor: actor, op: op, store: store, id: id, profileId: profileId, summary: summary };
    // Event patches are opt-in metadata only; delete entries never retain record content.
    if (op !== "delete" && input.patch !== undefined && input.patch !== null) {
      event.patch = cleanPatch(input.patch);
    }
    return event;
  }

  function create(adapter, options) {
    options = options || {};
    if (!adapter) throw eventError("storage_required");
    var profileId = options.profileId || SC.PROFILE_ID;
    async function append(input) {
      var event = cleanEvent(input, { profileId: profileId, now: options.now });
      var saved;
      await adapter.transaction(["eventlog"], "readwrite", async function (tx) {
        saved = await tx.add("eventlog", event);
      });
      return saved;
    }
    async function mutate(input) {
      input = input || {};
      var event = cleanEvent(input, { profileId: profileId, now: options.now });
      var store = event.store, op = event.op, id = event.id;
      var saved;
      await adapter.transaction([store, "eventlog"], "readwrite", async function (tx) {
        if (op === "delete") await tx.delete(store, id);
        else if (op === "create" || op === "update" || op === "import" || op === "restore") {
          if (!input.record) throw eventError("record_required");
          SC.validateRecord(store, input.record, profileId);
          if (input.record.id !== id) throw eventError("event_record_id_mismatch");
          await tx.put(store, input.record);
        }
        saved = await tx.add("eventlog", event);
      });
      return saved;
    }
    return {
      append: append,
      mutate: mutate,
      list: function (query) { return adapter.query("eventlog", Object.assign({ profileId: profileId, sortBy: "seq", direction: "asc" }, query || {})); }
    };
  }

  root.BliziCoreEvents = { create: create, cleanEvent: cleanEvent };
})(window);
