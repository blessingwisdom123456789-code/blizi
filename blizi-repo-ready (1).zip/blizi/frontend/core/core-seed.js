(function (root) {
  "use strict";

  var PROFILE_ID = root.BliziCoreSchema ? root.BliziCoreSchema.PROFILE_ID : "prof_main";
  var MANIFEST = {
    seedVersion: 1,
    profileId: PROFILE_ID,
    identityId: "idn_main",
    character: {
      name: "Blizi",
      personalitySource: "config/blizi-personality.txt"
    },
    legacyMappings: [
      { from: "settings.name", targetHint: "addressing.userCalledBy", source: "stated" },
      { from: "settings.persona", targetHint: "communication.tone", source: "stated" },
      { from: "settings.speak", targetHint: "communication.voice.enabled", source: "stated" },
      { from: "settings.voice", targetHint: "communication.voice.id", source: "stated" }
    ]
  };

  function clone(value) {
    return root.BliziCoreSchema ? root.BliziCoreSchema.clone(value) : JSON.parse(JSON.stringify(value));
  }

  function projectLegacySettings(settings) {
    settings = settings && typeof settings === "object" && !Array.isArray(settings) ? settings : {};
    var candidate = {};
    if (typeof settings.name === "string" && settings.name.trim()) candidate.userCalledBy = settings.name.trim().slice(0, 80);
    if (typeof settings.persona === "string" && settings.persona.trim()) candidate.tone = settings.persona.trim().slice(0, 80);
    if (Object.prototype.hasOwnProperty.call(settings, "speak") || Object.prototype.hasOwnProperty.call(settings, "voice")) {
      candidate.voice = {};
      if (typeof settings.speak === "boolean") candidate.voice.enabled = settings.speak;
      if (typeof settings.voice === "string") candidate.voice.id = settings.voice.slice(0, 80);
    }
    return {
      seedVersion: MANIFEST.seedVersion,
      profileId: PROFILE_ID,
      identityId: MANIFEST.identityId,
      candidateValues: candidate,
      mappingVersion: "legacy-settings-v1",
      canonicalSchemaApplied: false
    };
  }

  root.BliziCoreSeed = {
    manifest: function () { return clone(MANIFEST); },
    projectLegacySettings: projectLegacySettings
  };
})(window);
