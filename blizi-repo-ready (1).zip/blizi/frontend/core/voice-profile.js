(function (root) {
  "use strict";

  var FEMALE_HINTS = ["female", "samantha", "victoria", "ava", "allison", "zoe", "karen", "moira", "fiona", "veena", "tessa", "serena", "zira", "jenny", "aria", "hazel", "susan", "siri", "google us english"];
  var MALE_HINTS = ["male", "david", "mark", "daniel", "alex", "fred", "george", "guy", "rishi", "google uk english male"];

  function score(voice, language) {
    var name = String(voice && voice.name || "").toLowerCase(), lang = String(voice && (voice.lang || voice.language) || "").toLowerCase(), target = String(language || "").toLowerCase(), value = 0;
    if (!name) return -10000;
    if (target && lang === target) value += 30;
    else if (target && lang.indexOf(target.slice(0, 2)) === 0) value += 15;
    FEMALE_HINTS.forEach(function (hint) { if (name.indexOf(hint) >= 0) value += 100; });
    MALE_HINTS.forEach(function (hint) { if (name.indexOf(hint) >= 0) value -= 120; });
    if (voice.localService) value += 3;
    return value;
  }
  function pick(voices, language) {
    var list = Array.isArray(voices) ? voices : [], best = null, bestScore = 0;
    list.forEach(function (voice) {
      var value = score(voice, language);
      // Never silently choose an unidentified voice: browsers can otherwise
      // turn a requested female character into the device's male default.
      if (value >= 100 && value > bestScore) { best = voice; bestScore = value; }
    });
    return best;
  }
  root.BliziVoiceProfile = { pickFemale: pick };
})(typeof window !== "undefined" ? window : globalThis);
