(function (root) {
  "use strict";

  function copy(value) {
    if (value === null || typeof value !== "object") return value;
    if (Array.isArray(value)) return value.slice();
    var out = {};
    Object.keys(value).forEach(function (key) { out[key] = copy(value[key]); });
    return out;
  }

  function create(options) {
    options = options || {};
    var now = options.now || Date.now;
    var getBodyState = typeof options.getBodyState === "function" ? options.getBodyState : function () { return { expression: "neutral", source: "default" }; };
    var getActivity = typeof options.getActivity === "function" ? options.getActivity : function () { return "idle"; };
    var getMode = typeof options.getMode === "function" ? options.getMode : function () { return "off"; };
    var getIdentity = typeof options.getIdentity === "function" ? options.getIdentity : function () { return ""; };

    function normalizeBody() {
      var body;
      try { body = getBodyState() || {}; } catch (_) { body = {}; }
      return {
        expression: String(body.expression || "neutral"),
        source: String(body.source || "default"),
        speaking: body.speaking === true,
        listening: body.listening === true,
        canSpeak: body.canSpeak !== false,
        canListen: body.canListen === true,
        canChangeExpression: body.canChangeExpression !== false
      };
    }
    function activity() {
      try { return String(getActivity() || "idle"); } catch (_) { return "idle"; }
    }
    function snapshot() {
      var body = normalizeBody();
      return {
        name: String(options.name || "Blizi"),
        role: "persistent AI companion",
        profileId: String(options.profileId || "prof_main"),
        mode: String(getMode() || "off"),
        activity: activity(),
        body: body,
        capabilities: ["change and describe my expression", "speak when voice is enabled", "listen when microphone input is available", "remember only supported local state"],
        boundaries: ["I am not human", "I do not claim consciousness", "I do not invent live access or actions", "I describe my current state from runtime signals"],
        observedAt: new Date(Number(now())).toISOString()
      };
    }
    function render(renderOptions) {
      renderOptions = renderOptions || {};
      var maxChars = Math.max(160, Number(renderOptions.maxChars) || 520), s = snapshot(), identity = "";
      try { identity = String(getIdentity() || ""); } catch (_) {}
      var text = "Self-model: I am " + s.name + ", a " + s.role + ". Current activity=" + s.activity + "; current face=" + s.body.expression + "; face source=" + s.body.source + ". I can change and describe my face" + (s.body.canSpeak ? ", speak" : "") + (s.body.canListen ? ", and listen" : "") + ". I am not human and do not claim consciousness; I report runtime state honestly.";
      if (identity) text += " " + identity.slice(0, 220);
      return text.slice(0, maxChars);
    }
    function explain(question) {
      var s = snapshot(), q = String(question || "").toLowerCase();
      if (/\bwho are you(?:\?|$)|\bwhat are you(?:\?|$)/.test(q)) return "I am " + s.name + ", a persistent AI companion. I am not human; I describe my identity and current runtime state rather than claiming consciousness.";
      if (/\bface\b|\bexpression\b|\blook\b/.test(q)) return "My current face is " + s.body.expression + ", selected by the " + s.body.source + " layer, and I am currently " + s.activity + ".";
      if (/\bdoing\b|\bstate\b|\bactivity\b/.test(q)) return "I am currently " + s.activity + " with a " + s.body.expression + " face.";
      return render({ maxChars: 700 });
    }
    return { snapshot: snapshot, render: render, explain: explain };
  }

  root.BliziSelfModel = { create: create };
})(typeof window !== "undefined" ? window : globalThis);
