(function (root) {
  "use strict";

  var SC = root.BliziCoreSchema;
  var STORE = "mood";
  var PROFILE = SC ? SC.PROFILE_ID : "prof_main";
  var ID = "mood_" + PROFILE;
  var MAX_CAUSES = 50;
  var MAX_HISTORY = 90;
  var DEFAULT_HALF_LIFE = 6 * 60 * 60 * 1000;
  var LABELS = ["neutral", "happy", "excited", "embarrassed", "confused", "sad", "angry", "thinking", "sleepy"];

  function copy(value) { return SC ? SC.clone(value) : JSON.parse(JSON.stringify(value)); }
  function clock(now) { return typeof now === "function" ? now() : (now === undefined ? Date.now() : now); }
  function finite(value, fallback) { return Number.isFinite(Number(value)) ? Number(value) : fallback; }
  function clamp(value, min, max) { return Math.max(min, Math.min(max, value)); }
  function iso(value) { return new Date(value).toISOString(); }
  function validLabel(value) {
    var normalized = root.BliziExpressionMap && root.BliziExpressionMap.normalize ? root.BliziExpressionMap.normalize(value) : String(value || "neutral");
    return LABELS.indexOf(normalized) >= 0 ? normalized : "neutral";
  }
  function vector(value) {
    if (typeof value === "number") return { valence: clamp(value, -1, 1), arousal: 0, dominance: 0 };
    value = value && typeof value === "object" ? value : {};
    return { valence: clamp(finite(value.valence, 0), -1, 1), arousal: clamp(finite(value.arousal, 0), -1, 1), dominance: clamp(finite(value.dominance, 0), -1, 1) };
  }
  function defaultRecord(now) {
    var at = iso(now);
    return {
      id: ID,
      profileId: PROFILE,
      sensitivity: "normal",
      baseline: { valence: 0.15, arousal: 0.05, dominance: 0 },
      decay: { defaultHalfLifeMs: DEFAULT_HALF_LIFE, maxShiftPerInteraction: 0.35, negativeIntensityCap: 0.65, nightArousal: -0.2 },
      labelMap: { positive: "happy", highArousal: "excited", lowArousal: "sleepy", thinking: "thinking", surprised: "surprised", serious: "serious", embarrassed: "embarrassed" },
      causes: [],
      current: { valence: 0.15, arousal: 0.05, dominance: 0, label: "neutral", at: at },
      timeline: [],
      dailySummaries: [],
      createdAt: at,
      updatedAt: at
    };
  }
  function compactCause(cause) {
    return {
      type: String(cause.type || "interaction").slice(0, 32),
      ref: String(cause.ref || "").slice(0, 64),
      delta: vector(cause.delta),
      labelHint: validLabel(cause.labelHint || "neutral"),
      note: String(cause.note || "").slice(0, 80),
      at: finite(cause.at, Date.now()),
      halfLifeMs: clamp(finite(cause.halfLifeMs, DEFAULT_HALF_LIFE), 1000, 30 * 24 * 60 * 60 * 1000)
    };
  }
  function encodeCause(cause) {
    return JSON.stringify({ t: cause.type, r: cause.ref, d: [cause.delta.valence, cause.delta.arousal, cause.delta.dominance], l: cause.labelHint, n: cause.note, a: cause.at, h: cause.halfLifeMs });
  }
  function decodeCause(value) {
    var item = JSON.parse(value);
    return compactCause({ type: item.t, ref: item.r, delta: { valence: item.d && item.d[0], arousal: item.d && item.d[1], dominance: item.d && item.d[2] }, labelHint: item.l, note: item.n, at: item.a, halfLifeMs: item.h });
  }
  function labelFor(record, result, active) {
    var hinted = active.slice().sort(function (a, b) { return Math.abs(b.delta.valence) + Math.abs(b.delta.arousal) - Math.abs(a.delta.valence) - Math.abs(a.delta.arousal); })[0];
    if (hinted && hinted.labelHint && hinted.labelHint !== "neutral") return validLabel(hinted.labelHint);
    if (result.arousal < -0.3) return "sleepy";
    if (result.arousal > 0.45 && result.valence > 0.35) return "excited";
    if (result.valence > 0.3) return "happy";
    if (result.valence < -0.45) return result.arousal > 0.3 ? "angry" : "sad";
    return "neutral";
  }
  function calculate(record, at) {
    at = clock(at);
    var baseline = vector(record.baseline), active = [], result = { valence: baseline.valence, arousal: baseline.arousal, dominance: baseline.dominance };
    (record.causes || []).forEach(function (cause) {
      var age = Math.max(0, at - finite(cause.at, at)), halfLife = Math.max(1000, finite(cause.halfLifeMs, DEFAULT_HALF_LIFE));
      if (age > halfLife * 12) return;
      var factor = Math.pow(0.5, age / halfLife), delta = vector(cause.delta);
      result.valence += delta.valence * factor; result.arousal += delta.arousal * factor; result.dominance += delta.dominance * factor;
      active.push(cause);
    });
    var hour = new Date(at).getHours();
    if (hour >= 22 || hour < 6) result.arousal += finite(record.decay && record.decay.nightArousal, -0.2);
    result.valence = clamp(result.valence, -1, 1); result.arousal = clamp(result.arousal, -1, 1); result.dominance = clamp(result.dominance, -1, 1);
    return { result: result, active: active, label: labelFor(record, result, active) };
  }
  function timelineEntry(at, computed) {
    return { at: iso(at), label: computed.label, valence: computed.result.valence, arousal: computed.result.arousal, dominance: computed.result.dominance };
  }

  function create(options) {
    options = options || {};
    var adapter = options.adapter, events = options.events, profileId = options.profileId || PROFILE, now = options.now;
    if (!adapter) throw SC.error("storage_required");
    var current = null, opened = false, listeners = [];
    function notify(value) { listeners.slice().forEach(function (fn) { try { fn(copy(value)); } catch (_) {} }); }
    async function open() {
      if (opened) return copy(current);
      current = await adapter.get(STORE, ID);
      if (!current) {
        current = defaultRecord(clock(now));
        if (events) await events.mutate({ store: STORE, op: "create", actor: "system", id: ID, record: current, patch: { kind: "mood_seed", schemaVersion: 1 } });
        else await adapter.put(STORE, current);
      }
      if (current.profileId !== profileId) throw SC.error("profile_mismatch");
      opened = true;
      return copy(current);
    }
    async function persist(computed, eventCause) {
      var at = clock(now), record = copy(current);
      record.causes = computed.active.slice(-MAX_CAUSES);
      record.current = { valence: computed.result.valence, arousal: computed.result.arousal, dominance: computed.result.dominance, label: computed.label, at: iso(at) };
      record.timeline = (record.timeline || []).concat([timelineEntry(at, computed)]).slice(-MAX_HISTORY);
      record.updatedAt = iso(at);
      if (eventCause && events) {
        var state = encodeCause(eventCause);
        if (state.length > 120) state = encodeCause(Object.assign({}, eventCause, { note: "" }));
        await events.mutate({ store: STORE, op: "update", actor: eventCause.type === "correction" ? "user" : "blizi", id: ID, record: record, patch: { kind: "mood_cause", state: state } });
      } else await adapter.put(STORE, record);
      current = record;
      notify(record.current);
      return copy(record);
    }
    async function recompute(at) {
      await open();
      var computed = calculate(current, at === undefined ? clock(now) : at);
      return (computed.label === current.current.label && Math.abs(computed.result.valence - current.current.valence) < 0.0001 && Math.abs(computed.result.arousal - current.current.arousal) < 0.0001) ? copy(current) : persist(computed, null);
    }
    async function addCause(input) {
      await open();
      input = input || {};
      var cause = compactCause(Object.assign({}, input, { at: clock(input.at === undefined ? now : input.at) }));
      var baseline = vector(current.baseline), delta = cause.delta, cap = finite(current.decay && current.decay.maxShiftPerInteraction, 0.35);
      cause.delta.valence = clamp(delta.valence, -cap, cap);
      cause.delta.arousal = clamp(delta.arousal, -cap, cap);
      cause.delta.dominance = clamp(delta.dominance, -cap, cap);
      if (cause.delta.valence < 0) cause.delta.valence = Math.max(cause.delta.valence, -finite(current.decay && current.decay.negativeIntensityCap, 0.65));
      current.causes = (current.causes || []).concat([cause]).slice(-MAX_CAUSES);
      var computed = calculate(current, cause.at);
      if (Math.abs(baseline.valence) > 1) computed.result.valence = baseline.valence;
      return persist(computed, cause);
    }
    async function get(at) { await open(); return recompute(at); }
    async function explain() { await open(); var at = clock(now); return (current.causes || []).filter(function (cause) { return at - cause.at <= cause.halfLifeMs * 12; }).map(copy); }
    function onChange(fn) { if (typeof fn !== "function") return function () {}; listeners.push(fn); return function () { listeners = listeners.filter(function (item) { return item !== fn; }); }; }
    async function rebuild(eventRows, rebuildOptions) {
      rebuildOptions = rebuildOptions || {};
      var record = defaultRecord(rebuildOptions.now === undefined ? clock(now) : rebuildOptions.now);
      (eventRows || []).filter(function (event) { return event.store === STORE && event.patch && event.patch.kind === "mood_cause" && event.patch.state; }).forEach(function (event) {
        try { record.causes.push(decodeCause(event.patch.state)); } catch (_) {}
      });
      var computed = calculate(record, rebuildOptions.now === undefined ? clock(now) : rebuildOptions.now);
      record.causes = computed.active.slice(-MAX_CAUSES); record.current = Object.assign({}, computed.result, { label: computed.label, at: iso(rebuildOptions.now === undefined ? clock(now) : rebuildOptions.now) });
      return record;
    }
    return { open: open, get: get, addCause: addCause, explain: explain, recompute: recompute, onChange: onChange, rebuild: rebuild, id: ID };
  }

  root.BliziMood = { create: create, calculate: calculate, rebuildFromEvents: function (events, options) { return create({ adapter: { get: async function () { return null; } }, profileId: PROFILE, now: options && options.now }).rebuild(events, options); } };
})(typeof window !== "undefined" ? window : globalThis);
