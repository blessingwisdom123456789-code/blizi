(function (root) {
  "use strict";

  var SC = root.BliziCoreSchema;
  var ID = "idn_main";
  var PROFILE = SC ? SC.PROFILE_ID : "prof_main";

  function copy(value) { return SC ? SC.clone(value) : JSON.parse(JSON.stringify(value)); }
  function canonical(value) {
    if (value === null || typeof value !== "object") return JSON.stringify(value);
    if (Array.isArray(value)) return "[" + value.map(canonical).join(",") + "]";
    return "{" + Object.keys(value).sort().map(function (key) { return JSON.stringify(key) + ":" + canonical(value[key]); }).join(",") + "}";
  }
  function cryptoFor(options) { return options.crypto || root.crypto || (typeof globalThis !== "undefined" ? globalThis.crypto : null); }
  async function sha256(value, options) {
    var c = cryptoFor(options), subtle = c && c.subtle;
    if (!subtle || typeof subtle.digest !== "function") throw (SC ? SC.error("crypto_unavailable", "SHA-256 is unavailable") : new Error("crypto_unavailable"));
    var data = new TextEncoder().encode(value), digest = await subtle.digest("SHA-256", data);
    return Array.prototype.map.call(new Uint8Array(digest), function (b) { return b.toString(16).padStart(2, "0"); }).join("");
  }
  function defaultRecord(seed, now) {
    var at = new Date(now).toISOString();
    return {
      id: ID,
      profileId: PROFILE,
      schemaVersion: 1,
      kind: "identity",
      coreTraits: { curious: true, warm: true, candid: true },
      values: ["honesty", "privacy"],
      voice: { register: "friendly", humor: "light", verbosity: "short" },
      boundaries: { hard: ["never claim to be human", "never use guilt", "never invent live access"] },
      integrity: { hardBoundariesHash: "" },
      sensitivity: "normal",
      createdAt: at,
      updatedAt: at,
      seedVersion: seed && seed.seedVersion || 1
    };
  }
  async function withHash(record, options) {
    var next = copy(record);
    next.integrity = next.integrity || {};
    next.integrity.hardBoundariesHash = await sha256(canonical(next.boundaries && next.boundaries.hard || []), options);
    return next;
  }

  function create(options) {
    options = options || {};
    var adapter = options.adapter, events = options.events, seed = options.seed || {}, profileId = options.profileId || PROFILE;
    var now = options.now, crypto = options.crypto, current = null, opened = false;
    if (!adapter) throw (SC ? SC.error("storage_required") : new Error("storage_required"));
    function clock() { return typeof now === "function" ? now() : (now === undefined ? Date.now() : now); }
    async function open() {
      if (opened) return copy(current);
      current = await adapter.get("identity", ID);
      if (!current) {
        var record = await withHash(defaultRecord(seed, clock()), { crypto: crypto });
        if (events) await events.mutate({ store: "identity", op: "create", actor: "system", id: ID, record: record, patch: { kind: "identity_seed", schemaVersion: 1 } });
        else await adapter.put("identity", record);
        current = record;
      }
      if (current.profileId !== profileId) throw SC.error("profile_mismatch");
      opened = true;
      return copy(current);
    }
    async function get() { await open(); return copy(current); }
    async function verifyIntegrity() {
      await open();
      var persisted = await adapter.get("identity", ID);
      if (persisted) current = persisted;
      var expected = await sha256(canonical(current.boundaries && current.boundaries.hard || []), { crypto: crypto });
      return expected === current.integrity.hardBoundariesHash ? { ok: true, reason: "ok" } : { ok: false, reason: "hard_boundaries_hash_mismatch" };
    }
    function render(renderOptions) {
      renderOptions = renderOptions || {};
      var maxChars = Math.max(120, Number(renderOptions.maxChars) || 450), record = current || defaultRecord(seed, clock());
      var traits = Object.keys(record.coreTraits || {}).filter(function (key) { return record.coreTraits[key]; }).join(", ");
      var values = (record.values || []).join(", ");
      var hard = (record.boundaries && record.boundaries.hard || []).join("; ");
      var text = "Blizi core: " + traits + ". Values: " + values + ". Voice: " + ((record.voice && record.voice.register) || "friendly") + ". Hard boundaries: " + hard + ".";
      return text.slice(0, maxChars);
    }
    return { open: open, get: get, verifyIntegrity: verifyIntegrity, render: render, id: ID };
  }

  root.BliziIdentity = { create: create, canonical: canonical, sha256: sha256 };
})(typeof window !== "undefined" ? window : globalThis);
