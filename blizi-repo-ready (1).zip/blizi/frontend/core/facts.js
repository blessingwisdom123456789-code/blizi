(function (root) {
  "use strict";
  var SC = root.BliziCoreSchema, FACTS = "facts", CORRECTIONS = "corrections", PROFILE = SC ? SC.PROFILE_ID : "prof_main";
  var SOURCES = ["stated", "observed", "inferred"];
  function copy(value) { return SC.clone(value); }
  function atValue(now) { return typeof now === "function" ? now() : (now === undefined ? Date.now() : now); }
  function iso(value) { return new Date(value).toISOString(); }
  function confidence(source, value) { var cap = source === "stated" ? 0.9 : source === "observed" ? 0.6 : 0.5; return Math.min(cap, Math.max(0, Number(value) || cap)); }
  function patch(kind, state) { return { kind: "fact_" + kind, state: JSON.stringify(state || {}).slice(0, 120) }; }
  function cleanSource(value) { return SOURCES.indexOf(value) >= 0 ? value : "stated"; }
  function create(options) {
    options = options || {};
    var adapter = options.adapter, events = options.events, profileId = options.profileId || PROFILE, now = options.now;
    if (!adapter) throw SC.error("storage_required");
    async function get(id) { var record = await adapter.get(FACTS, id); return record && record.profileId === profileId ? record : null; }
    async function writeFact(record, op, actor, state) { if (events) await events.mutate({ store: FACTS, op: op, actor: actor || "user", id: record.id, record: record, patch: patch(op, state || { id: record.id }) }); else await adapter.put(FACTS, record); return copy(record); }
    async function add(input) {
      input = input || {};
      if (input.sensitive === true || input.sensitivity === "sensitive") throw SC.error("sensitive_disabled");
      if (!input.key || input.value === undefined) throw SC.error("fact_fields_required");
      var source = cleanSource(input.source), time = atValue(input.createdAt === undefined ? now : input.createdAt), record = SC.createEnvelope(FACTS, { subject: String(input.subject || "user").slice(0, 120), category: String(input.category || "general").slice(0, 80), key: String(input.key).slice(0, 120), value: copy(input.value), source: source, confidence: confidence(source, input.confidence), status: "active", temporal: copy(input.temporal || null), provenance: { source: source, ref: String(input.ref || "explicit_user_input").slice(0, 120), at: iso(time) }, changing: input.changing === true, reconfirmAfterDays: Math.max(1, Number(input.reconfirmAfterDays) || 90), sensitivity: "normal", locked: false }, { profileId: profileId, now: time, prefix: "facts" });
      return writeFact(record, "create", "user", { id: record.id, source: source });
    }
    async function update(id, changes, actor) { var record = await get(id); if (!record) throw SC.error("fact_not_found"); if (changes && (changes.sensitive === true || changes.sensitivity === "sensitive")) throw SC.error("sensitive_disabled"); Object.keys(changes || {}).forEach(function (key) { if (["id", "profileId", "createdAt", "value"].indexOf(key) < 0) record[key] = copy(changes[key]); if (key === "value") record.value = copy(changes[key]); }); record.updatedAt = iso(atValue(now)); return writeFact(record, "update", actor || "user", { id: id, fields: Object.keys(changes || {}).slice(0, 8) }); }
    async function confirm(id) { var record = await get(id); if (!record) throw SC.error("fact_not_found"); record.status = "confirmed"; record.confidence = Math.max(record.confidence, confidence(record.source)); record.provenance.confirmedAt = iso(atValue(now)); return update(id, record, "user"); }
    async function retract(id) { var record = await get(id); if (!record) throw SC.error("fact_not_found"); record.status = "retracted"; return update(id, record, "user"); }
    async function dispute(idA, idB) { var a = await get(idA), b = await get(idB); if (!a || !b) throw SC.error("fact_not_found"); a.status = "disputed"; b.status = "disputed"; await update(idA, a, "system"); await update(idB, b, "system"); return { a: copy(a), b: copy(b) }; }
    async function correct(id, newValue, correctionOptions) {
      correctionOptions = correctionOptions || {}; var old = await get(id); if (!old) throw SC.error("fact_not_found");
      var replacement = await add({ subject: old.subject, category: old.category, key: old.key, value: newValue, source: "stated", confidence: 0.9, temporal: old.temporal, changing: old.changing, ref: "correction" });
      replacement.locked = true; replacement.supersedes = id; replacement.provenance.correctionReason = String(correctionOptions.reason || "user correction").slice(0, 120); await update(replacement.id, replacement, "user");
      var correction = SC.createEnvelope(CORRECTIONS, { targetId: id, replacementId: replacement.id, reason: String(correctionOptions.reason || "user correction").slice(0, 240), purgeBefore: correctionOptions.purgeBefore === true, provenance: { source: "user", at: iso(atValue(now)) }, sensitivity: "normal" }, { profileId: profileId, now: atValue(now), prefix: "corrections" });
      if (correctionOptions.purgeBefore === true) { if (events) await events.mutate({ store: FACTS, op: "delete", actor: "user", id: id }); else await adapter.delete(FACTS, id); }
      else { old.status = "superseded"; await update(id, old, "user"); }
      if (events) await events.mutate({ store: CORRECTIONS, op: "create", actor: "user", id: correction.id, record: correction, patch: patch("correction", { targetId: id, replacementId: replacement.id, purgeBefore: correction.purgeBefore }) }); else await adapter.put(CORRECTIONS, correction);
      return { correction: copy(correction), fact: await get(replacement.id) };
    }
    async function query(filter) { filter = filter || {}; var rows = await adapter.getAll(FACTS); return rows.filter(function (record) { if (record.profileId !== profileId) return false; if (filter.subject && record.subject !== filter.subject) return false; if (filter.category && record.category !== filter.category) return false; if (filter.key && record.key !== filter.key) return false; if (filter.status && record.status !== filter.status) return false; return true; }).sort(function (a, b) { return Date.parse(b.updatedAt) - Date.parse(a.updatedAt); }).map(copy); }
    async function decay(at) { at = atValue(at === undefined ? now : at); var rows = await adapter.getAll(FACTS), changed = 0; for (var i = 0; i < rows.length; i++) { var record = rows[i]; if (!record.changing || record.status === "retracted" || record.status === "superseded") continue; var due = record.reconfirmAfterDays * 24 * 60 * 60 * 1000; if (at - Date.parse(record.updatedAt) > due) { record.confidence = Math.max(0.1, record.confidence * 0.8); record.updatedAt = iso(at); await writeFact(record, "update", "system", { id: record.id, decay: true }); changed++; } } return { changed: changed }; }
    async function listCorrections() { return (await adapter.getAll(CORRECTIONS)).filter(function (record) { return record.profileId === profileId; }).map(copy); }
    return { add: add, get: get, confirm: confirm, retract: retract, dispute: dispute, correct: correct, query: query, decay: decay, corrections: listCorrections };
  }
  root.BliziFacts = { create: create };
})(typeof window !== "undefined" ? window : globalThis);
