(function (root) {
  "use strict";

  var SC = root.BliziCoreSchema;
  var STORES = root.BliziCoreStore;
  function coded(code, message) { return SC.error(code, message || code); }
  function copy(value) { return SC.clone(value); }
  function bytes(value) { var text = JSON.stringify(value); return typeof TextEncoder === "function" ? new TextEncoder().encode(text).length : text.length * 2; }
  function keyFor(storeName, record) { return SC.definition(storeName).keyPath === "seq" ? record.seq : record[SC.definition(storeName).keyPath]; }

  function create(options) {
    options = options || {};
    var profileId = options.profileId || SC.PROFILE_ID;
    if (profileId !== SC.PROFILE_ID) throw coded("profile_mismatch", "Phase A supports only prof_main");
    var adapter = options.adapter || STORES.createBrowserAdapter({
      profileId: profileId,
      indexedDB: options.indexedDB,
      localStorage: options.localStorage,
      localStorageOptions: options.localStorageOptions,
      indexedDBOptions: options.indexedDBOptions
    });
    var opened = false, opening = null, migrationResult = null, fallbackReason = null;
    var events = root.BliziCoreEvents ? root.BliziCoreEvents.create(adapter, { profileId: profileId, now: options.now }) : null;
    var migrations = root.BliziCoreMigrations ? root.BliziCoreMigrations.create(adapter, { profileId: profileId, events: events, now: options.now, maxBytes: options.maxLegacyBytes }) : null;
    var seed = root.BliziCoreSeed ? root.BliziCoreSeed.manifest() : null;
    var identity = root.BliziIdentity ? root.BliziIdentity.create({ adapter: adapter, events: events, seed: seed, profileId: profileId, now: options.now, crypto: options.crypto }) : null;
    var mood = root.BliziMood ? root.BliziMood.create({ adapter: adapter, events: events, profileId: profileId, now: options.now }) : null;
    var relationship = root.BliziRelationship ? root.BliziRelationship.create({ adapter: adapter, events: events, identity: identity, mood: mood, profileId: profileId, now: options.now, legacyStorage: legacyStorage }) : null;
    var episodes = root.BliziEpisodes ? root.BliziEpisodes.create({ adapter: adapter, events: events, profileId: profileId, now: options.now }) : null;
    var facts = root.BliziFacts ? root.BliziFacts.create({ adapter: adapter, events: events, profileId: profileId, now: options.now }) : null;
    var projects = root.BliziProjects ? root.BliziProjects.create({ adapter: adapter, events: events, mood: mood, episodes: episodes, relationship: relationship, profileId: profileId, now: options.now }) : null;

    function legacyStorage() {
      if (options.localStorage !== undefined) return options.localStorage;
      try { return root.localStorage; } catch (_) { return null; }
    }

    async function open() {
      if (opening) return opening;
      opening = (async function () {
        try { await adapter.open(); }
        catch (firstError) {
          fallbackReason = firstError && firstError.code || "indexeddb_open_failed";
          var local = legacyStorage();
          if (adapter.kind !== "indexedDB" || !local) {
            adapter = local ? new STORES.LocalStorageAdapter(local, Object.assign({}, options.localStorageOptions || {}, { profileId: profileId })) : new STORES.MemoryAdapter({ profileId: profileId });
          } else adapter = new STORES.LocalStorageAdapter(local, Object.assign({}, options.localStorageOptions || {}, { profileId: profileId }));
          events = root.BliziCoreEvents.create(adapter, { profileId: profileId, now: options.now });
          migrations = root.BliziCoreMigrations.create(adapter, { profileId: profileId, events: events, now: options.now, maxBytes: options.maxLegacyBytes });
          identity = root.BliziIdentity.create({ adapter: adapter, events: events, seed: seed, profileId: profileId, now: options.now, crypto: options.crypto });
          mood = root.BliziMood.create({ adapter: adapter, events: events, profileId: profileId, now: options.now });
          relationship = root.BliziRelationship.create({ adapter: adapter, events: events, identity: identity, mood: mood, profileId: profileId, now: options.now, legacyStorage: legacyStorage });
          episodes = root.BliziEpisodes.create({ adapter: adapter, events: events, profileId: profileId, now: options.now });
          facts = root.BliziFacts.create({ adapter: adapter, events: events, profileId: profileId, now: options.now });
          projects = root.BliziProjects.create({ adapter: adapter, events: events, mood: mood, episodes: episodes, relationship: relationship, profileId: profileId, now: options.now });
          await adapter.open();
        }
        opened = true;
        if (options.captureLegacy !== false && migrations) {
          migrationResult = await migrations.refreshLegacySnapshot(legacyStorage());
        }
        if (identity) await identity.open();
        if (mood) await mood.open();
        if (relationship) await relationship.open();
        if (projects) await projects.open();
        return {
          ok: true,
          profileId: profileId,
          mode: getMode(),
          storage: await storageInfo(),
          migration: copy(migrationResult)
        };
      })();
      try { return await opening; }
      catch (e) { opening = null; throw e; }
    }
    function getMode() {
      var value = typeof options.getMode === "function" ? options.getMode() : options.mode;
      return value === "shadow" || value === "on" ? value : "off";
    }
    async function requireOpen() { if (!opened) await open(); }
    async function storageInfo() {
      var estimate = await adapter.estimate();
      return {
        kind: adapter.kind,
        profileId: profileId,
        warning: adapter.kind === "localStorage" ? "Storage fallback has a small quota; Core State is currently off and no chat context is read from it." : adapter.kind === "memory" ? "Memory-only storage is temporary and will be lost when the page closes." : null,
        fallbackReason: fallbackReason,
        estimate: estimate
      };
    }
    async function exportBundle(options) {
      options = options || {};
      await requireOpen();
      var exported = Object.create(null);
      for (var i = 0; i < SC.STORE_NAMES.length; i++) {
        var name = SC.STORE_NAMES[i];
        if (name === "meta" || (name === "snapshots" && options.includeSnapshots !== true)) continue;
        var rows = await adapter.getAll(name);
        exported[name] = rows.filter(function (row) { return row.profileId === profileId; }).map(copy);
      }
      return { format: "blizi-core-foundation-bundle", formatVersion: 1, schemaVersion: SC.DATABASE_VERSION, profileId: profileId, exportedAt: new Date(typeof options.now === "function" ? options.now() : Date.now()).toISOString(), stores: exported };
    }
    async function importBundle(bundle, importOptions) {
      importOptions = importOptions || {};
      await requireOpen();
      if (!bundle || bundle.format !== "blizi-core-foundation-bundle" || bundle.formatVersion !== 1 || bundle.profileId !== profileId || !bundle.stores || typeof bundle.stores !== "object") throw coded("invalid_bundle", "Unsupported Core State foundation bundle");
      var names = Object.keys(bundle.stores);
      names.forEach(function (name) {
        SC.definition(name);
        if (name === "meta") throw coded("invalid_bundle", "Global metadata cannot be imported in a profile bundle");
        if (!Array.isArray(bundle.stores[name])) throw coded("invalid_bundle", "Bundle store must be an array");
        bundle.stores[name].forEach(function (row) { SC.validateRecord(name, row, profileId); });
      });
      var replace = importOptions.mode === "replace", allNames = SC.STORE_NAMES.filter(function (n) { return n !== "meta"; });
      if (!replace && importOptions.mode && importOptions.mode !== "merge") throw coded("invalid_import_mode");
      await adapter.transaction(allNames, "readwrite", async function (tx) {
        if (replace) {
          for (var s = 0; s < allNames.length; s++) {
            if (allNames[s] === "snapshots" && importOptions.preserveSnapshots === true) continue;
            var all = await tx.getAll(allNames[s]);
            for (var r = 0; r < all.length; r++) if (all[r].profileId === profileId) await tx.delete(allNames[s], keyFor(allNames[s], all[r]));
          }
        }
        for (var j = 0; j < names.length; j++) {
          var storeName = names[j], records = bundle.stores[storeName];
          for (var k = 0; k < records.length; k++) {
            if (replace) await tx.put(storeName, records[k]);
            else await tx.add(storeName, records[k]);
          }
        }
      });
      return { ok: true, mode: replace ? "replace" : "merge", records: names.reduce(function (n, key) { return n + bundle.stores[key].length; }, 0) };
    }
    async function snapshot(reason) {
      await requireOpen();
      var bundle = await exportBundle({ includeSnapshots: false });
      var now = typeof options.now === "function" ? options.now() : Date.now();
      var record = SC.createEnvelope("snapshots", { kind: "foundation-snapshot", reason: String(reason || "manual").slice(0, 120), bundle: bundle }, { profileId: profileId, now: now, prefix: "snp" });
      await adapter.put("snapshots", record);
      return record;
    }
    async function restore(snapshotId, restoreOptions) {
      await requireOpen();
      var record = await adapter.get("snapshots", snapshotId);
      if (!record || record.profileId !== profileId || !record.bundle) throw coded("snapshot_not_found");
      return importBundle(record.bundle, Object.assign({ mode: "replace", preserveSnapshots: true }, restoreOptions || {}));
    }
    async function clearProfile() {
      await requireOpen();
      var removals = Object.create(null), names = SC.STORE_NAMES.filter(function (name) { return name !== "meta"; });
      for (var i = 0; i < names.length; i++) {
        var rows = await adapter.getAll(names[i]);
        removals[names[i]] = rows.filter(function (row) { return row.profileId === profileId; }).map(function (row) { return keyFor(names[i], row); });
      }
      await adapter.transaction(names, "readwrite", async function (tx) {
        for (var j = 0; j < names.length; j++) for (var k = 0; k < removals[names[j]].length; k++) await tx.delete(names[j], removals[names[j]][k]);
      });
      migrationResult = null;
      return { ok: true, profileId: profileId };
    }
    async function close() { if (adapter && typeof adapter.close === "function") adapter.close(); opened = false; opening = null; }

    return {
      open: open,
      mode: getMode,
      profileId: profileId,
      adapter: function () { return adapter; },
      seed: function () { return copy(seed); },
      events: function () { return events; },
      migrations: function () { return migrations; },
      migrationStatus: function () { return copy(migrationResult); },
      identity: function () { return identity; },
      mood: function () { return mood; },
      relationship: function () { return relationship; },
      episodes: function () { return episodes; },
      facts: function () { return facts; },
      projects: function () { return projects; },
      storageInfo: storageInfo,
      export: exportBundle,
      import: importBundle,
      snapshot: snapshot,
      restore: restore,
      clearProfile: clearProfile,
      wipe: clearProfile,
      close: close
    };
  }

  root.BliziCore = { create: create, profileId: SC.PROFILE_ID, schemaVersion: SC.DATABASE_VERSION };
})(window);
