(function (root) {
  "use strict";
  var SC = root.BliziCoreSchema, STORE = "episodes", PROFILE = SC ? SC.PROFILE_ID : "prof_main", CAP = 2000, HALF_LIFE = 30 * 24 * 60 * 60 * 1000;
  function copy(value) { return SC.clone(value); }
  function atValue(now) { return typeof now === "function" ? now() : (now === undefined ? Date.now() : now); }
  function iso(value) { return new Date(value).toISOString(); }
  function clamp(value, min, max) { return Math.max(min, Math.min(max, Number(value) || 0)); }
  function patch(kind, state) { return { kind: "episode_" + kind, state: JSON.stringify(state || {}).slice(0, 120) }; }
  function topics(text) { var stop = /^(about|after|again|also|because|being|could|first|from|have|into|just|like|more|really|that|their|there|these|this|what|when|where|which|with|would|your)$/; var seen = {}; return String(text || "").toLowerCase().replace(/[^a-z0-9 ]/g, " ").split(/\s+/).filter(function (word) { return word.length > 4 && !stop.test(word) && !seen[word] && (seen[word] = true); }).slice(0, 8); }
  function summarize(messages, meta) {
    messages = Array.isArray(messages) ? messages : [];
    var firstUser = messages.filter(function (m) { return m && m.who === "user" && m.text; })[0];
    var first = String(firstUser ? firstUser.text : "").trim().slice(0, 240);
    return { summary: first || "Conversation with Blizi", topics: topics(first), userCount: messages.filter(function (m) { return m && m.who === "user"; }).length, assistantCount: messages.filter(function (m) { return m && m.who === "bot"; }).length, importance: clamp(meta && meta.importance === undefined ? 0.4 : meta.importance, 0, 1) };
  }
  function create(options) {
    options = options || {};
    var adapter = options.adapter, events = options.events, profileId = options.profileId || PROFILE, now = options.now;
    if (!adapter) throw SC.error("storage_required");
    async function add(input) {
      input = input || {}; var time = atValue(input.occurredAt === undefined ? now : input.occurredAt);
      if (input.sensitive === true || input.sensitivity === "sensitive") throw SC.error("sensitive_disabled");
      var record = SC.createEnvelope(STORE, { occurredAt: iso(time), summary: String(input.summary || "").slice(0, 500), topics: Array.isArray(input.topics) ? input.topics.slice(0, 16) : topics(input.summary), projects: Array.isArray(input.projects) ? input.projects.slice(0, 16) : [], people: Array.isArray(input.people) ? input.people.slice(0, 16) : [], importance: clamp(input.importance === undefined ? 0.4 : input.importance, 0, 1), strength: clamp(input.strength === undefined ? 1 : input.strength, 0, 1), pinned: input.pinned === true, consolidation: { state: "active" }, provenance: { source: String(input.source || "conversation").slice(0, 80) }, lastRecalledAt: null, sensitivity: "normal" }, { profileId: profileId, now: time, prefix: "episodes" });
      if (events) await events.mutate({ store: STORE, op: "create", actor: "user", id: record.id, record: record, patch: patch("add", { id: record.id, source: record.provenance.source }) });
      else await adapter.put(STORE, record);
      return copy(record);
    }
    async function get(id) { var record = await adapter.get(STORE, id); return record && record.profileId === profileId ? record : null; }
    async function update(id, changes) {
      var record = await get(id); if (!record) throw SC.error("episode_not_found");
      if (changes && (changes.sensitive === true || changes.sensitivity === "sensitive")) throw SC.error("sensitive_disabled");
      Object.keys(changes || {}).forEach(function (key) { if (["id", "profileId", "createdAt"].indexOf(key) < 0) record[key] = copy(changes[key]); });
      record.updatedAt = iso(atValue(now));
      if (events) await events.mutate({ store: STORE, op: "update", actor: "user", id: id, record: record, patch: patch("update", { id: id, fields: Object.keys(changes || {}).slice(0, 8) }) });
      else await adapter.put(STORE, record);
      return copy(record);
    }
    async function pin(id, value) { var record = await get(id); if (!record) throw SC.error("episode_not_found"); record.pinned = value === true; if (record.pinned) record.importance = Math.max(0.9, record.importance); return update(id, record); }
    async function remove(id) { var record = await get(id); if (!record) return false; if (events) await events.mutate({ store: STORE, op: "delete", actor: "user", id: id, patch: null }); else await adapter.delete(STORE, id); return true; }
    async function query(filter) {
      filter = filter || {}; var rows = await adapter.getAll(STORE), text = String(filter.text || "").toLowerCase();
      rows = rows.filter(function (record) { if (record.profileId !== profileId || record.consolidation.state !== "active") return false; if (text && (String(record.summary).toLowerCase().indexOf(text) < 0 && (record.topics || []).join(" ").toLowerCase().indexOf(text) < 0)) return false; if (filter.projects && filter.projects.some(function (x) { return (record.projects || []).indexOf(x) < 0; })) return false; if (filter.people && filter.people.some(function (x) { return (record.people || []).indexOf(x) < 0; })) return false; if (filter.since && Date.parse(record.occurredAt) < Number(filter.since)) return false; return true; });
      rows.sort(function (a, b) { return Date.parse(b.occurredAt) - Date.parse(a.occurredAt); }); return rows.slice(0, Math.max(0, Number(filter.limit) || 50)).map(copy);
    }
    async function touch(id) { var record = await get(id); if (!record) throw SC.error("episode_not_found"); record.strength = clamp(record.strength + 0.1, 0, 1); record.lastRecalledAt = iso(atValue(now)); return update(id, record); }
    async function captureConversation(messages, meta) { var summary = summarize(messages, meta); if (!summary.userCount) return null; return add(Object.assign(summary, meta || {}, { source: "rule_summarizer", sensitivity: "normal" })); }
    async function maintain(at) {
      at = atValue(at === undefined ? now : at); var rows = await adapter.getAll(STORE), changed = 0, active = rows.filter(function (r) { return r.consolidation.state === "active"; });
      for (var i = 0; i < active.length; i++) { var record = active[i], age = Math.max(0, at - Date.parse(record.occurredAt)); record.strength = clamp(Math.pow(0.5, age / HALF_LIFE), 0, 1); if (events) await events.mutate({ store: STORE, op: "update", actor: "system", id: record.id, record: record, patch: patch("decay", { id: record.id }) }); else await adapter.put(STORE, record); changed++; }
      active = (await adapter.getAll(STORE)).filter(function (r) { return r.consolidation.state === "active"; }).sort(function (a, b) { return (a.strength * a.importance) - (b.strength * b.importance); });
      while (active.length > CAP) { var victim = active.shift(); if (victim.pinned) continue; victim.consolidation = { state: "archived", archivedAt: iso(at), reason: "capacity" }; if (events) await events.mutate({ store: STORE, op: "update", actor: "system", id: victim.id, record: victim, patch: patch("archive", { id: victim.id }) }); else await adapter.put(STORE, victim); changed++; }
      return { changed: changed, active: (await query({ limit: CAP })).length };
    }
    return { add: add, get: get, update: update, pin: pin, delete: remove, query: query, touch: touch, captureConversation: captureConversation, maintain: maintain };
  }
  root.BliziEpisodes = { create: create, summarize: summarize };
})(typeof window !== "undefined" ? window : globalThis);
