(function (root) {
  "use strict";

  var PROFILE_ID = "prof_main";
  var DATABASE_NAME = "blizi-core";
  var DATABASE_VERSION = 1;
  var STORE_DEFS = [
    { name: "meta", keyPath: "key", global: true },
    { name: "identity", keyPath: "id" },
    { name: "mood", keyPath: "id" },
    { name: "relationship", keyPath: "id" },
    { name: "episodes", keyPath: "id" },
    { name: "facts", keyPath: "id" },
    { name: "corrections", keyPath: "id" },
    { name: "projects", keyPath: "id" },
    { name: "journal", keyPath: "id" },
    { name: "proposals", keyPath: "id" },
    { name: "versions", keyPath: "id" },
    { name: "migrations", keyPath: "id" },
    { name: "transcripts", keyPath: "id" },
    { name: "snapshots", keyPath: "id" },
    { name: "eventlog", keyPath: "seq", autoIncrement: true }
  ];
  var STORE_BY_NAME = Object.create(null);
  STORE_DEFS.forEach(function (entry) { STORE_BY_NAME[entry.name] = entry; });
  var ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
  var ID_PREFIXES = {
    identity: "ide",
    mood: "moo",
    relationship: "rel",
    episodes: "ep",
    facts: "fct",
    corrections: "cor",
    projects: "proj",
    journal: "jrn",
    proposals: "prp",
    versions: "ver",
    migrations: "mig",
    transcripts: "trn",
    snapshots: "snp",
    eventlog: "evt",
    meta: "meta"
  };

  function clone(value) {
    if (value === undefined || value === null) return value;
    if (typeof root.structuredClone === "function") return root.structuredClone(value);
    return JSON.parse(JSON.stringify(value));
  }

  function makeId(prefix, options) {
    options = options || {};
    var requestedPrefix = String(prefix || "rec").replace(/[^a-z0-9]/gi, "").toLowerCase();
    prefix = ID_PREFIXES[requestedPrefix] || requestedPrefix.slice(0, 8) || "rec";
    var now = typeof options.now === "function" ? options.now() : (options.now === undefined ? Date.now() : options.now);
    var time = Math.max(0, Math.floor(Number(now) || 0));
    var timePart = "";
    for (var i = 0; i < 10; i++) {
      timePart = ALPHABET[time % 32] + timePart;
      time = Math.floor(time / 32);
    }
    var bytes = new Uint8Array(10);
    var cryptoObject = options.crypto || root.crypto;
    if (cryptoObject && typeof cryptoObject.getRandomValues === "function") {
      try { cryptoObject.getRandomValues(bytes); }
      catch (error) { fillRandom(bytes, options.random); }
    } else fillRandom(bytes, options.random);
    var randomPart = "", buffer = 0, bits = 0;
    for (var j = 0; j < bytes.length; j++) {
      buffer = (buffer << 8) | bytes[j];
      bits += 8;
      while (bits >= 5) {
        bits -= 5;
        randomPart += ALPHABET[(buffer >>> bits) & 31];
      }
    }
    return prefix + "_" + timePart + randomPart;
  }

  function fillRandom(bytes, random) {
    for (var i = 0; i < bytes.length; i++) {
      var value = typeof random === "function" ? Number(random()) : Math.random();
      if (!isFinite(value)) value = 0;
      value = Math.max(0, Math.min(0.999999999, value));
      bytes[i] = Math.floor(value * 256);
    }
  }

  function definition(name) {
    var entry = STORE_BY_NAME[name];
    if (!entry) throw codedError("unknown_store", "Unknown Core State store");
    return entry;
  }

  function codedError(code, message) {
    var error = new Error(message || code);
    error.code = code;
    return error;
  }

  function validateRecord(storeName, record, profileId) {
    var def = definition(storeName);
    if (!record || typeof record !== "object" || Array.isArray(record)) throw codedError("invalid_record", "Record must be an object");
    if (def.global) {
      if (typeof record.key !== "string" || !record.key) throw codedError("invalid_key", "Global metadata needs a key");
      return true;
    }
    if (storeName === "eventlog") {
      if (record.profileId !== (profileId || PROFILE_ID)) throw codedError("profile_mismatch", "Event belongs to a different profile");
      if (record.seq !== undefined && (!Number.isSafeInteger(record.seq) || record.seq < 1)) throw codedError("invalid_key", "Invalid event sequence");
      return true;
    }
    if (typeof record.id !== "string" || !record.id.trim()) throw codedError("invalid_key", "Profile record needs an id");
    if (record.profileId !== (profileId || PROFILE_ID)) throw codedError("profile_mismatch", "Record belongs to a different profile");
    if (record.sensitivity === "sensitive" || record.sensitive === true) throw codedError("sensitive_disabled", "Sensitive-memory collection is disabled in v1");
    return true;
  }

  function createEnvelope(storeName, input, options) {
    options = options || {};
    var def = definition(storeName), profileId = options.profileId || PROFILE_ID;
    var now = typeof options.now === "function" ? options.now() : (options.now === undefined ? Date.now() : options.now);
    var iso = new Date(now).toISOString();
    var record = clone(input || {});
    if (def.global) {
      if (!record.key) record.key = options.key || makeId("meta", options);
      return record;
    }
    if (storeName === "eventlog") {
      if (!record.profileId) record.profileId = profileId;
      validateRecord(storeName, record, profileId);
      return record;
    }
    if (record.profileId && record.profileId !== profileId) throw codedError("profile_mismatch", "Record belongs to a different profile");
    if (!record.id) record.id = options.id || makeId(options.prefix || storeName, options);
    record.profileId = profileId;
    if (!record.createdAt) record.createdAt = iso;
    record.updatedAt = iso;
    validateRecord(storeName, record, profileId);
    return record;
  }

  root.BliziCoreSchema = {
    PROFILE_ID: PROFILE_ID,
    DATABASE_NAME: DATABASE_NAME,
    DATABASE_VERSION: DATABASE_VERSION,
    STORE_DEFS: STORE_DEFS.map(function (entry) { return clone(entry); }),
    STORE_NAMES: STORE_DEFS.map(function (entry) { return entry.name; }),
    definition: definition,
    clone: clone,
    makeId: makeId,
    createEnvelope: createEnvelope,
    validateRecord: validateRecord,
    error: codedError
  };
})(window);
