(function (root) {
  "use strict";
  function create(options) {
    options = options || {};
    var mood = options.mood, arbiter = options.arbiter, mode = options.getMode || function () { return "off"; }, unsubscribe = null;
    function apply(value) {
      if (mode() !== "on" || !arbiter || typeof arbiter.request !== "function") return;
      var label = value && value.label;
      if (!label) return;
      try { arbiter.request({ expr: label, source: "mood", holdMs: 0 }); } catch (_) {}
    }
    function start() {
      if (!mood || unsubscribe) return function () {};
      unsubscribe = mood.onChange(apply);
      mood.get().then(apply).catch(function () {});
      return function () { if (unsubscribe) unsubscribe(); unsubscribe = null; };
    }
    function stop() { if (unsubscribe) unsubscribe(); unsubscribe = null; }
    return { start: start, stop: stop, apply: apply };
  }
  root.BliziCoreAvatarBridge = { create: create };
})(typeof window !== "undefined" ? window : globalThis);
