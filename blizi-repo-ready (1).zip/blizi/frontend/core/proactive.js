(function (root) {
  "use strict";

  /*
   * BLIZI proactive check-ins (inspired by the Jarvis proactive agent, rebuilt for a web app).
   *
   * Pure decision logic: given a snapshot of the situation it returns at most one short check-in
   * (morning, evening or welcome-back) or null. No DOM, no timers, no model calls, so it is fast,
   * works offline, costs nothing, and is fully testable. The page owns the timer and the delivery.
   *
   * She only speaks up when it is polite: the feature is on, the app is visible, she is not busy or
   * already speaking, it is not quiet time, the user has not touched anything for a few seconds,
   * and she has not already checked in recently. Each kind fires at most once per local day.
   */

  var MIN_GAP_MS = 90 * 60 * 1000;      // never two check-ins within 90 minutes
  var IDLE_MS = 20 * 1000;              // user must have been idle this long
  var AWAY_MS = 8 * 60 * 60 * 1000;     // "welcome back" after this long away
  var HUMOR = { off: 1, subtle: 1, playful: 1 };
  var FORMALITY = { casual: 1, neutral: 1, formal: 1 };

  function pad(n) { return n < 10 ? "0" + n : String(n); }
  function dateKey(at) {
    var d = new Date(at);
    return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate());
  }
  function cleanName(name) {
    return String(name == null ? "" : name).replace(/[\u0000-\u001f\u007f<>]/g, " ").replace(/\s+/g, " ").trim().slice(0, 40);
  }

  var GREETING = {
    morning: { casual: "Morning", neutral: "Good morning", formal: "Good morning" },
    evening: { casual: "Hey", neutral: "Good evening", formal: "Good evening" },
    back: { casual: "Hey, welcome back", neutral: "Welcome back", formal: "Welcome back" }
  };
  var BODY = {
    morning: {
      off: "What would you like to do today?",
      subtle: "Anything I can help you start with?",
      playful: "I've been waiting here all night. Dramatic, I know. What's the plan?"
    },
    evening: {
      off: "Would you like to wrap up the day?",
      subtle: "Want to wind down, or tie up anything for tomorrow?",
      playful: "The day is almost done. Want to wrap up before your brain files a complaint?"
    },
    back: {
      off: "How can I help?",
      subtle: "Good to see you again. What's next?",
      playful: "I kept your spot warm. What are we doing?"
    }
  };
  var FORMAL_BODY = { morning: "How may I help you today?", evening: "May I help you wrap up the day?", back: "How may I help you?" };
  var FACE = { morning: "happy", evening: "sleepy", back: "excited" };

  function compose(type, name, humor, formality) {
    humor = HUMOR[humor] ? humor : "subtle";
    formality = FORMALITY[formality] ? formality : "neutral";
    var who = cleanName(name);
    // A formal tone always wins over humor, so she never jokes while being formal.
    var body = formality === "formal" ? FORMAL_BODY[type] : BODY[type][humor];
    return GREETING[type][formality] + (who ? ", " + who : "") + ". " + body;
  }

  function evaluate(ctx) {
    ctx = ctx || {};
    var now = Number(ctx.now);
    if (!isFinite(now)) return null;
    if (!ctx.enabled || !ctx.visible || ctx.busy || ctx.speaking) return null;
    var hour = new Date(now).getHours(), minute = new Date(now).getMinutes();
    // Quiet time: trust the relationship's quiet hours when known, else a sensible default.
    var quiet = ctx.quiet === true || (ctx.quiet !== false && (hour >= 23 || hour < 6));
    if (quiet) return null;
    if (!(Number(ctx.idleMs) >= IDLE_MS)) return null; // unknown idleness counts as not idle
    var sent = ctx.sent || {};
    if (isFinite(Number(sent.lastAt)) && sent.lastAt > 0 && now - sent.lastAt < MIN_GAP_MS) return null;

    var today = dateKey(now), type = null;
    if (hour >= 6 && hour < 11 && sent.morning !== today && ctx.spokeToday !== true) type = "morning";
    else if (((hour === 20 && minute >= 30) || hour === 21 || hour === 22) && sent.evening !== today) type = "evening";
    else if (Number(ctx.awayMs) >= AWAY_MS && sent.back !== today && sent.morning !== today) type = "back";
    if (!type) return null;
    return { type: type, text: compose(type, ctx.name, ctx.humor, ctx.formality), face: FACE[type], key: today };
  }

  function markSent(sent, type, now) {
    var next = {};
    Object.keys(sent || {}).forEach(function (k) { next[k] = sent[k]; });
    next[type] = dateKey(now);
    next.lastAt = Number(now);
    return next;
  }

  root.BliziProactive = Object.freeze({
    evaluate: evaluate,
    markSent: markSent,
    compose: compose,
    dateKey: dateKey,
    MIN_GAP_MS: MIN_GAP_MS,
    IDLE_MS: IDLE_MS,
    AWAY_MS: AWAY_MS
  });
})(typeof window !== "undefined" ? window : globalThis);
