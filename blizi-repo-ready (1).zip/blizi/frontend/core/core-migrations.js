(function (root) {
  "use strict";

  var SC = root.BliziCoreSchema;
  var MIGRATION_ID = "mig_localstorage_v1";
  var SOURCE_KEYS = ["blizi.settings", "blizi.settings.manus.v1", "blizi.notes", "blizi.convs"];

  function hashText(text) {
    // Change detector only; not a cryptographic integrity or confidentiality mechanism.
    var h = 2166136261;
    for (var i = 0; i < text.length; i++) { h ^= text.charCodeAt(i); h = Math.imul(h, 16777619); }
    return "fnv1a32:" + (h >>> 0).toString(16).padStart(8, "0");
  }
  function safeRead(storage, key) {
    try { return storage && typeof storage.getItem === "function" ? storage.getItem(key) : null; }
    catch (e) { var error = SC.error("legacy_source_unavailable", "Legacy local data could not be read"); throw error; }
  }
  function parseSettings(raw) {
    if (typeof raw !== "string") return {};
    try { var parsed = JSON.parse(raw); return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : {}; }
    catch (e) { return {}; }
  }
  function snapshotLegacy(storage, options) {
    options = options || {};
    var values = Object.create(null);
    SOURCE_KEYS.forEach(function (key) { values[key] = safeRead(storage, key); });
    var settings = Object.assign({}, parseSettings(values["blizi.settings"]), parseSettings(values["blizi.settings.manus.v1"]));
    var seed = root.BliziCoreSeed ? root.BliziCoreSeed.projectLegacySettings(settings) : { profileId: SC.PROFILE_ID, canonicalSchemaApplied: false };
    var payload = { keys: values, identitySeedCandidate: seed };
    var text = JSON.stringify(payload);
    var bytes = typeof TextEncoder === "function" ? new TextEncoder().encode(text).length : text.length * 2;
    var maxBytes = Math.max(65536, Number(options.maxBytes) || 12 * 1024 * 1024);
    return { payload: payload, digest: hashText(text), bytes: bytes, maxBytes: maxBytes };
  }
  function create(adapter, options) {
    options = options || {};
    if (!adapter) throw SC.error("storage_required");
    var profileId = options.profileId || SC.PROFILE_ID;
    if (profileId !== SC.PROFILE_ID) throw SC.error("profile_mismatch");
    async function refreshLegacySnapshot(storage) {
      if (!storage || typeof storage.getItem !== "function") return { ok: true, status: "source_unavailable", changed: false };
      var snapshot;
      try { snapshot = snapshotLegacy(storage, options); }
      catch (e) { return { ok: false, status: e.code || "source_unavailable", changed: false }; }
      if (snapshot.bytes > snapshot.maxBytes) return { ok: false, status: "snapshot_too_large", bytes: snapshot.bytes, changed: false };
      var existing;
      try { existing = await adapter.get("migrations", MIGRATION_ID); }
      catch (e) { return { ok: false, status: e.code || "storage_read_failed", changed: false }; }
      if (existing && existing.sourceDigest === snapshot.digest) {
        return { ok: true, status: "unchanged", changed: false, revision: existing.revision || 1, sourceKeys: SOURCE_KEYS.length };
      }
      var now = typeof options.now === "function" ? options.now() : Date.now();
      var record = SC.createEnvelope("migrations", {
        id: MIGRATION_ID,
        profileId: profileId,
        kind: "legacy-local-snapshot",
        state: "staged",
        revision: existing ? (Number(existing.revision) || 1) + 1 : 1,
        source: "localStorage",
        sourceDigest: snapshot.digest,
        sourceBytes: snapshot.bytes,
        capturedAt: new Date(now).toISOString(),
        payload: snapshot.payload,
        schemaMapped: false
      }, { profileId: profileId, now: now });
      try {
        if (options.events) {
          await options.events.mutate({
            store: "migrations", op: existing ? "update" : "create", actor: "migration", id: MIGRATION_ID,
            profileId: profileId, summary: "Staged a refreshable copy of legacy local data",
            patch: { source: "localStorage", revision: record.revision }, record: record
          });
        } else await adapter.put("migrations", record);
      } catch (e) { return { ok: false, status: e.code || "migration_write_failed", changed: false }; }
      return { ok: true, status: existing ? "refreshed" : "staged", changed: true, revision: record.revision, sourceKeys: SOURCE_KEYS.length, bytes: snapshot.bytes };
    }
    return { refreshLegacySnapshot: refreshLegacySnapshot, sourceKeys: SOURCE_KEYS.slice(), migrationId: MIGRATION_ID };
  }

  root.BliziCoreMigrations = { create: create, snapshotLegacy: snapshotLegacy, sourceKeys: SOURCE_KEYS.slice(), migrationId: MIGRATION_ID };
})(window);
