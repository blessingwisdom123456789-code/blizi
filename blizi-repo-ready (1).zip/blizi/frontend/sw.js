// BLIZI service worker: network-first for the app shell with an offline fallback. API calls and cross-origin requests are never touched.
const CACHE = "blizi-shell-v15";
const SHELL = ["./", "./index.html", "./avatar/expression-map.js", "./avatar/blink-config.js", "./avatar/blink-scheduler.js", "./avatar/svg-renderer.js", "./avatar/avatar-controller.js", "./avatar/expression-arbiter.js", "./core/body-intent.js", "./core/self-model.js", "./core/core-schema.js", "./core/core-store.js", "./core/core-events.js", "./core/core-seed.js", "./core/identity.js", "./core/context-assembler.js", "./core/proactive.js", "./core/core-migrations.js", "./core/mood.js", "./core/core-avatar-bridge.js", "./core/relationship.js", "./core/episodes.js", "./core/facts.js", "./core/projects.js", "./core/core-state.js", "./core/voice-profile.js", "./tools/registry.js", "./tools/native-bridge.js", "./tools/native-tools.js", "./tools/agent-loop.js", "./config.js", "./tools/reminders.js", "./tools/todos.js", "./tools/extras.js", "./tools/device.js", "./tools/web-info.js", "./tools/page-actions.js", "./manifest.webmanifest", "./icons/icon-192.png", "./icons/icon-512.png"];
const API = ["/chat", "/tts", "/memory", "/auth/"];
self.addEventListener("install", e => { e.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL)).then(() => self.skipWaiting())); });
self.addEventListener("activate", e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener("fetch", e => {
  const r = e.request, u = new URL(r.url);
  if (r.method !== "GET" || u.origin !== self.location.origin || API.some(p => u.pathname.startsWith(p))) return;
  e.respondWith(fetch(r).then(res => { if (res.ok) { const c = res.clone(); caches.open(CACHE).then(x => x.put(r, c)); } return res; })
    .catch(() => caches.match(r).then(m => m || caches.match("./index.html"))));
});
self.addEventListener("notificationclick", e => {
  e.notification.close();
  e.waitUntil(self.clients.matchAll({ type: "window", includeUncontrolled: true }).then(list => {
    for (const c of list) { if ("focus" in c) return c.focus(); }
    return self.clients.openWindow("./");
  }));
});
