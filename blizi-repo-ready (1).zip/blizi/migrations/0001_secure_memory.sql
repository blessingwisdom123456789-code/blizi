-- BLIZI Stage 2 foundation. Apply to a NEW D1 database before deploying the Worker.
-- User content is stored only as application-encrypted AES-GCM ciphertext.
CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY CHECK (length(token_hash) = 64),
  user_id TEXT NOT NULL CHECK (length(user_id) BETWEEN 1 AND 128),
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sessions_expiry ON sessions (expires_at);

CREATE TABLE IF NOT EXISTS rate_limits (
  bucket_key TEXT PRIMARY KEY CHECK (length(bucket_key) <= 160),
  window_start INTEGER NOT NULL,
  count INTEGER NOT NULL CHECK (count >= 0)
);

CREATE TABLE IF NOT EXISTS user_data (
  user_id TEXT PRIMARY KEY CHECK (length(user_id) BETWEEN 1 AND 128),
  payload_ciphertext TEXT NOT NULL CHECK (length(payload_ciphertext) <= 1400000),
  updated_at INTEGER NOT NULL
);
