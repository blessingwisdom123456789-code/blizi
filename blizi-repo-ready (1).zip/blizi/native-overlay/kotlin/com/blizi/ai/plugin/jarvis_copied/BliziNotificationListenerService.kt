package com.blizi.ai.plugin.jarvis_copied

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Keeps the most recent notifications IN MEMORY ONLY (nothing is written to disk).
 * Adapted from JARVIS' InboxNotificationListenerService, but not limited to mail/SMS apps,
 * so WhatsApp and other messengers are captured too.
 */
class BliziNotificationListenerService : NotificationListenerService() {

    companion object {
        @Volatile
        var isConnected: Boolean = false
            private set

        private const val MAX_SAVED = 50
        private val captured = CopyOnWriteArrayList<Map<String, Any>>()

        /** Newest first. Optionally filtered by package name. */
        fun recent(limit: Int, pkg: String?): List<Map<String, Any>> {
            val all = captured.toList()
            val filtered = if (pkg.isNullOrBlank()) all else all.filter { it["package"] == pkg }
            return filtered.take(limit.coerceIn(1, MAX_SAVED))
        }
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        isConnected = true
        try {
            activeNotifications?.forEach { process(it) }
        } catch (_: Exception) {
        }
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        isConnected = false
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        if (sbn != null) process(sbn)
    }

    private fun process(sbn: StatusBarNotification) {
        val pkg = sbn.packageName ?: return
        if (pkg == packageName) return // ignore Blizi's own notifications
        val extras = sbn.notification?.extras ?: return

        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return

        val item: Map<String, Any> = hashMapOf(
            "package" to pkg,
            "title" to title,
            "text" to text,
            "timestamp" to sbn.postTime
        )
        captured.removeAll { it["package"] == pkg && it["title"] == title && it["text"] == text }
        captured.add(0, item)
        while (captured.size > MAX_SAVED) captured.removeAt(captured.size - 1)
    }
}
