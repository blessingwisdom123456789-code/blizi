package com.blizi.ai.plugin

import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import com.blizi.ai.plugin.jarvis_copied.AgentAccessibilityService
import com.blizi.ai.plugin.jarvis_copied.BliziNotificationListenerService
import com.getcapacitor.JSArray
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin

/**
 * Capacitor plugin: the phone "body" Blizi's brain acts through.
 * Every method resolves {ok:true,...} or {ok:false,error:"code"}; nothing throws into JS silently.
 */
@CapacitorPlugin(name = "BliziNativeBridge")
class BliziNativeBridgePlugin : Plugin() {

    private val service: AgentAccessibilityService?
        get() = AgentAccessibilityService.instance

    private fun ok(call: PluginCall, extra: JSObject = JSObject()) {
        extra.put("ok", true)
        call.resolve(extra)
    }

    private fun fail(call: PluginCall, error: String) {
        val o = JSObject()
        o.put("ok", false)
        o.put("error", error)
        call.resolve(o)
    }

    private fun startSettings(call: PluginCall, action: String) {
        try {
            val i = Intent(action)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(i)
            ok(call)
        } catch (e: Exception) {
            fail(call, "settings_unavailable")
        }
    }

    // ---- status / permissions --------------------------------------------------------------

    @PluginMethod
    fun getStatus(call: PluginCall) {
        val enabledList = Settings.Secure.getString(
            context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ).orEmpty()
        val component = ComponentName(context, AgentAccessibilityService::class.java).flattenToString()
        val o = JSObject()
        o.put("accessibilityConnected", AgentAccessibilityService.isConnected)
        o.put("accessibilityEnabledInSettings", enabledList.contains(component))
        o.put(
            "notificationListenerEnabled",
            NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName)
        )
        o.put("notificationListenerConnected", BliziNotificationListenerService.isConnected)
        o.put("sdk", android.os.Build.VERSION.SDK_INT)
        ok(call, o)
    }

    @PluginMethod
    fun openAccessibilitySettings(call: PluginCall) =
        startSettings(call, Settings.ACTION_ACCESSIBILITY_SETTINGS)

    @PluginMethod
    fun openNotificationSettings(call: PluginCall) =
        startSettings(call, "android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")

    // ---- apps ---------------------------------------------------------------------------------

    /** `name` is an app label ("WhatsApp") or a package id ("com.whatsapp"). */
    @PluginMethod
    fun openApp(call: PluginCall) {
        val name = (call.getString("name") ?: call.getString("package") ?: "").trim()
        if (name.isEmpty()) return fail(call, "missing_name")
        val pm = context.packageManager

        var pkg: String? = null
        if (name.contains('.') && pm.getLaunchIntentForPackage(name) != null) {
            pkg = name
        } else {
            val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val matches = pm.queryIntentActivities(launcher, 0)
            val wanted = name.lowercase()
            val exact = matches.firstOrNull { it.loadLabel(pm).toString().lowercase() == wanted }
            val partial = matches.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(wanted) }
            pkg = (exact ?: partial)?.activityInfo?.packageName
        }
        if (pkg == null) return fail(call, "app_not_found")

        val intent = pm.getLaunchIntentForPackage(pkg) ?: return fail(call, "app_not_found")
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            context.startActivity(intent)
            val o = JSObject()
            o.put("package", pkg)
            ok(call, o)
        } catch (e: Exception) {
            fail(call, "launch_failed")
        }
    }

    // ---- screen control (accessibility) ---------------------------------------------------

    @PluginMethod
    fun readScreen(call: PluginCall) {
        val svc = service ?: return fail(call, "accessibility_not_enabled")
        val nodes = try {
            svc.dumpScreen()
        } catch (e: Exception) {
            return fail(call, "read_failed")
        }
        val arr = JSArray()
        for (node in nodes) {
            val n = JSObject()
            for ((k, v) in node) {
                when (v) {
                    is Boolean -> n.put(k, v)
                    is Int -> n.put(k, v)
                    is Long -> n.put(k, v)
                    is Float -> n.put(k, v.toDouble())
                    is Double -> n.put(k, v)
                    else -> n.put(k, v.toString())
                }
            }
            arr.put(n)
        }
        val o = JSObject()
        o.put("nodes", arr)
        ok(call, o)
    }

    @PluginMethod
    fun tap(call: PluginCall) {
        val svc = service ?: return fail(call, "accessibility_not_enabled")
        val x = call.getDouble("x")
        val y = call.getDouble("y")
        if (x == null || y == null) return fail(call, "missing_xy")
        // true means the system accepted the gesture, not that the app reacted to it.
        if (svc.clickAt(x.toFloat(), y.toFloat())) ok(call) else fail(call, "tap_rejected")
    }

    @PluginMethod
    fun scroll(call: PluginCall) {
        val svc = service ?: return fail(call, "accessibility_not_enabled")
        val dir = call.getString("direction") ?: "down"
        if (svc.scroll(dir)) ok(call) else fail(call, "scroll_failed")
    }

    @PluginMethod
    fun typeText(call: PluginCall) {
        val svc = service ?: return fail(call, "accessibility_not_enabled")
        val text = call.getString("text") ?: return fail(call, "missing_text")
        if (svc.typeText(text)) ok(call) else fail(call, "no_editable_field")
    }

    @PluginMethod
    fun pressKey(call: PluginCall) {
        val svc = service ?: return fail(call, "accessibility_not_enabled")
        val key = call.getString("key") ?: return fail(call, "missing_key")
        if (svc.pressKey(key)) ok(call) else fail(call, "key_failed")
    }

    // ---- notifications ------------------------------------------------------------------------

    @PluginMethod
    fun getNotifications(call: PluginCall) {
        if (!BliziNotificationListenerService.isConnected) {
            return fail(call, "notification_listener_not_enabled")
        }
        val limit = call.getInt("limit") ?: 10
        val items = BliziNotificationListenerService.recent(limit, call.getString("package"))
        val arr = JSArray()
        for (item in items) {
            val n = JSObject()
            for ((k, v) in item) {
                when (v) {
                    is Long -> n.put(k, v)
                    else -> n.put(k, v.toString())
                }
            }
            arr.put(n)
        }
        val o = JSObject()
        o.put("notifications", arr)
        ok(call, o)
    }

    // ---- SMS ------------------------------------------------------------------------------------

    /** Opens the SMS app with the message filled in. The user taps Send; nothing is sent from here. */
    @PluginMethod
    fun composeSms(call: PluginCall) {
        val number = (call.getString("number") ?: "").trim()
        val message = call.getString("message") ?: ""
        if (number.isEmpty()) return fail(call, "missing_number")
        try {
            val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number)))
            i.putExtra("sms_body", message)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(i)
            ok(call)
        } catch (e: Exception) {
            fail(call, "no_sms_app")
        }
    }
}
