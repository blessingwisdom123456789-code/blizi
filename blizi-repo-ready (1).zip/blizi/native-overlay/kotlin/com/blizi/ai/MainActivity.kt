package com.blizi.ai

import android.os.Bundle
import com.blizi.ai.plugin.BliziNativeBridgePlugin
import com.getcapacitor.BridgeActivity

class MainActivity : BridgeActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        // Local plugins must be registered BEFORE super.onCreate, or the JS side never sees them.
        registerPlugin(BliziNativeBridgePlugin::class.java)
        super.onCreate(savedInstanceState)
    }
}
