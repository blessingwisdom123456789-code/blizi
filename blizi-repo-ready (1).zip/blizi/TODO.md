# BLIZI AI launch outcomes

## Core State v1 — Phase A milestone
- [x] Add the identity record (`idn_main`) with a SHA-256 hard-boundary integrity hash.
- [x] Add the bounded identity-only Context Assembly module with a 3000-character ceiling.
- [x] Wire `S.core` modes so `off` keeps the legacy prompt, `shadow` builds but sends legacy, and `on` uses Core context with fallback.
- [x] Serve and precache the Phase A modules.
- [x] Add identity tamper, context-cap, and prompt-mode regression tests before enabling Core State by default (tests/core-identity.test.mjs, tests/core-context.test.mjs). Core is still default OFF; Settings now has a Memory & mood switch (Off / Test only / On, reload to apply).
- [ ] Decide the prompt cap: the default (Core off) prompt is capped at 1950 chars and the system prompt itself is ~1335, so saved notes only get ~600 of their 1000 allowed characters. The backend accepts 3000. Raising PROMPT_MAX in index.html restores the room.
- [ ] Phases F (journal) and G (evolution).
- [ ] Ideas from the Jarvis project not built yet: hands-free wake word with a ~7 s follow-up window (Chrome only, unreliable on iPhone) and splitting compound requests ("remind me at 5, add eggs to my list") into separate actions.
- [ ] Turn on "Check in on me" on your phone and see whether the timing feels right (she only runs while the app is open; a closed web app cannot speak up).
- [ ] On a real phone: check the talking mouth, the held emotion during speech, and that Core On remembers a fact across an app restart (verified only in desktop Chromium so far).

## Previous Stage 3 work

### Existing Stage 3 source integrity — complete
- Obtain the existing `blizi-ai-stage3.zip` from the upload or available project workspace; if inaccessible, ask once for the ZIP upload.
- Verify SHA-256 `78b27bcf20d5bc23b497acfd80e5a1fa0158edc090733bff77992ff31592a310` before deployment.
- Preserve the original Stage 3 project; do not rebuild BLIZI from scratch or replace its character, interface, personality, voice, visual assets, manifest, icons, service worker, or current functionality.

### Previous public PWA — complete as frontend-only
- Deploy the existing frontend to a real, publicly accessible HTTPS URL that opens in Chrome on Android.
- Configure and preserve the original PWA behavior so its name, icon, manifest, and service worker work and the website is installable from Chrome on Android.
- Publish the original website first; do not substitute a newly designed or static mock application.

### Previous staging backend — still not deployed
- Configure the existing backend and AI integration only as far as credentials and authorized services allow; never expose API keys in frontend code.
- Reuse existing Stage 3 work and the already-created staging D1 database where appropriate; do not create duplicate infrastructure unnecessarily.
- Leave Gemini pending until `GEMINI_API_KEY` can be configured securely server-side; report backend and AI as unavailable until verified.

## Current Manus-hosted v0.4.0 chat release

### Reuse the existing project and original v0.4.0 design — in progress
- Build and publish a website for “Blizi AI”, a friendly AI chat character, that works on a phone browser, on Manus-managed hosting (not the user's Cloudflare account).
- Reuse the available v0.4.0 ZIP design (`frontend/` and its chat page); do not rebuild BLIZI from scratch.
- Use the existing BLIZI AI Manus project and its current public link. Enable Server only on this project and keep the managed database off.
- Do not touch any of the user's Cloudflare resources.

### Server-side AI and abuse protection — in progress
- Keep any API key on the server side only. Use the Manus built-in AI if available so the owner need not supply a provider key; never ask for a secret in chat.
- Protect against credit drain with a per-visitor rate limit, a daily cap on AI requests, and a short maximum message length. The selected limits are: 5 requests per visitor per 10 minutes, 20 requests per visitor per UTC day, 100 AI requests per server process per UTC day, and a 500-character maximum for each user message.
- Make BLIZI's personality easy to edit in the plain-text file `config/blizi-personality.txt`.
- Report roughly how many Manus credits one chat message uses if the model/API exposes enough usage data to estimate it.

### Real browser verification and owner handoff — pending
- Test 3 user messages in a real browser and report the exact replies and any errors. Clearly state what is verified and what is not.
- Provide the complete source as a ZIP.
- Explain exactly how the owner can update the live site later while keeping the same public link.
- List everything created so the owner can delete it later, then stop and wait for review.

## Anime assistant roadmap

### Phase 1 — AvatarController abstraction — complete
- Create `frontend/avatar/avatar-controller.js` and `frontend/avatar/svg-renderer.js`.
- Move existing avatar responsibilities behind `setExpression(name)`, `setSpeaking(boolean)`, `setMouthLevel(value)`, `triggerBlink()`, and `setIdleState(state)`.
- Keep all existing SVG functionality working: current expressions, current blinking, current idle animations, and current speaking animation.
- Update `frontend/index.html` to use AvatarController rather than directly manipulating avatar state.
- Preserve `browserSpeak()`, `backendSpeak()`, `Body3D`, and existing chat functionality.
- Do not add new features; focus on architecture and compatibility.

### Phase 2 — Expanded centralized expression system — complete
- Support the expressions `neutral`, `happy`, `excited`, `embarrassed`, `confused`, `sad`, `angry`, `thinking`, `sleepy`, and `speaking`.
- Update the SVG renderer so each expression is visually distinct through eyebrow position, eye shape, mouth shape, and head tilt where appropriate.
- Preserve existing blinking behavior.
- Do not break the AvatarController APIs.
- Create a centralized expression mapping system so future VRM expressions can reuse the same expression names.
- Add fallback behavior when a renderer does not support a specific expression.
- Show file changes, implementation details, migration notes, and screenshots or rendered states if available.
- Keep all existing tests passing and add tests for the new expression states.

### Phase 3 — Blinking Realism — complete
- Preserve the existing APIs: `setExpression()`, `setSpeaking()`, `setMouthLevel()`, `triggerBlink()`, and `setIdleState()`.
- Move blink behavior into a renderer-independent system controlled by `AvatarController`.
- Implement random blink intervals between approximately 2 and 6 seconds, occasional double blinks, slightly longer blinks while thinking, more frequent blinks while sleepy, reduced blink frequency while speaking, and expression-aware blink timing.
- Preserve compatibility with `svg-renderer.js`, future `vrm-renderer.js`, the existing speech system, and the existing idle system.
- Add configuration values so blink timing can be adjusted without modifying core logic.
- Ensure only one blink scheduler exists at a time and prevent duplicate timers.
- Provide idempotent controller/scheduler/renderer teardown that clears owned timers, and do not destroy state when `pagehide` indicates the browser will retain the page in BFCache.
- Add tests covering blink interval generation, double blink behavior, expression-specific blink adjustments, scheduler lifecycle, and fallback behavior.
- Show files modified, implementation details, migration notes, and test results.
- Do not begin Phase 4; focus only on making blinking realistic and reusable.

### Core State Phase A — Foundation — in progress
- Establish Core State infrastructure behind `S.core = "off"` by default.
- Implement `core-state.js`, the storage kernel, event-log foundation, identity seed structure, and migration framework.
- Add necessary frontend/backend wiring without changing current behavior; preserve chat and the existing personality system when Core State is off.
- Preserve compatibility with `AvatarController`, the Expression Registry, Blink Scheduler, and future Idle Motion integration by using only public interfaces.
- Import existing local data non-destructively; keep every legacy key unchanged until a future schema-aware migration is verified.
- Keep profile compatibility using `profileId: "prof_main"`; sensitive-memory schema support must not enable sensitive-memory collection in v1.
- Add tests and include the new suites in the existing `npm test` command.
- Defer domain-record field validators and mood, relationship, episodic/semantic memory, project, journal, and evolution behavior until the Core State Schema documents are supplied.
