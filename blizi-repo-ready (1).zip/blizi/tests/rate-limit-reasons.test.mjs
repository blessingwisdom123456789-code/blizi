// The 429 response must say WHICH limit was hit and how long to wait, and the page must show that.
// Mock upstream only; frontend text function is run from the real index.html.
import assert from "node:assert/strict";
import fs from "node:fs";
import { createBliziChatService, CHAT_LIMITS } from "../backend/manus-chat.mjs";

let n = 0; const check = (v, l) => { assert.ok(v, l); n++; };
const origin = "https://site.test", env = { MANUS_API_URL: "https://llm.test", MANUS_API_KEY: "test-key-never-log" };
const body = { messages: [{ role: "user", content: "hi" }], system: "x" };
const fetchImpl = async () => new Response(JSON.stringify({ choices: [{ message: { content: "ok" } }], usage: { prompt_tokens: 1, completion_tokens: 1 } }), { status: 200, headers: { "content-type": "application/json" } });
const mk = (clock) => createBliziChatService({ env, fetchImpl, now: () => clock.t, personality: "p", allowedOrigin: origin });

{ // short window
  const c = { t: Date.UTC(2026, 10, 9, 12, 0, 0) }, s = mk(c);
  for (let i = 0; i < CHAT_LIMITS.perVisitorWindow; i++) await s.handle({ body, origin, visitor: "v" });
  c.t += 60_000; // one minute later
  const r = await s.handle({ body, origin, visitor: "v" });
  check(r.status === 429 && r.body.error === "rate_limited", "still returns 429 with error=rate_limited (unchanged key)");
  check(r.body.reason === "window", "reason=window when the 10-minute allowance is used");
  check(r.body.retryAfter > 0 && r.body.retryAfter <= 540, `retryAfter is the time until the oldest message leaves the window (${r.body.retryAfter}s)`);
}
{ // daily
  const c = { t: Date.UTC(2026, 10, 9, 12, 0, 0) }, s = mk(c);
  for (let i = 0; i < CHAT_LIMITS.perVisitorUtcDay; i++) { if (i && i % CHAT_LIMITS.perVisitorWindow === 0) c.t += CHAT_LIMITS.windowMs; await s.handle({ body, origin, visitor: "v" }); }
  const r = await s.handle({ body, origin, visitor: "v" });
  check(r.status === 429 && r.body.reason === "daily", "reason=daily when the visitor day allowance is used (even if the window is also full)");
  const left = Date.UTC(2026, 10, 10, 0, 0, 0) - c.t;
  check(Math.abs(r.body.retryAfter * 1000 - left) < 1500, "retryAfter counts down to the next UTC midnight");
}
{ // whole-server daily
  const c = { t: Date.UTC(2026, 10, 9, 12, 0, 0) }, s = mk(c);
  for (let i = 0; i < CHAT_LIMITS.perProcessUtcDay; i++) await s.handle({ body, origin, visitor: "v" + i });
  const r = await s.handle({ body, origin, visitor: "fresh" });
  check(r.status === 429 && r.body.reason === "server_daily", "reason=server_daily when the whole-site allowance is used");
}

// page text, from the real index.html
const html = fs.readFileSync(new URL("../frontend/index.html", import.meta.url), "utf8");
const m = html.match(/function limitText\(e\)\{[\s\S]*?\n  return"Too many requests\. Wait a moment, then retry\."\}/);
check(!!m, "limitText() exists in the page");
const limitText = new Function(m[0] + "; return limitText;")();
check(/lot of messages.*4 minutes/.test(limitText({ reason: "window", retryAfter: 200 })), "window message names the wait in minutes");
check(/today’s message limit.*3 hours.*UTC/.test(limitText({ reason: "daily", retryAfter: 3 * 3600 })), "daily message says it resets (hours, midnight UTC)");
check(/all of today’s AI messages/.test(limitText({ reason: "server_daily", retryAfter: 100 })), "server-wide message says the whole site is out for today");
check(limitText({}) === "Too many requests. Wait a moment, then retry." && limitText(null) === "Too many requests. Wait a moment, then retry.", "unknown/old responses fall back to the original message");
check(/45 seconds/.test(limitText({ reason: "window", retryAfter: 45 })), "short waits are shown in seconds");

console.log(`${n} passed, 0 failed (mock upstream; page text logic only, real screen NOT tested)`);
