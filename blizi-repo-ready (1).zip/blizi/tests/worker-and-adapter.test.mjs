import worker from "../backend/worker.js";
import fs from "fs";
import { mockD1, sha256 } from "./helpers/mock-d1.mjs";
let res,seen;let pass=0,fail=0;const ok=(c,n)=>{c?pass++:(fail++,console.log("FAIL:",n));if(c)console.log("ok  :",n)};
const DB=mockD1(), sessionToken="test-session-token";
await DB.sessions.set(await sha256(sessionToken),{user_id:"owner",created_at:Date.now(),expires_at:Date.now()+86400000});
const env={DB,BLIZI_AUTH_PASSWORD:"correct-horse-battery-staple",SESSION_SECRET:"test-session-secret-at-least-32-bytes",MEMORY_ENCRYPTION_KEY:"test-memory-encryption-key-at-least-32",BLIZI_COOKIE_INSECURE:"true",PROVIDER_URL:"https://provider.test/v1/chat/completions",PROVIDER_KEY:"SECRET-KEY-123",MODEL_FAST:"m-fast",MODEL_DEEP:"m-deep",ALLOWED_ORIGINS:"https://site.test, https://other.test"};
let providerMode="ok",lastProviderReq=null;
const realFetch=globalThis.fetch;
function call(path,init={},auth=true,target=env){const headers=new Headers(init.headers||{});if(auth)headers.set("Cookie","blizi_session="+sessionToken);return worker.fetch(new Request("https://worker.test"+path,{...init,headers}),target)}
globalThis.fetch=async(url,init)=>{
  const u=String(url);
  if(u.startsWith("https://provider.test")){
    lastProviderReq={url:u,headers:init.headers,body:JSON.parse(init.body)};
    if(providerMode==="429")return new Response("{}",{status:429});
    if(providerMode==="401")return new Response("{}",{status:401});
    if(providerMode==="500")return new Response("oops",{status:500});
    if(providerMode==="badjson")return new Response("not json",{status:200});
    if(providerMode==="empty")return new Response(JSON.stringify({choices:[{message:{content:""}}]}),{status:200});
    if(providerMode==="down")throw new TypeError("network");
    return new Response(JSON.stringify({choices:[{message:{content:"[happy] Hello from provider"}}]}),{status:200});
  }
  if(u.startsWith("https://worker.test")){ // adapter -> real worker handler
    const headers=new Headers(init.headers||{});if(!headers.has("Cookie"))headers.set("Cookie","blizi_session="+sessionToken);
    return worker.fetch(new Request(u,{...init,headers}),env);
  }
  throw new TypeError("blocked "+u);
};
const H=(o)=>({"Content-Type":"application/json","Origin":o||"https://site.test"});
const good={messages:[{role:"user",content:"hi"}],system:"be nice",tier:"fast"};
// --- authentication and persistent-memory API (D1 is simulated here)
const authDB=mockD1(), authEnv={...env,DB:authDB};
let ar=await worker.fetch(new Request("https://worker.test/auth/login",{method:"POST",headers:H(),body:JSON.stringify({password:"wrong-password"})}),authEnv);
ok(ar.status===401&&(await ar.json()).error==="invalid_credentials","invalid password rejected without disclosing credential details");
ar=await worker.fetch(new Request("https://worker.test/auth/login",{method:"POST",headers:H(),body:JSON.stringify({password:authEnv.BLIZI_AUTH_PASSWORD})}),authEnv);
let aj=await ar.json(), cookie=(ar.headers.get("set-cookie")||"").match(/blizi_session=([^;]+)/);
ok(ar.status===200&&aj.authenticated===true&&!!cookie,"valid password creates a session cookie");
ok(/HttpOnly/.test(ar.headers.get("set-cookie"))&&/SameSite=Lax/.test(ar.headers.get("set-cookie")),"development session cookie is HttpOnly and SameSite=Lax");
ar=await worker.fetch(new Request("https://worker.test/auth/session",{headers:{Cookie:"blizi_session="+cookie[1]}}),authEnv);
ok(ar.status===200&&(await ar.json()).authenticated,"valid session is recognized");
ar=await worker.fetch(new Request("https://worker.test/auth/logout",{method:"POST",headers:{...H(),Cookie:"blizi_session="+cookie[1]}}),authEnv);
ok(ar.status===200&&/Max-Age=0/.test(ar.headers.get("set-cookie")),"logout revokes the server session and expires cookie");
ar=await worker.fetch(new Request("https://worker.test/auth/session",{headers:{Cookie:"blizi_session="+cookie[1]}}),authEnv);
ok(ar.status===401,"revoked session cannot be reused");
const secureEnv={...env,DB:mockD1()};delete secureEnv.BLIZI_COOKIE_INSECURE;
ar=await worker.fetch(new Request("https://worker.test/auth/login",{method:"POST",headers:H(),body:JSON.stringify({password:secureEnv.BLIZI_AUTH_PASSWORD})}),secureEnv);
ok(ar.status===200&&/^__Host-blizi_session=/.test(ar.headers.get("set-cookie"))&&/; Secure/.test(ar.headers.get("set-cookie"))&&/SameSite=None/.test(ar.headers.get("set-cookie")),"production session cookie has __Host, Secure, HttpOnly, SameSite=None flags");
const incompleteEnv={...env};delete incompleteEnv.MEMORY_ENCRYPTION_KEY;
ar=await worker.fetch(new Request("https://worker.test/chat",{method:"POST",headers:{...H(),Cookie:"blizi_session="+sessionToken},body:JSON.stringify(good)}),incompleteEnv);
ok(ar.status===503,"missing required auth/encryption configuration fails closed");
ar=await worker.fetch(new Request("https://worker.test/tts",{method:"POST",headers:H(),body:JSON.stringify({text:"hi"})}),env);ok(ar.status===401,"secure mode: /tts requires a session");
ar=await worker.fetch(new Request("https://worker.test/tts",{method:"POST",headers:{...H(),Cookie:"blizi_session="+sessionToken},body:JSON.stringify({text:"hi"})}),env);ok(ar.status===503&&(await ar.json()).error==="tts_not_configured","secure mode: a valid session reaches /tts (TTS not configured in this env)");
const throttleDB=mockD1(), throttleEnv={...env,DB:throttleDB};let lastLoginStatus=0;
for(let i=0;i<6;i++){ar=await worker.fetch(new Request("https://worker.test/auth/login",{method:"POST",headers:{...H(),"CF-Connecting-IP":"192.0.2.44"},body:JSON.stringify({password:"bad-password"})}),throttleEnv);lastLoginStatus=ar.status;}
ok(lastLoginStatus===429,"excessive login attempts are throttled by client IP");
// Seed a second principal to exercise data isolation; production login only provisions the single owner.
const otherToken="other-test-session";
await DB.sessions.set(await sha256(otherToken),{user_id:"other-account",created_at:Date.now(),expires_at:Date.now()+86400000});
const memoryPayload={memory:"Likes cats",notes:"Keep answers brief",conversations:{cur:"conv-1",list:[{id:"conv-1",t:123,msgs:[{who:"user",t:"10:00",text:"Hello"},{who:"bot",t:"10:01",text:"Hi",ai:true}]}]}};
ar=await call("/memory",{method:"PUT",headers:H(),body:JSON.stringify({...memoryPayload,userId:"other-account"})});
ok(ar.status===200&&(await ar.json()).saved,"authorized owner can save cloud memory, notes, and chat history");
const storedCipher=DB.userData.get("owner").payload_ciphertext;
ok(typeof storedCipher==="string"&&storedCipher.split(".").length===2&&!storedCipher.includes("Likes cats"),"D1 mock stores AES-GCM ciphertext, not plaintext memory");
ar=await call("/memory",{method:"GET",headers:H()});aj=await ar.json();
ok(ar.status===200&&aj.memory==="Likes cats"&&aj.notes==="Keep answers brief"&&aj.conversations.list[0].msgs.length===2,"memory export returns saved memory, notes, and conversations");
const wrongKeyEnv={...env,MEMORY_ENCRYPTION_KEY:"different-memory-key-material-at-least-32"};
ar=await worker.fetch(new Request("https://worker.test/memory",{headers:{...H(),Cookie:"blizi_session="+sessionToken}}),wrongKeyEnv);aj=await ar.json();
ok(ar.status===500&&aj.error==="storage_error"&&!JSON.stringify(aj).includes("Likes cats"),"wrong memory key fails closed with generic storage error");
ar=await call("/memory",{method:"PUT",headers:H(),body:JSON.stringify({...memoryPayload,conversations:{cur:null,list:[{id:"x",t:1,msgs:[{who:"system",t:"",text:"inject"}]}]}})});
ok(ar.status===400,"memory payload rejects unsupported message roles");
const otherPayload={memory:"other private memory",notes:"other note",conversations:{cur:null,list:[]}};
ar=await worker.fetch(new Request("https://worker.test/memory",{method:"PUT",headers:{...H(),Cookie:"blizi_session="+otherToken},body:JSON.stringify(otherPayload)}),env);
ok(ar.status===200,"second principal stores its own encrypted cloud record");
ar=await worker.fetch(new Request("https://worker.test/memory",{headers:{...H(),Cookie:"blizi_session="+otherToken}}),env);aj=await ar.json();
ok(ar.status===200&&aj.memory==="other private memory"&&aj.notes==="other note","memory queries are scoped to the authenticated session principal");
ar=await call("/memory",{method:"DELETE",headers:H()});
ok(ar.status===200&&(await ar.json()).deleted&&!DB.userData.has("owner")&&DB.userData.has("other-account"),"delete removes only the signed-in owner's cloud data");
const throttleChatDB=mockD1(), throttleChatEnv={...env,DB:throttleChatDB};
await throttleChatDB.sessions.set(await sha256(sessionToken),{user_id:"owner",created_at:Date.now(),expires_at:Date.now()+86400000});
let lastChatStatus=0;
for(let i=0;i<31;i++){ar=await worker.fetch(new Request("https://worker.test/chat",{method:"POST",headers:{...H(),Cookie:"blizi_session="+sessionToken},body:JSON.stringify(good)}),throttleChatEnv);lastChatStatus=ar.status;}
ok(lastChatStatus===429,"excessive authenticated chat requests are throttled");
// --- worker
let r=await call("/chat",{method:"OPTIONS",headers:{Origin:"https://site.test"}});ok(r.status===204&&r.headers.get("access-control-allow-origin")==="https://site.test","preflight allowed origin");
r=await call("/chat",{method:"OPTIONS",headers:{Origin:"https://evil.test"}});ok(r.status===403,"preflight denied origin");
r=await call("/chat",{method:"POST",headers:H("https://evil.test"),body:JSON.stringify(good)});ok(r.status===403,"POST from disallowed origin rejected");
r=await call("/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(good)});ok(r.status===403,"POST without Origin rejected");
r=await call("/chat",{method:"POST",headers:H(),body:JSON.stringify(good)},false);ok(r.status===401,"unauthenticated chat rejected with allowed Origin");
r=await call("/chat",{method:"POST",headers:{...H(),Cookie:"blizi_session=forged"},body:JSON.stringify(good)},false);ok(r.status===401,"invalid session cookie rejected");
r=await call("/chat",{method:"GET",headers:{Origin:"https://site.test"}});ok(r.status===405,"GET rejected");
r=await call("/chat",{method:"POST",headers:H(),body:"{bad"});ok(r.status===400,"bad JSON");
r=await call("/chat",{method:"POST",headers:H(),body:JSON.stringify({messages:[]})});ok(r.status===400,"empty messages");
r=await call("/chat",{method:"POST",headers:H(),body:JSON.stringify({messages:[{role:"assistant",content:"x"}]})});ok(r.status===400,"last must be user");
r=await call("/chat",{method:"POST",headers:H(),body:JSON.stringify({messages:[{role:"system",content:"x"}]})});ok(r.status===400,"system role injection rejected");
r=await call("/chat",{method:"POST",headers:H(),body:JSON.stringify({messages:[{role:"user",content:"x".repeat(7000)}]})});ok(r.status===400,"oversized message rejected");
r=await call("/chat",{method:"POST",headers:H(),body:"x".repeat(200000)});ok(r.status===413,"oversized body rejected");
r=await call("/chat",{method:"POST",headers:H(),body:JSON.stringify(good)});let j=await r.json();
ok(r.status===200&&j.text==="[happy] Hello from provider","success path returns text");
ok(lastProviderReq.headers.Authorization==="Bearer SECRET-KEY-123"&&lastProviderReq.body.model==="m-fast"&&lastProviderReq.body.messages[0].role==="system","provider got key server-side, fast model, system first");
ok(!JSON.stringify(j).includes("SECRET")&&![...r.headers.values()].join().includes("SECRET"),"key not in response");
r=await call("/chat",{method:"POST",headers:H(),body:JSON.stringify({...good,tier:"deep"})});await r.json();ok(lastProviderReq.body.model==="m-deep","deep tier uses deep model");
for(const [m,st,e] of [["429",429,"provider_rate_limited"],["401",502,"provider_auth_failed"],["500",502,"provider_error"],["badjson",502,"provider_bad_response"],["empty",502,"provider_bad_response"],["down",504,"provider_unreachable"]]){
  providerMode=m;r=await call("/chat",{method:"POST",headers:H(),body:JSON.stringify(good)});j=await r.json();ok(r.status===st&&j.error===e,"provider "+m+" -> "+st+" "+e);ok(!JSON.stringify(j).includes("SECRET"),"no key leak on "+m);}
providerMode="ok";
const saved={...env};delete env.PROVIDER_KEY;r=await call("/chat",{method:"POST",headers:H(),body:JSON.stringify(good)});ok(r.status===500,"missing config -> 500");env.PROVIDER_KEY=saved.PROVIDER_KEY;
// --- adapter (extracted from the real file)
const src=fs.readFileSync(new URL("../frontend/index.html",import.meta.url),"utf8");
const block=src.slice(src.indexOf("/* ai-adapter */"),src.indexOf("/* /ai-adapter */"));
function mk(win,S){return new Function("window","S","fetch","AbortController","URL",block+";return AI")(win,S,globalThis.fetch,AbortController,URL)}
let S={provider:"auto",url:"https://worker.test/chat"};
let AI=mk({},S);
ok(AI.validUrl("https://a.com/x")&&AI.validUrl("http://localhost:8787/c")&&!AI.validUrl("http://a.com")&&!AI.validUrl("https://u:p@a.com")&&!AI.validUrl("javascript:alert(1)")&&!AI.validUrl("sk-abc"),"validUrl rules");
ok(AI.kind()==="backend"&&AI.ready(),"auto picks backend when URL set");
// origin: adapter fetch has no Origin header in node, so worker rejects -> exercise error mapping
S.url="https://worker.test/chat";
try{await AI.complete([{role:"user",content:"hi"}],{});ok(false,"expected denial (no Origin in node)")}catch(e){ok(e.code==="backend_denied"&&/origin not allowed/.test(e.message),"403 mapped to backend_denied with reason")}
// emulate browser Origin so we can test success + 429 mapping end to end
const orig=globalThis.fetch;globalThis.fetch=(u,i)=>orig(u,{...i,headers:{...i.headers,Origin:"https://site.test"}});
AI=mk({},S);res=await AI.complete([{role:"user",content:"hi"}],{system:"s"});ok(res.text.includes("Hello"),"round trip with browser-like Origin");
seen="";res=await AI.complete([{role:"user",content:"hi"}],{system:"sys",tier:"fast",onText:o=>seen=o.text});
ok(res.text==="[happy] Hello from provider"&&seen===res.text,"adapter -> real worker -> mock provider round trip");

providerMode="429";try{await AI.complete([{role:"user",content:"hi"}],{});ok(false,"x")}catch(e){ok(e.code==="rate_limited","429 -> rate_limited")}providerMode="500";
try{await AI.complete([{role:"user",content:"hi"}],{});ok(false,"x")}catch(e){ok(e.code==="backend_error","502 -> backend_error")}providerMode="ok";
globalThis.fetch=orig;
globalThis.fetch=async()=>{throw new TypeError("Failed to fetch")};AI=mk({},S);
try{await AI.complete([{role:"user",content:"hi"}],{});ok(false,"x")}catch(e){ok(e.code==="network","fetch failure -> network")}
globalThis.fetch=(u,i)=>new Promise((_,rej)=>i.signal.addEventListener("abort",()=>rej(new DOMException("a","AbortError"))));AI=mk({},S);
const ctl=new AbortController();const p=AI.complete([{role:"user",content:"hi"}],{signal:ctl.signal});setTimeout(()=>ctl.abort(),20);
try{await p;ok(false,"x")}catch(e){ok(e.code==="aborted","user abort -> aborted")}
globalThis.fetch=async()=>new Response("<html>",{status:200});AI=mk({},S);try{await AI.complete([{role:"user",content:"hi"}],{});ok(false,"x")}catch(e){ok(e.code==="bad_response","non-JSON 200 -> bad_response")}
// page provider with fake sample
let got=null;const fakeSample=async(m,o)=>{got={m,o};o.onText&&o.onText({text:"streamed"});return{text:"[happy] ok"}};
const win={claude:{use:async n=>n==="sample"?fakeSample:null}};
S={provider:"auto",url:""};AI=mk(win,S);await new Promise(r=>AI.init(r));
ok(AI.kind()==="page"&&AI.ready(),"auto picks page provider when no URL and claude.use exists");
await AI.complete([{role:"user",content:"hello"}],{system:"SYS",tier:"deep"});
ok(got.m[0].content.startsWith("SYS")&&got.m[0].content.endsWith("hello")&&got.o.modelTier==="default"&&got.o.cache===false,"page provider folds system into first turn, deep->default, no cache");
await AI.complete([{role:"user",content:"hello"}],{tier:"fast"});ok(got.o.modelTier==="quick","fast->quick");
AI=mk({},{provider:"auto",url:""});await new Promise(r=>AI.init(r));ok(!AI.ready()&&AI.state()==="none","no window.claude and no URL -> not ready (no silent fallback)");
try{await AI.complete([{role:"user",content:"hi"}],{});ok(false,"x")}catch(e){ok(e.code==="unavailable","complete() rejects when unavailable")}

// timeout path: shrink the 60s timer to 15ms
{const st=globalThis.setTimeout;globalThis.setTimeout=(f,d,...a)=>st(f,d===60000?15:d,...a);
globalThis.fetch=(u,i)=>new Promise((_,rej)=>i.signal.addEventListener("abort",()=>rej(new DOMException("a","AbortError"))));
AI=mk({},{provider:"auto",url:"https://worker.test/chat"});
try{await AI.complete([{role:"user",content:"hi"}],{});ok(false,"x")}catch(e){ok(e.code==="timeout","60s timeout -> timeout")}
globalThis.setTimeout=st;}
console.log(`\n${pass} passed, ${fail} failed`);
