// Spoken replies are ON by default, migrate once for old saved settings, and the quick button stays in sync.
// Logic extracted from the real index.html and run against fakes. A real phone voice is NOT tested.
import fs from "node:fs";
let pass = 0, fail = 0;
const ok = (c, n) => { c ? (pass++, console.log("ok  :", n)) : (fail++, console.log("FAIL:", n)); };
const html = fs.readFileSync(new URL("../frontend/index.html", import.meta.url), "utf8");
const voiceProfile = fs.readFileSync(new URL("../frontend/core/voice-profile.js", import.meta.url), "utf8");

ok(/var DEF=\{[^}]*speak:true/.test(html), "default settings have speak:true");
ok(/voiceGender:"female"/.test(html), "default voice profile is female");
ok(html.includes('src="core/voice-profile.js"'), "the female voice profile is loaded by the page");

const voiceWindow = {};
new Function("window", voiceProfile)(voiceWindow);
const selected = voiceWindow.BliziVoiceProfile.pickFemale([
  { name: "Microsoft David Desktop", lang: "en-US", localService: true },
  { name: "Microsoft Zira Desktop", lang: "en-US", localService: true },
  { name: "Google UK English Female", lang: "en-GB", localService: false }
], "en-US");
ok(selected && selected.name === "Microsoft Zira Desktop", "female voice ranking prefers a female voice in the requested language");
ok(voiceWindow.BliziVoiceProfile.pickFemale([{ name: "English (United States)", lang: "en-US", localService: true }], "en-US") === null, "unidentified voices are not used as a female fallback");

const mig = html.match(/if\(!S\.speakDefaultV2\)\{[^\n]*\}\n/);
ok(!!mig, "one-time migration exists");
function run(saved) {
  const store = { k: saved === undefined ? null : JSON.stringify(saved) };
  const localStorage = { setItem: (_, v) => { store.k = v; } };
  const S = Object.assign({ speak: true }, saved || {});
  new Function("S", "localStorage", "SETTINGS_KEY", mig[0])(S, localStorage, "k");
  return { S, saved: store.k && JSON.parse(store.k) };
}
let r = run({ speak: false });
ok(r.S.speak === true && r.S.speakDefaultV2 === true && r.saved.speak === true, "old saved setting (speak:false, no flag) is switched on once and saved");
r = run({ speak: false, speakDefaultV2: true });
ok(r.S.speak === false, "after the migration, a user who turns voice OFF stays off");
r = run(undefined);
ok(r.S.speak === true, "a brand-new visitor gets spoken replies on");

const fn = html.match(/function syncSpk\(\)\{[\s\S]*?\n/);
ok(!!fn, "syncSpk() exists");
function sync(speak) {
  const btn = { attrs: {}, textContent: "", setAttribute(k, v) { this.attrs[k] = v; } }, box = { checked: null };
  const $ = (s) => (s === "#spkQuick" ? btn : s === "#sSpeak" ? box : null);
  new Function("$", "S", fn[0] + "; syncSpk();")($, { speak });
  return { btn, box };
}
let x = sync(true);
ok(x.btn.textContent === "🔊 Voice on" && x.btn.attrs["aria-pressed"] === "true" && x.box.checked === true, "voice ON: button says Voice on and the Settings switch is on");
x = sync(false);
ok(x.btn.textContent === "🔇 Voice off" && x.btn.attrs["aria-pressed"] === "false" && x.box.checked === false, "voice OFF: button says Voice off and the Settings switch is off");
ok(html.includes('id="spkQuick"'), "the Voice button is in the Chat header");
console.log(`${pass} passed, ${fail} failed (logic from the real page on fakes; real phone voice NOT tested)`);
process.exit(fail ? 1 : 0);
