import fs from "node:fs";
import assert from "node:assert/strict";

const root = { structuredClone: globalThis.structuredClone };
new Function("window", fs.readFileSync(new URL("../frontend/avatar/expression-map.js", import.meta.url), "utf8"))(root);
new Function("window", fs.readFileSync(new URL("../frontend/avatar/expression-arbiter.js", import.meta.url), "utf8"))(root);

let now = 0;
let nextTimer = 0;
const timers = new Map();
const avatarState = { expression: "neutral", speaking: false };
const avatar = {
  getExpression: () => avatarState.expression,
  supportsExpression: expression => expression !== "sleepy",
  setExpression(expression) { avatarState.expression = expression; return expression; }
};
const arbiter = root.BliziExpressionArbiter.create({
  avatar,
  now: () => now,
  setTimeout: (fn, delay) => { const id = ++nextTimer; timers.set(id, { fn, at: now + delay }); return id; },
  clearTimeout: id => timers.delete(id)
});
const advance = ms => {
  const end = now + ms;
  for (;;) {
    const pending = [...timers.entries()].sort((a, b) => a[1].at - b[1].at)[0];
    if (!pending || pending[1].at > end) break;
    now = pending[1].at;
    timers.delete(pending[0]);
    pending[1].fn();
  }
  now = end;
};

assert.equal(arbiter.request({ source: "mood", expr: "sad" }).expression, "sad");
assert.equal(arbiter.request({ source: "reply-tag", expr: "excited", holdMs: 12000 }).expression, "excited");
assert.equal(arbiter.request({ source: "user-command", expr: "thinking", holdMs: 8000 }).expression, "thinking");
assert.equal(arbiter.getState().source, "user-command", "user-command outranks reply-tag and mood");
const explanation = arbiter.explain();
assert.equal(explanation.winner, "user-command");
assert.ok(explanation.layers.some(layer => layer.source === "mood" && layer.active), "explain lists active lower-priority layers");

advance(8001);
assert.equal(arbiter.current(), "excited", "expired user expression falls back to active reply-tag");
advance(4000);
assert.equal(arbiter.current(), "sad", "expired reply-tag falls back to mood");

const beforeTagless = arbiter.current();
const tagless = arbiter.request({ source: "reply-tag", expr: "" });
assert.equal(tagless.ok, false);
assert.equal(arbiter.current(), beforeTagless, "tagless reply does not replace the current expression");
assert.equal(arbiter.request({ source: "reply-tag", expr: "mystery-face" }).reason, "unknown_expression");
assert.equal(arbiter.current(), beforeTagless, "unknown expressions are rejected without changing state");
assert.equal(arbiter.request({ source: "reply-tag", expr: "sleepy" }).reason, "unsupported_renderer");
assert.equal(arbiter.current(), beforeTagless, "renderer-unsupported expressions are rejected without changing state");

let label = "";
const changes = [];
const unsubscribe = arbiter.onChange(event => { label = event.expression; changes.push(event); });
assert.equal(arbiter.request({ source: "user-command", expr: "angry", holdMs: 0 }).ok, true);
assert.equal(label, avatarState.expression, "arbiter change event keeps UI label aligned with avatar");
assert.equal(changes.at(-1).source, "user-command");
unsubscribe();
assert.equal(arbiter.clear("user-command").expression, "sad");
assert.equal(avatarState.expression, "sad", "clearing a layer applies the next winning expression to the avatar");

// ---- extend(): hold an emotion through speech, then let it linger
{
  let t2 = 0, id2 = 0; const tm2 = new Map(); const av2 = { s: "neutral", getExpression() { return this.s; }, supportsExpression: () => true, setExpression(x) { this.s = x; return x; } };
  const a2 = root.BliziExpressionArbiter.create({ avatar: av2, now: () => t2, setTimeout: (fn, d) => { const i = ++id2; tm2.set(i, { fn, at: t2 + d }); return i; }, clearTimeout: i => tm2.delete(i) });
  const adv2 = ms => { const end = t2 + ms; for (;;) { const p = [...tm2.entries()].sort((a, b) => a[1].at - b[1].at)[0]; if (!p || p[1].at > end) break; t2 = p[1].at; tm2.delete(p[0]); p[1].fn(); } t2 = end; };
  a2.request({ source: "mood", expr: "sleepy" }); a2.request({ source: "reply-tag", expr: "serious" });
  assert.equal(a2.extend("reply-tag", 180000).ok, true);
  adv2(60000); assert.equal(a2.current(), "serious", "extended reply emotion is held far past the default 5 s hold");
  assert.equal(a2.extend("reply-tag", 3500).ok, true);
  adv2(3400); assert.equal(a2.current(), "serious", "emotion lingers briefly after speech ends");
  adv2(200); assert.equal(a2.current(), "sleepy", "then falls back to the mood layer");
  assert.deepEqual([a2.extend("reply-tag", 1000).ok, a2.extend("reply-tag", 1000).reason], [false, "no_active_layer"], "extend never resurrects an expired or missing layer");
  a2.request({ source: "reply-tag", expr: "sad", holdMs: 5000 }); a2.extend("reply-tag", 0);
  adv2(600000); assert.equal(a2.current(), "sad", "extend with 0 makes the layer permanent until cleared");
  a2.clear("reply-tag"); assert.equal(a2.current(), "sleepy");
  assert.equal(typeof root.BliziExpressionArbiter.create({}).extend, "function", "extend works without an avatar");
}
console.log("25 passed, 0 failed (expression arbiter priority, holds, extend through speech, rejection, fallback, explanation, and synchronization)");
