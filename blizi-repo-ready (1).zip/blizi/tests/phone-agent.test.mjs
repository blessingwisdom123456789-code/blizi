import fs from "node:fs";
import assert from "node:assert/strict";
const load = (f, win = {}) => { new Function("window", fs.readFileSync(new URL("../frontend/tools/" + f, import.meta.url), "utf8"))(win); return win; };
let passed = 0;
const ok = async (name, fn) => { await fn(); passed++; console.log("ok  : " + name); };
const fresh = () => { const w = {}; load("registry.js", w); load("native-tools.js", w); load("agent-loop.js", w); return w; };
const calls = [];
const plugin = (over = {}) => new Proxy({}, { get: (_, m) => over[m] || (async (a) => { calls.push([m, a]); return { ok: true }; }) });
const inst = (w, p, extra = {}) => w.BliziNativeTools.install({ tools: w.BliziTools, plugin: p, sleep: async () => {}, ...extra });

await ok("web: nothing installs, no tools advertised", () => {
  const w = fresh(); assert.equal(w.BliziNativeTools.active(), false);
  assert.deepEqual(w.BliziTools.names(), []); assert.equal(w.BliziNativeTools.promptLine(), "");
  assert.equal(w.BliziNativeTools.fitSystem("base", 100), "base");
  w.Capacitor = { isNativePlatform: () => false, registerPlugin: () => plugin() };
  assert.equal(w.BliziNativeTools.install({ win: w }), false);
});
await ok("native: Capacitor.registerPlugin is used and tools register", () => {
  const w = fresh(); w.Capacitor = { isNativePlatform: () => true, registerPlugin: (n) => (assert.equal(n, "BliziNativeBridge"), plugin()) };
  assert.equal(w.BliziNativeTools.install({ win: w, sleep: async () => {} }), true);
  assert.deepEqual(w.BliziTools.names().sort(), ["compose_sms", "open_app", "open_settings", "phone_status", "press_key", "read_notifications", "read_screen", "scroll", "tap", "type_text"]);
  assert.ok(w.BliziNativeTools.promptLine().includes("Never say an action worked"));
});
await ok("prompt fits the system budget and keeps the tool list", () => {
  const w = fresh(); inst(w, plugin());
  const out = w.BliziNativeTools.fitSystem("x".repeat(2800), 3000);
  assert.ok(out.length <= 3000, "len " + out.length); assert.ok(out.includes("compose_sms("));
});
await ok("tools call the right plugin method and report evidence-based text", async () => {
  const w = fresh(); inst(w, plugin({ openApp: async (a) => (calls.push(["openApp", a]), { ok: true, package: "com.whatsapp" }) }));
  calls.length = 0;
  assert.equal(await w.BliziTools.execute("open_app", { name: "WhatsApp" }).result, "opened com.whatsapp");
  assert.equal(await w.BliziTools.execute("tap", { x: 10, y: 20 }).result, "tap sent (check read_screen to confirm it worked)");
  assert.deepEqual(calls.map((c) => c[0]), ["openApp", "tap"]); assert.deepEqual(calls[1][1], { x: 10, y: 20 });
  assert.equal(w.BliziTools.execute("tap", { x: -1, y: 2 }).error, "out_of_range:x");
  assert.equal(w.BliziTools.execute("press_key", { key: "power" }).error, "bad_value:key");
});
await ok("errors and rejected bridge calls surface as 'error:' text", async () => {
  const w = fresh(); inst(w, plugin({ readScreen: async () => ({ ok: false, error: "accessibility_not_enabled" }), tap: async () => { throw new Error("UNIMPLEMENTED"); } }));
  assert.equal(await w.BliziTools.execute("read_screen", {}).result, "error: accessibility_not_enabled");
  assert.equal(await w.BliziTools.execute("tap", { x: 1, y: 1 }).result, "error: bridge_failed: UNIMPLEMENTED");
});
await ok("read_screen output is compact and capped", async () => {
  const nodes = Array.from({ length: 200 }, (_, i) => ({ index: i, text: "Item number " + i, centerX: 5, centerY: i, isClickable: true }));
  const w = fresh(); inst(w, plugin({ readScreen: async () => ({ ok: true, nodes }) }), { maxResult: 600 });
  const r = await w.BliziTools.execute("read_screen", {}).result;
  assert.ok(r.length <= 600, "len " + r.length); assert.ok(r.includes("more items not shown")); assert.ok(r.includes("0|Item number 0|5,0|c"));
});
await ok("compose_sms needs confirmation; declined means nothing opens", async () => {
  const w = fresh(); inst(w, plugin()); calls.length = 0;
  const call = { name: "compose_sms", args: { number: "+100", message: "hi" } };
  let card = null;
  const out = await w.BliziAgent.run({ messages: [{ role: "user", content: "text mum" }], system: "s", tools: w.BliziTools, confirm: (c) => (card = c, false),
    complete: (() => { let n = 0; return async () => (n++ ? { text: "ok, not sent" } : { text: "[[tool compose_sms {\"number\":\"+100\",\"message\":\"hi\"}]]" }); })() });
  assert.ok(card.summary.includes("+100")); assert.equal(calls.length, 0); assert.equal(out.steps[0].status, "declined");
});
await ok("agent loop: runs tools, feeds results back, stops with final text", async () => {
  const w = fresh(); inst(w, plugin({ openApp: async () => ({ ok: true, package: "com.whatsapp" }) }));
  const seen = [], script = ["[thinking] [[tool open_app {\"name\":\"WhatsApp\"}]]", "[happy] WhatsApp is open."];
  const out = await w.BliziAgent.run({ messages: [{ role: "user", content: "open whatsapp" }], system: "s", tools: w.BliziTools, complete: async (m) => (seen.push(m.map((x) => x.role)), { text: script.shift() }) });
  assert.equal(out.text, "[happy] WhatsApp is open."); assert.equal(out.steps.length, 1);
  assert.deepEqual(seen[1], ["user", "assistant", "user"]);
});
await ok("agent loop: step cap is honest, abort stops, history stays within message cap", async () => {
  const w = fresh(); inst(w, plugin());
  const loop = { text: "[[tool scroll {\"direction\":\"down\"}]]" };
  const sizes = [];
  const capped = await w.BliziAgent.run({ messages: Array.from({ length: 19 }, (_, i) => ({ role: i % 2 ? "assistant" : "user", content: "m" + i })), system: "s", tools: w.BliziTools, maxSteps: 2, complete: async (m) => (sizes.push(m.length), loop) });
  assert.equal(capped.capped, true); assert.ok(capped.text.includes("stopped after 2 steps")); assert.ok(Math.max(...sizes) <= 20);
  const ac = new AbortController(); ac.abort();
  await assert.rejects(w.BliziAgent.run({ messages: [{ role: "user", content: "x" }], system: "s", tools: w.BliziTools, signal: ac.signal, complete: async () => loop }), (e) => e.code === "aborted");
});
await ok("'open app' command defers to the brain once phone tools exist", () => {
  const w = fresh(); load("reminders.js", w); load("todos.js", w); load("native-bridge.js", w); load("page-actions.js", w);
  const mk = (phone) => w.BliziActions.create({ R: w.BliziReminders, D: w.BliziTodos, native: w.BliziNative, phone, now: () => 0, load: () => null, save() {}, say() {}, notify() {}, beep() {} });
  assert.ok(mk(null).handle("open app Maps").reply.includes("needs the Blizi phone app"));
  assert.equal(mk(() => true).handle("open app Maps"), null);
});
console.log("\n" + passed + " phone-agent tests passed");
