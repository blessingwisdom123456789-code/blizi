import fs from "node:fs";

let pass = 0, fail = 0;
const ok = (condition, name) => { condition ? pass++ : (fail++, console.log("FAIL:", name)); if (condition) console.log("ok  :", name); };
const source = fs.readFileSync(new URL("../frontend/avatar/blink-scheduler.js", import.meta.url), "utf8");
const configSource = fs.readFileSync(new URL("../frontend/avatar/blink-config.js", import.meta.url), "utf8");
const mapSource = fs.readFileSync(new URL("../frontend/avatar/expression-map.js", import.meta.url), "utf8");

function clock() {
  let now = 0, nextId = 0;
  const tasks = new Map();
  return {
    get now() { return now; },
    setTimeout(fn, delay) { const id = ++nextId; tasks.set(id, { fn, at: now + Math.max(0, delay) }); return id; },
    clearTimeout(id) { tasks.delete(id); },
    pending() { return tasks.size; },
    nextDelay() { return tasks.size ? Math.min(...Array.from(tasks.values(), task => task.at - now)) : null; },
    advance(ms) {
      const target = now + ms;
      let turns = 0;
      while (true) {
        const next = Array.from(tasks.entries()).sort((a, b) => a[1].at - b[1].at)[0];
        if (!next || next[1].at > target) break;
        if (++turns > 1000) throw new Error("fake clock runaway");
        now = next[1].at;
        tasks.delete(next[0]);
        next[1].fn();
      }
      now = target;
    }
  };
}

const win = {};
new Function("window", mapSource)(win);
new Function("window", configSource)(win);
new Function("window", source)(win);
const create = win.BliziBlinkScheduler.create;
const base = create({ autoStart: false, random: () => 0.5 });
const range = base.getIntervalRange("neutral");
ok(range.min === 2000 && range.max === 6000 && base.getNextInterval("neutral") === 4000,
  "normal blink intervals are randomized within the configurable 2-6 second range");
ok(base.getConfig().baseMinIntervalMs === 2000 && base.getConfig().baseMaxIntervalMs === 6000,
  "the separate editable configuration supplies the default interval bounds");
ok(base.getBlinkDuration("thinking") > base.getBlinkDuration("happy"),
  "thinking expression produces a slightly longer blink");
const sleepyRange = base.getIntervalRange("sleepy"), speakingRange = base.getIntervalRange("speaking");
ok(sleepyRange.max < range.max && sleepyRange.min < range.min,
  "sleepy expression schedules more frequent blinks");
ok(speakingRange.min > range.min && speakingRange.max > range.max,
  "speaking expression reduces blink frequency");

const c = clock(), blinks = [];
const double = create({
  autoStart: false,
  config: { baseMinIntervalMs: 1000, baseMaxIntervalMs: 1000, doubleBlinkChance: 1, doubleBlinkDelayMinMs: 250, doubleBlinkDelayMaxMs: 250 },
  setTimeout: c.setTimeout.bind(c), clearTimeout: c.clearTimeout.bind(c), random: () => 0,
  onBlink: duration => { blinks.push({ at: c.now, duration }); return true; }
});
ok(double.start() === true && c.pending() === 1, "starting the scheduler creates exactly one pending timer");
ok(double.start() === false && c.pending() === 1, "repeated start calls do not create duplicate timers");
c.advance(1000);
ok(blinks.length === 1 && double.getState().phase === "double-blink" && c.pending() === 1,
  "a selected double blink schedules one delayed second blink, not a parallel scheduler");
c.advance(249); ok(blinks.length === 1, "the second blink waits for its configured delay");
c.advance(1);
ok(blinks.length === 2 && blinks[1].at - blinks[0].at === 250 && c.pending() === 1,
  "double blink fires twice at the configured spacing and returns to one interval timer");

const beforeDelay = c.nextDelay();
double.setExpression("sleepy");
ok(double.getState().expression === "sleepy" && c.pending() === 1 && c.nextDelay() !== beforeDelay,
  "expression changes replace the pending interval using the new expression timing");
double.setIdleState("paused");
ok(!double.getState().running && c.pending() === 0 && double.getState().phase === "stopped",
  "pausing idle cancels the only pending interval or double-blink timer");
ok(double.setIdleState("idle") === "idle" && double.getState().running && c.pending() === 1,
  "resuming idle restarts exactly one scheduler timer");
double.stop();
ok(!double.getState().running && c.pending() === 0 && double.stop() === false,
  "stop is idempotent and clears the pending timer");

const customClock = clock(), custom = create({
  autoStart: false, config: { baseMinIntervalMs: 900, baseMaxIntervalMs: 1800, doubleBlinkChance: 0 },
  setTimeout: customClock.setTimeout.bind(customClock), clearTimeout: customClock.clearTimeout.bind(customClock),
  random: () => 0, onBlink: () => false
});
ok(custom.getNextInterval() === 900 && custom.getConfig().baseMaxIntervalMs === 1800,
  "caller configuration overrides the default interval bounds");
custom.start(); customClock.advance(900);
ok(custom.getState().running && customClock.pending() === 1,
  "a renderer fallback that declines a blink is harmless and the scheduler continues");
custom.stop();

const throwingClock = clock(), throwing = create({
  autoStart: false, config: { baseMinIntervalMs: 500, baseMaxIntervalMs: 500, doubleBlinkChance: 0 },
  setTimeout: throwingClock.setTimeout.bind(throwingClock), clearTimeout: throwingClock.clearTimeout.bind(throwingClock),
  onBlink: () => { throw new Error("renderer unavailable"); }
});
throwing.start();
let threw = false;
try { throwingClock.advance(500); } catch (_) { threw = true; }
ok(!threw && throwing.getState().running && throwingClock.pending() === 1,
  "renderer errors are contained and do not duplicate or kill the scheduler");
throwing.stop();

// ---- Phase 3 additions: interval statistics, speaking tuning, rescaling, destroy, timer failures ----
const lo = create({ autoStart: false, random: () => 0 }), hi = create({ autoStart: false, random: () => 0.999999 });
ok(lo.getNextInterval("neutral") === 2000 && hi.getNextInterval("neutral") >= 5990 && hi.getNextInterval("neutral") <= 6000,
  "interval generation stays inside the 2-6 second bounds at both random extremes");
const badRandom = create({ autoStart: false, random: () => NaN });
ok(badRandom.getNextInterval("neutral") === 2000, "a broken random source falls back to the minimum interval instead of NaN");
let sampleOk = true, seed = 7;
const lcg = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
const sampler = create({ autoStart: false, random: lcg });
for (let i = 0; i < 500; i++) { const v = sampler.getNextInterval("neutral"); if (v < 2000 || v > 6000) sampleOk = false; }
ok(sampleOk, "500 pseudo-random intervals all fall between 2000 and 6000 ms");
const ratio = base.getIntervalRange("speaking").max / range.max;
ok(ratio > 1 && ratio <= 1.3, "speaking only slightly reduces blink frequency (interval stretched by at most 30%)");
ok(base.getIntervalRange("unknown-mood").min === 2000 && base.getBlinkDuration("unknown-mood") === 130,
  "unknown expressions use the neutral timing and duration");
const badCfg = create({ autoStart: false, config: { baseMinIntervalMs: "abc", baseMaxIntervalMs: -5, doubleBlinkChance: 9, sleepyIntervalMultiplier: 0 } });
const cfg = badCfg.getConfig();
ok(cfg.baseMinIntervalMs === 2000 && cfg.baseMaxIntervalMs >= cfg.baseMinIntervalMs && cfg.doubleBlinkChance === 1 && cfg.sleepyIntervalMultiplier >= 0.1,
  "invalid or out-of-range config values are repaired to safe values");

// double-blink probability gate
const noDouble = clock(), nd = [];
const never = create({ autoStart: false, config: { baseMinIntervalMs: 1000, baseMaxIntervalMs: 1000, doubleBlinkChance: 0 },
  setTimeout: noDouble.setTimeout.bind(noDouble), clearTimeout: noDouble.clearTimeout.bind(noDouble), random: () => 0, onBlink: () => nd.push(1) });
never.start(); noDouble.advance(5000);
ok(nd.length === 5 && noDouble.pending() === 1, "with doubleBlinkChance 0 blinks stay single and evenly spaced");
never.stop();
const sd = clock(), sb = [];
const rare = create({ autoStart: false, config: { baseMinIntervalMs: 1000, baseMaxIntervalMs: 1000, doubleBlinkChance: 0.14, doubleBlinkDelayMinMs: 250, doubleBlinkDelayMaxMs: 250 },
  setTimeout: sd.setTimeout.bind(sd), clearTimeout: sd.clearTimeout.bind(sd), random: lcg, onBlink: () => sb.push(sd.now) });
rare.start(); sd.advance(400000); rare.stop();
const pairs = sb.slice(1).filter((x, i) => x - sb[i] === 250).length;
ok(pairs > 0 && pairs < sb.length * 0.4, "double blinks are occasional, not constant, over a long simulated run");

// expression changes: rescale remaining time, never restart the wait
const rc = clock(), rb = [];
const rs = create({ autoStart: false, config: { baseMinIntervalMs: 1000, baseMaxIntervalMs: 1000, doubleBlinkChance: 0, sleepyIntervalMultiplier: 0.5 },
  setTimeout: rc.setTimeout.bind(rc), clearTimeout: rc.clearTimeout.bind(rc), now: () => rc.now, random: () => 0, expression: "neutral", onBlink: () => rb.push(rc.now) });
rs.start(); rc.advance(600);
rs.setExpression("sleepy");
ok(rc.pending() === 1 && rc.nextDelay() === 200, "switching to sleepy rescales the remaining 400 ms to 200 ms");
rc.advance(200); ok(rb.length === 1 && rb[0] === 800, "the rescaled blink fires at the shortened time");
rs.stop();
const st = clock(), stb = [];
const starve = create({ autoStart: false, config: { baseMinIntervalMs: 1000, baseMaxIntervalMs: 1000, doubleBlinkChance: 0 },
  setTimeout: st.setTimeout.bind(st), clearTimeout: st.clearTimeout.bind(st), now: () => st.now, random: () => 0, onBlink: () => stb.push(st.now) });
starve.start();
for (let i = 0; i < 20; i++) { st.advance(100); starve.setExpression(i % 2 ? "speaking" : "happy"); }
ok(stb.length >= 1 && st.pending() === 1, "rapid expression flipping cannot starve blinking or create extra timers");
starve.stop();
const same = clock(), sameS = create({ autoStart: false, setTimeout: same.setTimeout.bind(same), clearTimeout: same.clearTimeout.bind(same), now: () => same.now, random: () => 0.5 });
sameS.start(); const dBefore = same.nextDelay(); sameS.setExpression("angry");
ok(same.pending() === 1 && same.nextDelay() === dBefore, "an expression with the same timing leaves the pending timer untouched");
sameS.stop();
const dbl = clock(), dblb = [];
const keepPair = create({ autoStart: false, config: { baseMinIntervalMs: 500, baseMaxIntervalMs: 500, doubleBlinkChance: 1, doubleBlinkDelayMinMs: 250, doubleBlinkDelayMaxMs: 250 },
  setTimeout: dbl.setTimeout.bind(dbl), clearTimeout: dbl.clearTimeout.bind(dbl), now: () => dbl.now, random: () => 0, onBlink: () => dblb.push(dbl.now) });
keepPair.start(); dbl.advance(500); keepPair.setExpression("sleepy"); dbl.advance(250);
ok(dblb.length === 2 && dblb[1] - dblb[0] === 250, "an expression change mid-double-blink still completes the second blink");
keepPair.stop();

// destroy + timer failure
const dc = clock(), ds = create({ autoStart: false, setTimeout: dc.setTimeout.bind(dc), clearTimeout: dc.clearTimeout.bind(dc), random: () => 0.5, onBlink: () => true });
ds.start(); ds.destroy();
ok(dc.pending() === 0 && ds.getState().destroyed === true && ds.getState().timerPending === false, "destroy clears the pending timer and marks the scheduler destroyed");
ok(ds.start() === false && ds.setIdleState("idle") === "idle" && dc.pending() === 0, "a destroyed scheduler can never be restarted");
ok(ds.destroy() === false, "destroy is idempotent");
const failing = create({ autoStart: false, setTimeout: () => { throw new Error("no timers"); }, clearTimeout: () => {}, random: () => 0.5 });
let failThrew = false; try { failing.start(); } catch (_) { failThrew = true; }
ok(!failThrew && failing.getState().running === false && failing.getState().timerPending === false,
  "a failing timer API is contained and leaves the scheduler cleanly stopped");
let churn = clock(), churnS = create({ autoStart: false, setTimeout: churn.setTimeout.bind(churn), clearTimeout: churn.clearTimeout.bind(churn), now: () => churn.now, random: () => 0.3 });
for (let i = 0; i < 200; i++) { churnS.start(); churnS.setExpression(["sleepy", "thinking", "speaking", "happy"][i % 4]); if (i % 3 === 0) churnS.stop(); }
ok(churn.pending() <= 1, "200 start/stop/expression cycles never leave more than one live timer");
churnS.destroy(); ok(churn.pending() === 0, "no timers remain after the churn test is destroyed");

console.log(`\n${pass} passed, ${fail} failed (deterministic fake-clock tests; actual avatar rendering not tested)`);
process.exit(fail ? 1 : 0);
