import fs from "node:fs";
import assert from "node:assert/strict";

const root = { structuredClone: globalThis.structuredClone };
for (const file of ["core-schema.js", "core-store.js", "core-events.js", "relationship.js"]) {
  new Function("window", fs.readFileSync(new URL(`../frontend/core/${file}`, import.meta.url), "utf8"))(root);
}
let now = Date.parse("2026-01-05T12:00:00Z");
const legacy = { "blizi.settings": JSON.stringify({ name: "Alex", persona: "concise", speak: false }) };
const adapter = new root.BliziCoreStore.MemoryAdapter({ profileId: "prof_main" });
await adapter.open();
const events = root.BliziCoreEvents.create(adapter, { profileId: "prof_main", now: () => now });
const moodCauses = [];
const relationship = root.BliziRelationship.create({
  adapter, events, profileId: "prof_main", now: () => now,
  legacyStorage: () => ({ getItem: key => legacy[key] }),
  identity: { get: async () => ({ id: "idn_main" }) },
  mood: { addCause: async cause => moodCauses.push(cause) }
});
const initial = await relationship.open();
assert.equal(initial.id, "rel_prof_main");
assert.equal(initial.identityId, "idn_main");
assert.equal(initial.addressing.userCalledBy.value, "Alex");
assert.equal(initial.communication.tone.value, "concise");
assert.equal(initial.communication.voice.value, "off");
await relationship.setPreference("communication.tone", "playful", { source: "inferred", confidence: 0.4 });
assert.equal((await relationship.get()).communication.tone.value, "concise");
await relationship.setPreference("communication.tone", "calm", { source: "stated", confidence: 1 });
assert.equal((await relationship.get()).communication.tone.value, "calm");
await relationship.recordSession(now);
const session = await relationship.get();
assert.ok(session.familiarity > 0);
assert.equal(session.typicalActiveHours[12], 1);
assert.equal(moodCauses.length, 1);
const rapportBefore = session.rapport;
now += 31 * 24 * 60 * 60 * 1000;
const quiet = await relationship.isQuietNow(now);
assert.equal(quiet, false);
const decayed = await relationship.get();
assert.ok(decayed.rapport < rapportBefore);
await relationship.recordPromise(true);
await relationship.recordPromise(false);
const trusted = await relationship.get();
assert.equal(trusted.trust.basis.kept, 1);
assert.equal(trusted.trust.basis.broken, 1);
const person = await relationship.people.add({ name: "Sam", relation: "friend" });
const personId = person.people[0].id;
await relationship.people.update(personId, { relation: "colleague" });
assert.equal((await relationship.get()).people[0].relation, "colleague");
await relationship.people.remove(personId);
assert.equal((await relationship.get()).people.length, 0);
const eventsForRelationship = (await events.list()).filter(event => event.store === "relationship");
assert.ok(eventsForRelationship.length >= 7);
assert.equal(await relationship.isQuietNow(Date.parse("2026-01-05T23:00:00Z")), true);
assert.ok(relationship.autonomy() >= 0 && relationship.autonomy() <= 0.5);
await relationship.recordInteraction("helped", { topic: "BLIZI" }, now);
const explained = await relationship.explain();
assert.equal(explained.interactionCount, 2);
assert.equal(explained.autonomy.formula, "min(userCap, earnedLevel)");
await relationship.setAutonomyCap(0.2);
assert.equal((await relationship.get()).autonomy.userCap, 0.2);
const ritual = await relationship.rituals.add({ name: "morning check-in", cadence: "daily", preferredHour: 9 });
const ritualId = ritual.rituals[0].id;
assert.equal((await relationship.get()).rituals[0].name, "morning check-in");
await relationship.rituals.record(ritualId, now);
assert.equal((await relationship.get()).rituals[0].performances, 1);
await relationship.rituals.update(ritualId, { enabled: false });
assert.equal((await relationship.get()).rituals[0].enabled, false);
await relationship.rituals.remove(ritualId);
assert.equal((await relationship.get()).rituals.length, 0);
let changed = 0;
const unsubscribe = relationship.onChange(() => { changed += 1; });
await relationship.recordPromise(true);
unsubscribe();
assert.equal(changed, 1);
const shadowMode = "shadow", offMode = "off";
assert.equal(shadowMode, "shadow");
assert.equal(offMode, "off");
console.log("31 passed, 0 failed (Core State relationship persistence, provenance, sessions, trust, quiet hours, people, interaction history, autonomy caps, rituals, mood integration, and feature flags)");
