import assert from "node:assert/strict";
import { createManusServer } from "../manus-server.mjs";

let assertions = 0;
function check(value, label) {
  assert.ok(value, label);
  assertions += 1;
}
const server = createManusServer({
  publicOrigin: "https://site.test",
  chatService: { handle: async () => ({ status: 200, body: { text: "[happy] test" } }) },
});
await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
const { port } = server.address();
const base = `http://127.0.0.1:${port}`;
try {
  let response = await fetch(`${base}/_app/health`);
  check(response.status === 200 && (await response.json()).status === "ok", "readiness route returns unauthenticated 200");
  response = await fetch(`${base}/`);
  const html = await response.text();
  check(response.status === 200 && response.headers.get("content-type").startsWith("text/html") && html.includes("BLIZI"), "serves the original mobile application shell");
  response = await fetch(`${base}/manifest.webmanifest`);
  const manifest = await response.json();
  check(response.status === 200 && manifest.short_name === "BLIZI", "serves the application-owned PWA manifest");
  response = await fetch(`${base}/sw.js`);
  check(response.status === 200 && (await response.text()).includes("blizi-shell"), "serves the app service worker");
  for (const [route, marker] of [["/avatar/blink-config.js", "BliziBlinkConfig"], ["/avatar/blink-scheduler.js", "BliziBlinkScheduler"]]) {
    response = await fetch(`${base}${route}`);
    const script = await response.text();
    check(response.status === 200 && response.headers.get("content-type").startsWith("text/javascript") && script.includes(marker), `serves ${route} as JavaScript`);
  }
  response = await fetch(`${base}/chat`, { method: "POST", headers: { "Content-Type": "application/json", Origin: "https://site.test" }, body: JSON.stringify({ messages: [{ role: "user", content: "hello" }] }) });
  check(response.status === 200 && (await response.json()).text === "[happy] test", "routes same-origin chat to the backend handler");
  response = await fetch(`${base}/chat`, { method: "GET" });
  check(response.status === 405, "rejects non-POST chat methods");
} finally {
  await new Promise((resolve, reject) => server.close((err) => err ? reject(err) : resolve()));
}
console.log(`${assertions} passed, 0 failed (server tests use a stub chat service; no real AI request)`);
