import fs from "node:fs";

let pass = 0, fail = 0;
const ok = (condition, name) => {
  condition ? pass++ : (fail++, console.log("FAIL:", name));
  if (condition) console.log("ok  :", name);
};

const svgSource = fs.readFileSync(new URL("../frontend/avatar/svg-renderer.js", import.meta.url), "utf8");
const controllerSource = fs.readFileSync(new URL("../frontend/avatar/avatar-controller.js", import.meta.url), "utf8");
const expressionMapSource = fs.readFileSync(new URL("../frontend/avatar/expression-map.js", import.meta.url), "utf8");
const blinkConfigSource = fs.readFileSync(new URL("../frontend/avatar/blink-config.js", import.meta.url), "utf8");
const blinkSchedulerSource = fs.readFileSync(new URL("../frontend/avatar/blink-scheduler.js", import.meta.url), "utf8");
const timers = new Map();
let nextTimer = 0;
const browserWindow = {
  setTimeout(fn, delay) {
    const id = ++nextTimer;
    timers.set(id, { fn, delay });
    return id;
  },
  clearTimeout(id) { timers.delete(id); }
};
new Function("window", expressionMapSource)(browserWindow);
new Function("window", blinkConfigSource)(browserWindow);
new Function("window", blinkSchedulerSource)(browserWindow);
new Function("window", svgSource)(browserWindow);
new Function("window", controllerSource)(browserWindow);

const classes = new Set();
const styles = new Map();
const svg = {
  dataset: { expr: "happy" },
  style: {
    setProperty: (name, value) => styles.set(name, String(value)),
    removeProperty: name => styles.delete(name)
  },
  classList: {
    add: name => classes.add(name),
    remove: name => classes.delete(name),
    toggle: (name, active) => active ? classes.add(name) : classes.delete(name)
  }
};
const bodyCalls = { expressions: [], mouths: [], blinks: [], idle: [] };
let bodyIdle = true;
const body3d = {
  state: name => bodyCalls.expressions.push(name),
  mouth: value => bodyCalls.mouths.push(value),
  info: () => ({ active: false, ready: false }),
  triggerBlink: duration => { bodyCalls.blinks.push(duration); return bodyIdle; },
  setIdleState: state => { bodyIdle = state === true || state === "idle"; bodyCalls.idle.push(state); return bodyIdle ? "idle" : "paused"; }
};
const avatar = new browserWindow.AvatarController({
  svg,
  body3d,
  svgOptions: {
    setTimeout: browserWindow.setTimeout,
    clearTimeout: browserWindow.clearTimeout
  }
});

ok(typeof avatar.setExpression === "function" && typeof avatar.setSpeaking === "function"
  && typeof avatar.setMouthLevel === "function" && typeof avatar.triggerBlink === "function"
  && typeof avatar.setIdleState === "function", "controller exposes all five requested methods");
ok(avatar.setExpression("thinking") === "thinking" && svg.dataset.expr === "thinking"
  && bodyCalls.expressions.at(-1) === "thinking", "expression is rendered in SVG and mirrored to Body3D");
const canonical = ["neutral", "happy", "excited", "embarrassed", "confused", "sad", "angry", "thinking", "sleepy", "speaking"];
ok(canonical.every(name => avatar.setExpression(name) === name && svg.dataset.expr === name), "controller renders each of the ten canonical expressions");
ok(avatar.setExpression("not-a-mood") === "neutral" && svg.dataset.expr === "neutral", "unknown expression names safely resolve to neutral");
avatar.setExpression("happy");
ok(avatar.setSpeaking(true) === "happy" && svg.dataset.expr === "happy"
  && classes.has("speaking") && bodyCalls.expressions.at(-1) === "speaking", "speaking start adds an overlay without changing the base expression");
ok(avatar.setSpeaking(false) === "happy" && svg.dataset.expr === "happy"
  && !classes.has("speaking") && bodyCalls.expressions.at(-1) === "happy", "speaking end removes the overlay and restores the same base expression");
avatar.setExpression("thinking");
avatar.setSpeaking(true);
ok(avatar.setSpeaking(false) === "thinking" && svg.dataset.expr === "thinking" && !classes.has("speaking"),
  "speech start and end preserve an explicit non-happy expression");
ok(avatar.setMouthLevel(0.456) === 0.456 && classes.has("audio")
  && styles.get("--mouth") === "0.46" && bodyCalls.mouths.at(-1) === 0.456,
  "numeric mouth level updates SVG styling and Body3D");
ok(avatar.setMouthLevel(2) === 1 && styles.get("--mouth") === "1.00"
  && bodyCalls.mouths.at(-1) === 1, "mouth level is clamped to the supported 0..1 range");
ok(avatar.setMouthLevel(null) === null && !classes.has("audio")
  && !styles.has("--mouth") && bodyCalls.mouths.at(-1) === null,
  "clearing the mouth level restores the legacy non-audio speaking animation");
ok(avatar.triggerBlink() === true && classes.has("blink"), "triggerBlink starts the existing SVG blink class");
ok(bodyCalls.blinks.at(-1) === undefined, "central blink command is also forwarded to the Body3D adapter");
const blinkTimer = Array.from(timers.entries()).find(([, timer]) => timer.delay === 130);
ok(!!blinkTimer, "SVG blink keeps the existing 130 ms duration");
if (blinkTimer) { timers.delete(blinkTimer[0]); blinkTimer[1].fn(); }
ok(!classes.has("blink"), "SVG blink class clears after its timer");
ok(avatar.triggerBlink(220) === true && Array.from(timers.values()).some(timer => timer.delay === 220),
  "controller forwards the scheduler-selected longer blink duration to the renderer");
ok(bodyCalls.blinks.at(-1) === 220, "controller forwards the same configured duration to the VRM adapter");
const pauseCount = timers.size;
ok(avatar.setIdleState("paused") === "paused" && avatar.triggerBlink() === false && timers.size === pauseCount - 1,
  "pausing idle suppresses new blink requests and clears the recurring scheduler while the active blink finishes");
ok(bodyCalls.idle.at(-1) === "paused", "controller idle pause reaches the Body3D adapter");
const pausedCount = timers.size;
ok(avatar.setIdleState("idle") === "idle" && avatar.triggerBlink() === true && timers.size === pausedCount + 1,
  "resuming idle restarts one scheduler and manual SVG blinking still works");
const resumedCount = timers.size;
avatar.setIdleState("idle");
ok(timers.size === resumedCount, "repeated idle activation does not create a duplicate scheduler timer");

let limitedState = "happy";
const limitedRenderer = {
  supportedExpressions: ["neutral", "happy"],
  supportsExpression: name => name === "neutral" || name === "happy",
  getExpression: () => limitedState,
  setExpression(name) { if (name !== "neutral" && name !== "happy") return false; limitedState = name; return name; },
  setSpeaking() { return limitedState; }
};
const limited = new browserWindow.AvatarController({ svgRenderer: limitedRenderer });
ok(limited.setExpression("confused") === "neutral" && limitedState === "neutral",
  "renderer without a requested expression falls back to its supported neutral state");
ok(limited.setSpeaking(true) === "neutral" && limitedState === "neutral",
  "renderer that cannot display speaking is reset to its supported fallback");
const happyOnlyRenderer = {
  supportedExpressions: ["happy"], fallbackExpression: "happy",
  supportsExpression: name => name === "happy", getExpression: () => "happy",
  setExpression(name) { if (name !== "happy") return false; return "happy"; }
};
const happyOnly = new browserWindow.AvatarController({ svgRenderer: happyOnlyRenderer });
ok(happyOnly.setExpression("sleepy") === "happy", "renderer-specific fallback expression is used when neutral is unsupported");

let hiddenSvgBlinks = 0, vrmBlinkDurations = [], vrmIdle = true;
const readyVrmRenderer = {
  getExpression: () => "happy", setExpression: name => name,
  triggerBlink: () => { hiddenSvgBlinks++; return true; }, setIdleState: () => "idle"
};
const readyVrm = {
  info: () => ({ active: true, ready: true, kind: "vrm" }),
  triggerBlink: duration => { vrmBlinkDurations.push(duration); return vrmIdle; },
  setIdleState: state => { vrmIdle = state === true || state === "idle"; return vrmIdle ? "idle" : "paused"; }
};
const vrmAvatar = new browserWindow.AvatarController({ renderer: readyVrmRenderer, body3d: readyVrm });
ok(vrmAvatar.triggerBlink(176) === true && vrmBlinkDurations.at(-1) === 176 && hiddenSvgBlinks === 0,
  "controller sends scheduled blinks only to the visible ready VRM renderer");
vrmAvatar.setIdleState("paused");
ok(vrmAvatar.triggerBlink(176) === false && hiddenSvgBlinks === 0,
  "VRM idle pause suppresses further controller-driven blinks");
// ---- Phase 3 additions: lifecycle, cleanup and fallback ----
const lc = (() => { let now = 0, id = 0; const m = new Map(); return {
  setTimeout(fn, d) { m.set(++id, { fn, at: now + d }); return id; }, clearTimeout(i) { m.delete(i); }, pending: () => m.size,
  advance(ms) { const end = now + ms; for (;;) { const n = [...m.entries()].sort((a, b) => a[1].at - b[1].at)[0]; if (!n || n[1].at > end) break; now = n[1].at; m.delete(n[0]); n[1].fn(); } now = end; }, now: () => now }; })();
const lcCalls = [];
const lcRenderer = { getExpression: () => "happy", setExpression: n => n, triggerBlink: d => { lcCalls.push(d); return true; }, setIdleState: () => "idle", destroyed: 0, destroy() { this.destroyed++; } };
const lcAvatar = new browserWindow.AvatarController({ renderer: lcRenderer, blinkSetTimeout: lc.setTimeout, blinkClearTimeout: lc.clearTimeout, blinkNow: lc.now, blinkRandom: () => 0,
  blinkConfig: { baseMinIntervalMs: 1000, baseMaxIntervalMs: 1000, doubleBlinkChance: 0, baseDurationMs: 130, thinkingDurationMultiplier: 2 } });
ok(lc.pending() === 1, "constructing a controller creates exactly one blink scheduler timer");
lc.advance(1000);
ok(lcCalls.length === 1 && lcCalls[0] === 130, "controller drives the renderer from its own scheduler with the configured duration");
lcAvatar.setExpression("thinking"); lc.advance(1100);
ok(lcCalls.at(-1) === 260, "thinking expression produces the longer configured blink through the controller");
lcAvatar.setSpeaking(true);
ok(lc.pending() === 1, "starting speech does not add a second scheduler timer");
lcAvatar.setIdleState("paused"); ok(lc.pending() === 0, "pausing idle cancels the scheduler timer");
lcAvatar.setIdleState("idle"); lcAvatar.setIdleState("idle"); ok(lc.pending() === 1, "resuming idle twice still leaves exactly one timer");
ok(lcAvatar.destroy() === true && lc.pending() === 0 && lcRenderer.destroyed === 1, "destroy stops the scheduler and releases the renderer");
const callsAtDestroy = lcCalls.length;
lc.advance(10000); lcAvatar.setIdleState("idle");
ok(lcCalls.length === callsAtDestroy && lc.pending() === 0, "no blinks or timers appear after destroy, even if idle is re-enabled");
ok(lcAvatar.destroy() === false && lcAvatar.setExpression("sad") === "sad", "destroy is idempotent and the public API stays safe to call afterwards");

// SVG renderer cleanup: glance loop and blink timer are cancelled
const svgTimers = new Map(); let svgId = 0;
const svgLoop = { dataset: { expr: "happy" }, style: { setProperty() {}, removeProperty() {} }, classList: { add() {}, remove() {} } };
const svgRend = browserWindow.BliziSvgRenderer.create(svgLoop, { setTimeout: (fn, d) => { svgTimers.set(++svgId, fn); return svgId; }, clearTimeout: i => svgTimers.delete(i) });
svgRend.triggerBlink(); ok(svgTimers.size === 2, "SVG renderer has one glance timer and one blink timer before cleanup");
svgRend.destroy(); ok(svgTimers.size === 0 && svgRend.triggerBlink() === false, "SVG renderer destroy cancels all timers and ignores later blinks");

// fallback: missing / broken / absent collaborators
const savedScheduler = browserWindow.BliziBlinkScheduler;
browserWindow.BliziBlinkScheduler = undefined;
let noSched = null, noSchedThrew = false;
try { noSched = new browserWindow.AvatarController({ renderer: { getExpression: () => "happy", setExpression: n => n } }); } catch (_) { noSchedThrew = true; }
ok(!noSchedThrew && noSched.triggerBlink() === false && noSched.setIdleState("idle") === "idle" && noSched.destroy() === true,
  "controller works without the blink scheduler script and renderers without triggerBlink");
browserWindow.BliziBlinkScheduler = { create() { throw new Error("broken scheduler"); } };
let brokenThrew = false, broken = null;
try { broken = new browserWindow.AvatarController({ renderer: { getExpression: () => "happy", setExpression: n => n } }); } catch (_) { brokenThrew = true; }
ok(!brokenThrew && broken.setExpression("happy") === "happy", "a scheduler that throws on creation does not break the avatar");
browserWindow.BliziBlinkScheduler = savedScheduler;
const throwBlink = new browserWindow.AvatarController({ renderer: { getExpression: () => "happy", setExpression: n => n, triggerBlink() { throw new Error("boom"); } }, blinkSetTimeout: lc.setTimeout, blinkClearTimeout: lc.clearTimeout, blinkRandom: () => 0, blinkConfig: { baseMinIntervalMs: 100, baseMaxIntervalMs: 100 } });
let blinkThrew = false; try { lc.advance(1000); } catch (_) { blinkThrew = true; }
ok(!blinkThrew && throwBlink.triggerBlink() === false && lc.pending() === 1, "a renderer that throws on blink is contained and the scheduler keeps a single timer");
throwBlink.destroy(); ok(lc.pending() === 0, "cleanup leaves no timers behind");

// ---- 3D body: talking is a flag, the emotion state is NOT replaced by "speaking"
{
  const calls = []; const talkBody = { state: n => calls.push(["state", n]), talk: a => calls.push(["talk", a]), mouth() {}, info: () => ({ active: false, ready: false }), triggerBlink: () => false, setIdleState: () => "idle" };
  const sv = { dataset: { expr: "happy" }, style: { setProperty() {}, removeProperty() {} }, classList: { add() {}, remove() {}, toggle() {} } };
  const a3 = new browserWindow.AvatarController({ svg: sv, body3d: talkBody, svgOptions: { setTimeout: browserWindow.setTimeout, clearTimeout: browserWindow.clearTimeout } });
  a3.setExpression("serious"); calls.length = 0;
  a3.setSpeaking(true);
  ok(calls.some(c => c[0] === "talk" && c[1] === true) && !calls.some(c => c[0] === "state" && c[1] === "speaking") && calls.some(c => c[0] === "state" && c[1] === "serious"), "a 3D body with talk support keeps the emotion while she speaks");
  a3.setSpeaking(false);
  ok(calls.some(c => c[0] === "talk" && c[1] === false) && a3.getExpression() === "serious", "talk(false) on speech end, emotion unchanged");
  const thrower = { state() {}, talk() { throw new Error("boom"); }, mouth() {}, info: () => ({}), triggerBlink: () => false, setIdleState: () => "idle" };
  const a4 = new browserWindow.AvatarController({ svg: sv, body3d: thrower, svgOptions: { setTimeout: browserWindow.setTimeout, clearTimeout: browserWindow.clearTimeout } });
  let threw = false; try { a4.setSpeaking(true); a4.setSpeaking(false); } catch (_) { threw = true; }
  ok(!threw, "a 3D body that throws in talk() is contained");
  a3.destroy(); a4.destroy();
}
// ---- CSS contract: the speaking overlay class is actually styled, and the audio mouth rule still wins
{
  const html = fs.readFileSync(new URL("../frontend/index.html", import.meta.url), "utf8");
  const overlay = html.indexOf("#blizi.speaking .m-o"), audio = html.indexOf("#blizi.audio .m-o");
  ok(overlay > 0 && audio > overlay && /#blizi\.speaking \.m\{display:none\}/.test(html), "the speaking overlay class hides the emotion mouth and shows the moving one; the audio-driven rule comes later so it wins");
}

console.log(`\n${pass} passed, ${fail} failed (controller and SVG renderer run with fake DOM/timers; real browser rendering not tested)`);
process.exit(fail ? 1 : 0);
