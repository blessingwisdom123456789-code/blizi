// Tests the REAL Body3D block from frontend/index.html with FAKE three.js / three-vrm objects.
// This proves lifecycle, fallback, pause and mapping logic only. It does NOT prove real WebGL rendering or real VRM compatibility.
import fs from "node:fs";
let pass = 0, fail = 0;
const ok = (c, n) => { c ? pass++ : (fail++, console.log("FAIL:", n)); if (c) console.log("ok  :", n); };
const html = fs.readFileSync(new URL("../frontend/index.html", import.meta.url), "utf8");
const expressionMapSource = fs.readFileSync(new URL("../frontend/avatar/expression-map.js", import.meta.url), "utf8");
const block = html.slice(html.indexOf("/* body3d */"), html.indexOf("/* /body3d */"));
const Body3D = new Function(block + ";return Body3D")();
const sleep = ms => new Promise(r => setTimeout(r, ms));

function env({ gl = true, urls = {}, parseFail = false, vrmBuilds = {} } = {}) {
  const log = { scripts: [], set: [], renders: 0, cancelled: 0, updates: 0, rendererOpts: null, pixelRatio: null, status: [] };
  let cb = null, id = 0, renderThrows = false, glHandlers = {}, ioCb = null, docHandlers = {};
  const bones = {}; const bone = n => bones[n] || (bones[n] = { rotation: { x: 0, y: 0, z: 0 } });
  const vrm = { scene: { rotation: { y: 0 }, position: { y: 0 } }, humanoid: { getBoneNode: bone }, blendShapeProxy: { setValue: (n, w) => log.set.push([n, w]) }, update: () => log.updates++ };
  const TH = {
    WebGLRenderer: function (o) { log.rendererOpts = o; return { setPixelRatio: r => log.pixelRatio = r, setSize() {}, render: () => { if (renderThrows) throw new Error("boom"); log.renders++; }, dispose() {} }; },
    Scene: function () { return { add() {}, remove() {} }; }, PerspectiveCamera: function () { return { position: { set() {} }, lookAt() {}, updateProjectionMatrix() {} }; },
    AmbientLight: function () {}, DirectionalLight: function () { return { position: { set() {} } }; },
    Box3: function () { return { setFromObject() { return this; }, getSize: () => ({ y: 1.6, z: .3 }), getCenter: () => ({ y: .8 }) }; }, Vector3: function () {}
  };
  const win = { devicePixelRatio: 3, requestAnimationFrame: f => { cb = f; return ++id; }, cancelAnimationFrame: () => log.cancelled++, addEventListener() {}, IntersectionObserver: function (f) { ioCb = f; this.observe = () => {}; } };
  new Function("window", expressionMapSource)(win);
  const doc = { visibilityState: "visible", addEventListener: (t, f) => docHandlers[t] = f,
    head: { appendChild(el) { log.scripts.push(el.src); setTimeout(() => {
      const how = urls[el.src] || "ok";
      if (how === "fail") return el.onerror();
      if (el.src.includes("three.min")) win.THREE = TH;
      if (el.src.includes("GLTFLoader")) win.THREE.GLTFLoader = function () { this.parse = (b, p, res, rej) => parseFail ? rej(new Error("bad gltf")) : res({ scene: {} }); };
      if (el.src.includes("three-vrm")) { if (vrmBuilds[el.src] !== "incompatible") win.THREE.VRM = { from: async () => vrm }; }
      el.onload(); }, 0); } },
    createElement: t => t === "script" ? { src: "" } : { getContext: () => gl ? {} : null } };
  const hnd = {}; const cv = { hidden: true, clientWidth: 300, clientHeight: 340, addEventListener: (t, f) => hnd[t] = f };
  const svg = { style: { display: "" } };
  let taps = 0, flags = { flip: false, turn: false };
  const b = Body3D({ win, doc, canvas: cv, svg, status: m => log.status.push(m), flags: () => flags, onTap: () => taps++ });
  // Structurally valid minimal GLB (glTF 2.0 header + JSON chunk) carrying the VRM 0.x extension; inspection of the header is real code, three.js stays FAKE.
  const buf = () => { const j = new TextEncoder().encode(JSON.stringify({ asset: { version: "2.0" }, extensions: { VRM: {} }, meshes: [{ primitives: [{ attributes: { POSITION: 0 } }] }], accessors: [{ count: 3 }] }) + "   ").slice(); const pad = j.length % 4 ? 4 - j.length % 4 : 0; const jl = j.length + pad; const out = new Uint8Array(20 + jl); const dv = new DataView(out.buffer); dv.setUint32(0, 0x46546C67, true); dv.setUint32(4, 2, true); dv.setUint32(8, out.length, true); dv.setUint32(12, jl, true); dv.setUint32(16, 0x4E4F534A, true); out.set(j, 20); out.fill(32, 20 + j.length); return out.buffer; };
  let now = 1000; const tick = (ms = 33) => { now += ms; cb && cb(now); };
  return { b, log, vrm, bones, win, doc, cv, svg, hnd, buf, tick, setFlags: f => flags = f, taps: () => taps, throwOnRender: () => renderThrows = true, ioFire: v => ioCb([{ isIntersecting: v }]), docFire: () => docHandlers.visibilitychange(), glLost: () => hnd["webglcontextlost"] ? null : null, status: () => log.status[log.status.length - 1] };
}
const V = ["https://cdn.jsdelivr.net/npm/@pixiv/three-vrm@0.6.7/lib/three-vrm.js","https://unpkg.com/@pixiv/three-vrm@0.6.7/lib/three-vrm.js","https://cdn.jsdelivr.net/npm/@pixiv/three-vrm@0.3.4/lib/three-vrm.js","https://unpkg.com/@pixiv/three-vrm@0.3.4/lib/three-vrm.js"];

// 1. no WebGL
let e = env({ gl: false }); e.b.enable(true);
ok(/WebGL isn’t available/.test(e.status()) && e.log.scripts.length === 0, "no WebGL -> message, nothing downloaded");
// 2. validation happens before any download
e = env(); ok((await e.b.loadModel(e.buf())) === false && /Turn on 3D/.test(e.status()), "loading a model while 3D is off is refused");
e.b.enable(true);
ok((await e.b.loadModel(new ArrayBuffer(5))) === false && /empty/.test(e.status()), "empty file rejected");
ok((await e.b.loadModel(new ArrayBuffer(26 * 1024 * 1024))) === false && /25 MB/.test(e.status()), "over-25MB file rejected");
ok((await e.b.loadModel(new Uint8Array(50).buffer)) === false && /isn’t a VRM/.test(e.status()), "non-glTF file rejected");
ok(e.log.scripts.length === 0 && e.svg.style.display === "", "rejections never download libraries and keep 2D visible");
// 3. library fallback order + incompatible build + success
e = env({ urls: { [V[0]]: "fail" }, vrmBuilds: { [V[1]]: "incompatible" } }); e.b.enable(true);
ok((await e.b.loadModel(e.buf())) === true, "model loads once a compatible three-vrm build is found");
ok(JSON.stringify(e.log.scripts.slice(2)) === JSON.stringify(V.slice(0, 3)) && e.log.scripts[0].includes("three.min") && e.log.scripts[1].includes("GLTFLoader"), "libraries load sequentially; failing/incompatible vrm builds are skipped in order");
ok(e.svg.style.display === "none" && e.cv.hidden === false, "2D hidden and canvas shown only after the model is ready");
ok(e.log.rendererOpts.alpha === true && e.log.rendererOpts.antialias === false && e.log.rendererOpts.powerPreference === "low-power" && e.log.pixelRatio === 1.5, "phone-friendly renderer: no antialias, low-power, pixel ratio capped at 1.5");
// 4. all vrm builds fail -> 2D fallback, retry possible
e = env({ urls: Object.fromEntries(V.map(u => [u, "fail"])) }); e.b.enable(true);
ok((await e.b.loadModel(e.buf())) === false && /No compatible three-vrm/.test(e.status()) && e.svg.style.display === "" && e.cv.hidden === true, "no usable library -> clear reason, 2D stays");
const n1 = e.log.scripts.length; await e.b.loadModel(e.buf()); ok(e.log.scripts.length > n1, "a failed library load can be retried");
// 5. model parse failure
e = env({ parseFail: true }); e.b.enable(true);
ok((await e.b.loadModel(e.buf())) === false && /Couldn’t load the model/.test(e.status()) && e.svg.style.display === "", "corrupt model -> readable error, 2D stays");
// 6. animation, expressions, pose, fps cap
e = env(); e.b.enable(true); await e.b.loadModel(e.buf());
e.b.state("surprised"); for (let i = 0; i < 30; i++) e.tick();
const last = n => e.log.set.filter(x => x[0] === n).pop();
ok(last("a")[1] > .4 && last("joy")[1] < .05, "surprised state -> mouth-open approximation, joy off");
e.b.state("happy"); for (let i = 0; i < 40; i++) e.tick(); ok(last("joy")[1] > .6 && last("a")[1] < .05, "happy state -> joy expression");
e.b.state("sad"); for (let i = 0; i < 40; i++) e.tick(); ok(last("sorrow")[1] > .6, "sad state uses the shared VRM sorrow preset");
e.b.state("sleepy"); e.tick(); ok(last("blink")[1] >= .58, "sleepy state uses the shared half-lidded VRM blink mapping");
e.b.state("excited"); for (let i = 0; i < 40; i++) e.tick(); ok(last("joy")[1] > .9 && last("fun")[1] > .3, "excited state blends the shared joy and fun presets");
e.b.state("speaking"); e.log.set.length = 0; for (let i = 0; i < 60; i++) e.tick();
const mouth = e.log.set.filter(x => x[0] === "a").map(x => x[1]); ok(Math.max(...mouth) - Math.min(...mouth) > .15 && Math.max(...mouth) > .3, "speaking state animates the mouth (approximate, not audio-synced)");
e.b.state("happy"); e.log.set.length = 0; for (let i = 0; i < 300; i++) e.tick(); const bl = e.log.set.filter(x => x[0] === "blink").map(x => x[1]);
ok(Math.max(...bl) === 0, "VRM does not start a second private random blink scheduler");
e.log.set.length = 0; ok(e.b.triggerBlink(320) === true, "ready VRM accepts a controller-selected blink duration");
for (let i = 0; i < 20; i++) e.tick(33); const drivenBlink = e.log.set.filter(x => x[0] === "blink").map(x => x[1]);
ok(Math.max(...drivenBlink) > .5 && drivenBlink[drivenBlink.length - 1] === 0, "controller-driven VRM blink animates and returns open at its requested duration");
ok(e.b.setIdleState("paused") === "paused" && e.b.triggerBlink(150) === false, "VRM idle pause suppresses new controller-driven blinks");
ok(e.b.setIdleState("idle") === "idle" && e.b.triggerBlink(150) === true, "resuming idle re-enables VRM blinking");
ok(e.vrm.scene.rotation.y > 3 && e.bones.leftUpperArm.rotation.z > 1 && e.bones.rightUpperArm.rotation.z < -1, "default pose: faces camera, arms lowered");
e.setFlags({ flip: true, turn: true }); e.tick(); ok(e.bones.leftUpperArm.rotation.z < -1 && Math.abs(e.vrm.scene.rotation.y) < .1, "Flip arms / Turn around settings change the pose");
ok(e.log.updates > 0 && Math.abs(e.bones.chest.rotation.x) < .02, "vrm.update runs; breathing motion is subtle");
e.b.state("nonsense"); e.tick(); ok(true, "unknown state does not crash");
e = env(); e.b.enable(true); await e.b.loadModel(e.buf()); const r0 = e.log.renders; for (let i = 0; i < 100; i++) e.tick(10);
ok(e.log.renders - r0 > 25 && e.log.renders - r0 < 40, `frame cap: 100 frames at 10ms -> ${e.log.renders - r0} renders (~30fps)`);
// 7. pause when not visible
e = env(); e.b.enable(true); await e.b.loadModel(e.buf()); ok(e.b.info().running, "renders while visible");
e.b.view(false); ok(!e.b.info().running && e.log.cancelled > 0, "stops rendering when Home isn’t the visible view");
e.b.view(true); ok(e.b.info().running, "resumes when Home returns");
e.doc.visibilityState = "hidden"; e.docFire(); ok(!e.b.info().running, "stops when the tab is hidden"); e.doc.visibilityState = "visible"; e.docFire(); ok(e.b.info().running, "resumes when the tab is visible");
e.ioFire(false); ok(!e.b.info().running, "stops when scrolled out of view"); e.ioFire(true); ok(e.b.info().running, "resumes when back in view");
// 8. failure paths fall back to 2D
e = env(); e.b.enable(true); await e.b.loadModel(e.buf()); e.hnd.webglcontextlost({ preventDefault() {} });
ok(e.svg.style.display === "" && e.cv.hidden === true && !e.b.info().running && /Using 2D/.test(e.status()), "WebGL context loss -> 2D fallback");
e = env(); e.b.enable(true); await e.b.loadModel(e.buf()); e.throwOnRender(); e.tick(); e.tick();
ok(e.svg.style.display === "" && !e.b.info().running, "render exception -> 2D fallback");
e = env(); e.b.enable(true); await e.b.loadModel(e.buf()); e.b.enable(false); ok(e.svg.style.display === "" && !e.b.info().running, "switching 3D off restores 2D and stops rendering");
// 9. touch
e = env(); e.b.enable(true); await e.b.loadModel(e.buf());
e.hnd.pointerdown({ clientX: 100 }); e.hnd.pointerup(); ok(e.taps() === 1, "tap triggers a reaction");
e.hnd.pointerdown({ clientX: 100 }); e.hnd.pointermove({ clientX: 400 }); e.hnd.pointerup(); ok(e.taps() === 1, "a drag is not treated as a tap");
e.tick(); e.tick(); ok(Math.abs(e.vrm.scene.rotation.y - Math.PI) <= .9 + 1e-6 && e.vrm.scene.rotation.y !== Math.PI, "drag turns her, clamped");
// 10. audio-driven mouth + procedural gestures
e = env(); e.b.enable(true); await e.b.loadModel(e.buf()); e.b.state("speaking");
e.tick(); e.b.mouth(0.8); e.tick(); ok(Math.abs(e.log.set.filter(x => x[0] === "a").pop()[1] - 0.72) < 1e-6, "audio level drives the mouth directly (no smoothing lag)");
e.b.mouth(0); e.tick(); ok(e.log.set.filter(x => x[0] === "a").pop()[1] === 0, "silence closes the mouth immediately");
e.b.mouth(null); for (let i = 0; i < 30; i++) e.tick(); ok(e.log.set.filter(x => x[0] === "a").slice(-30).some(x => x[1] > .2), "without audio the approximate talking motion is used");
e.b.mouth(5); e.tick(); ok(e.log.set.filter(x => x[0] === "a").pop()[1] <= .9 + 1e-9, "mouth level is clamped");
e.b.state("happy"); e.b.mouth(0.9); for (let i = 0; i < 40; i++) e.tick(); ok(e.log.set.filter(x => x[0] === "a").pop()[1] < .05, "mouth override only applies while speaking");
// talking overlay: the mouth moves under ANY emotion, and the emotion itself is not replaced
e = env(); e.b.enable(true); await e.b.loadModel(e.buf()); e.b.state("sad"); e.b.talk(true);
e.tick(); e.b.mouth(0.8); for (let i = 0; i < 40; i++) e.tick();
const aTalk = e.log.set.filter(x => x[0] === "a").pop()[1], sorrowTalk = e.log.set.filter(x => x[0] === "sorrow").pop()[1];
ok(Math.abs(aTalk - 0.72) < 1e-6, "talking overlay: audio level drives the mouth while the state is an emotion, not 'speaking'");
ok(sorrowTalk > .5, "talking overlay: the sad expression weights are kept while she talks");
e.b.mouth(null); for (let i = 0; i < 30; i++) e.tick(); ok(e.log.set.filter(x => x[0] === "a").slice(-30).some(x => x[1] > .2), "talking overlay without audio: approximate talking motion under the emotion");
e.b.talk(false); e.b.mouth(0.9); for (let i = 0; i < 40; i++) e.tick(); ok(e.log.set.filter(x => x[0] === "a").pop()[1] < .05, "talk(false) closes the mouth again");
e = env(); ok(e.b.gesture("wave") === false, "gestures refused when no model is loaded");
e.b.enable(true); await e.b.loadModel(e.buf()); ok(e.b.gesture("bogus") === false && e.b.gesture("wave") === true, "unknown gesture refused; wave accepted");
e.tick(); let maxZ = -9; for (let i = 0; i < 40; i++) { e.tick(); maxZ = Math.max(maxZ, e.bones.rightUpperArm.rotation.z); } ok(maxZ > .3 && e.bones.rightLowerArm.rotation.z !== 0, "wave raises the right arm and moves the forearm");
for (let i = 0; i < 80; i++) e.tick(); e.tick(); ok(e.bones.rightUpperArm.rotation.z < -1, "arm returns to the lowered pose after the wave");
e.b.gesture("jump"); let maxY = 0; for (let i = 0; i < 20; i++) { e.tick(); maxY = Math.max(maxY, e.vrm.scene.position.y || 0); } ok(maxY > .1, "jump lifts the model");
for (let i = 0; i < 40; i++) e.tick(); ok((e.vrm.scene.position.y || 0) === 0, "model lands back at 0 after the jump");
e.b.gesture("dance"); for (let i = 0; i < 60; i++) e.tick(); ok(Math.abs(e.bones.hips.rotation.z) > 0 || Math.abs(e.bones.hips.rotation.y) > 0, "dance moves the hips");
for (let i = 0; i < 150; i++) e.tick(); ok(e.bones.hips.rotation.z === 0 && e.bones.hips.rotation.y === 0, "hips reset when the dance ends");
console.log(`\n${pass} passed, ${fail} failed (FAKE three.js/three-vrm: logic only; real WebGL and real VRM files are NOT tested)`);
process.exit(fail ? 1 : 0);
