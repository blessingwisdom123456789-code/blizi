import fs from "node:fs";
import assert from "node:assert/strict";

const root = {};
new Function("window", fs.readFileSync(new URL("../frontend/core/body-intent.js", import.meta.url), "utf8"))(root);
const detect = root.BliziBodyIntent.detect;

assert.deepEqual(detect("make a serious face"), { kind: "expression", expression: "serious", requested: "serious", phrase: "make a serious face" });
assert.equal(detect("now smile").expression, "happy");
assert.equal(detect("look sad").expression, "sad");
assert.equal(detect("I made a serious mistake today"), null, "serious in an ordinary statement is not a body request");
assert.equal(detect("Why is your face serious?"), null, "questions about the current face do not change it");
assert.equal(detect("make a purple face").kind, "expression");
assert.equal(detect("make a purple face").expression, null, "unknown face names remain explicit for safe handling");
assert.equal(detect("stop talking").action, "stop-speaking");
assert.equal(detect("mute yourself").action, "mute");
assert.equal(detect("speak again").action, "speak");
assert.equal(detect("the serious problem is urgent"), null, "ordinary serious-problem language does not trigger a face change");

console.log("11 passed, 0 failed (rule-based body intent: expressions, exclusions, questions, unknowns, and voice actions)");
