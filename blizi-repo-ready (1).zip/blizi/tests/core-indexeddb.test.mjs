import fs from "node:fs";
import assert from "node:assert/strict";
import { webcrypto } from "node:crypto";

/*
 * Regression: IndexedDbAdapter.transaction() used `self.profileId` without defining `self`.
 * In a browser a bare `self` is `window`, so every profile-scoped read filtered to nothing and
 * Core memory (facts, episodes, projects, mood, relationship) never persisted or came back.
 * Node has no global `self`, and the other suites use in-memory adapters, so nothing caught it.
 * This suite drives the REAL IndexedDbAdapter against a small fake IndexedDB, with a browser-like
 * global `self` that has no profileId.
 */
const root = { structuredClone: globalThis.structuredClone, crypto: webcrypto };
for (const file of ["core-schema.js", "core-store.js", "core-events.js", "facts.js"]) {
  new Function("window", fs.readFileSync(new URL(`../frontend/core/${file}`, import.meta.url), "utf8"))(root);
}
globalThis.self = { navigator: {}, note: "browser-like global: no profileId here" };   // what a browser gives a bare `self`

function fakeIndexedDB() {
  const databases = new Map();
  return {
    open(name) {
      const req = {};
      queueMicrotask(() => {
        let rec = databases.get(name), fresh = !rec;
        if (!rec) { rec = { stores: new Map() }; databases.set(name, rec); }
        const db = {
          objectStoreNames: { contains: n => rec.stores.has(n) },
          createObjectStore(n, opts) { rec.stores.set(n, { keyPath: opts.keyPath, auto: !!opts.autoIncrement, rows: new Map(), seq: 0 }); return {}; },
          close() {},
          transaction(names, mode) {
            const tx = { error: null }; let pending = 0, scheduled = false;
            const settle = () => { if (scheduled) return; scheduled = true; setTimeout(() => { scheduled = false; if (pending === 0) tx.oncomplete && tx.oncomplete(); else settle(); }, 0); };
            const request = work => { const r = {}; pending++; queueMicrotask(() => { try { r.result = work(); r.onsuccess && r.onsuccess(); } catch (e) { r.error = e; r.onerror && r.onerror(); } pending--; settle(); }); return r; };
            tx.objectStore = n => {
              const st = rec.stores.get(n); if (!st) throw new Error("NotFoundError");
              const keyOf = row => row[st.keyPath];
              return {
                put: row => request(() => { st.rows.set(keyOf(row), JSON.parse(JSON.stringify(row))); return keyOf(row); }),
                add: row => request(() => { const copy = JSON.parse(JSON.stringify(row)); if (st.auto && copy[st.keyPath] === undefined) copy[st.keyPath] = ++st.seq; st.rows.set(copy[st.keyPath], copy); return copy[st.keyPath]; }),
                get: key => request(() => st.rows.has(key) ? JSON.parse(JSON.stringify(st.rows.get(key))) : undefined),
                getAll: () => request(() => [...st.rows.values()].map(r => JSON.parse(JSON.stringify(r)))),
                delete: key => request(() => { st.rows.delete(key); }),
                clear: () => request(() => { st.rows.clear(); })
              };
            };
            tx.abort = () => {}; settle(); return tx;
          }
        };
        req.result = db;
        if (fresh) req.onupgradeneeded && req.onupgradeneeded();
        req.onsuccess && req.onsuccess();
      });
      return req;
    }
  };
}

let passed = 0;
const ok = (name, fn) => Promise.resolve().then(fn).then(() => { passed++; console.log("ok  : " + name); });

const idb = fakeIndexedDB();
const adapter = new root.BliziCoreStore.IndexedDbAdapter(idb, { profileId: "prof_main" });
await adapter.open();
const events = root.BliziCoreEvents.create(adapter, { profileId: "prof_main" });
const facts = root.BliziFacts.create({ adapter, events, profileId: "prof_main" });

await ok("a fact written through the IndexedDB adapter can be read back (browser-like global self)", async () => {
  const rec = await facts.add({ subject: "user", category: "general", key: "remembered.1", value: "I prefer short replies", source: "stated" });
  assert.ok(await facts.get(rec.id), "get by id must find the fact");
  const all = await facts.query({});
  assert.equal(all.length, 1);
  assert.equal(all[0].value, "I prefer short replies");
  assert.equal((await facts.query({ status: "active" })).length, 1);
});

await ok("the event log entry is also written and readable", async () => {
  const rows = await adapter.getAll("eventlog");
  assert.ok(rows.length >= 1 && rows.every(r => r.profileId === "prof_main"));
});

await ok("data survives closing and reopening the database", async () => {
  adapter.close();
  const again = new root.BliziCoreStore.IndexedDbAdapter(idb, { profileId: "prof_main" });
  await again.open();
  const f2 = root.BliziFacts.create({ adapter: again, events: root.BliziCoreEvents.create(again, { profileId: "prof_main" }), profileId: "prof_main" });
  assert.equal((await f2.query({})).length, 1);
});

await ok("another profile cannot see this profile's facts (scoping still enforced)", async () => {
  const other = new root.BliziCoreStore.IndexedDbAdapter(idb, { profileId: "prof_other" });
  await other.open();
  const f3 = root.BliziFacts.create({ adapter: other, events: root.BliziCoreEvents.create(other, { profileId: "prof_other" }), profileId: "prof_other" });
  assert.equal((await f3.query({})).length, 0);
});

console.log(`${passed} passed, 0 failed (REAL IndexedDbAdapter against a small fake IndexedDB; real browser IndexedDB verified separately in Chromium)`);
