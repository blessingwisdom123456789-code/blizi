import fs from "node:fs";
import assert from "node:assert/strict";

const root = { structuredClone: globalThis.structuredClone };
for (const file of ["core-schema.js", "core-store.js", "core-events.js", "episodes.js", "facts.js"]) {
  new Function("window", fs.readFileSync(new URL(`../frontend/core/${file}`, import.meta.url), "utf8"))(root);
}
let now = Date.parse("2026-02-01T10:00:00Z");
const adapter = new root.BliziCoreStore.MemoryAdapter({ profileId: "prof_main" });
await adapter.open();
const events = root.BliziCoreEvents.create(adapter, { profileId: "prof_main", now: () => now });
const episodes = root.BliziEpisodes.create({ adapter, events, profileId: "prof_main", now: () => now });
const facts = root.BliziFacts.create({ adapter, events, profileId: "prof_main", now: () => now });
const captured = await episodes.captureConversation([
  { who: "user", text: "I am planning a quiet weekend project with Sam." },
  { who: "bot", text: "That sounds thoughtful." }
], { importance: 0.7 });
assert.equal(captured.provenance.source, "rule_summarizer");
assert.equal(captured.sensitivity, "normal");
assert.ok(captured.topics.includes("planning"));
assert.equal((await episodes.query({ text: "weekend" })).length, 1);
await episodes.touch(captured.id);
assert.equal((await episodes.get(captured.id)).lastRecalledAt, new Date(now).toISOString());
await episodes.update(captured.id, { people: ["person_sam"], projects: ["proj_blizi"] });
assert.equal((await episodes.query({ people: ["person_sam"], projects: ["proj_blizi"] })).length, 1);
const maintained = await episodes.maintain(now + 31 * 24 * 60 * 60 * 1000);
assert.ok(maintained.changed >= 1);
await assert.rejects(() => episodes.add({ summary: "private", sensitive: true }), error => error.code === "sensitive_disabled");
const nameFact = await facts.add({ subject: "user", category: "identity", key: "user.name", value: "Alex", source: "stated", ref: "explicit_pattern" });
assert.equal(nameFact.confidence, 0.9);
const inferred = await facts.add({ subject: "user", category: "preference", key: "user.color", value: "blue", source: "inferred", confidence: 0.9 });
assert.equal(inferred.confidence, 0.5);
await facts.confirm(inferred.id);
assert.equal((await facts.get(inferred.id)).status, "confirmed");
const contradiction = await facts.add({ subject: "user", category: "identity", key: "user.name", value: "Sam", source: "stated" });
await facts.dispute(nameFact.id, contradiction.id);
assert.equal((await facts.get(nameFact.id)).status, "disputed");
assert.equal((await facts.get(contradiction.id)).status, "disputed");
const correction = await facts.correct(contradiction.id, "Jamie", { reason: "user correction", purgeBefore: true });
assert.equal((await facts.get(contradiction.id)), null);
assert.equal((await facts.get(correction.fact.id)).locked, true);
assert.equal((await facts.corrections()).length, 1);
const changing = await facts.add({ subject: "user", category: "preference", key: "user.food", value: "tea", source: "observed", changing: true, reconfirmAfterDays: 1 });
now += 3 * 24 * 60 * 60 * 1000;
assert.equal((await facts.decay(now)).changed, 1);
assert.ok((await facts.get(changing.id)).confidence < 0.6);
assert.ok((await events.list()).filter(event => event.store === "episodes").length >= 3);
assert.ok((await events.list()).filter(event => event.store === "facts").length >= 6);
assert.ok((await events.list()).filter(event => event.store === "corrections").length === 1);
assert.equal((await facts.query({ status: "retracted" })).length, 0);
console.log("22 passed, 0 failed (Core State episodic memory, semantic facts, corrections, provenance, confidence, decay, event log, and sensitive-memory guard)");
