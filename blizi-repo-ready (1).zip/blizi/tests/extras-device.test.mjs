import fs from "node:fs";
import assert from "node:assert/strict";

const load = (f) => { const root = {}; new Function("window", fs.readFileSync(new URL("../frontend/tools/" + f, import.meta.url), "utf8"))(root); return root; };
const R = load("reminders.js").BliziReminders, D = load("todos.js").BliziTodos, A = load("page-actions.js").BliziActions;
const X = load("extras.js").BliziExtras, V = load("device.js").BliziDevice, N = load("native-bridge.js").BliziNative;
let passed = 0;
const ok = async (name, fn) => { await fn(); passed++; console.log("ok  : " + name); };
const at = (y, mo, d, h, mi = 0) => new Date(y, mo - 1, d, h, mi, 0).getTime();

function rig({ nav, native } = {}) {
  const o = { t: at(2026, 11, 23, 9, 0), db: {} };
  const load2 = (k) => (k in o.db ? JSON.parse(o.db[k]) : null), save = (k, v) => { o.db[k] = JSON.stringify(v); };
  const extra = X.create({ now: () => o.t, load: load2, save });
  o.a = A.create({ R, D, X, extra, device: nav ? V.create(nav) : null, native, now: () => o.t, load: load2, save, say() {}, notify() {}, beep() {} });
  return o;
}

// ---- calculator
await ok("calc: precedence, parentheses, powers, decimals, unary minus", () => {
  assert.equal(X.calc("2+3*4"), 14); assert.equal(X.calc("(2+3)*4"), 20); assert.equal(X.calc("2^3^2"), 512);
  assert.equal(X.calc("10/4"), 2.5); assert.equal(X.calc("-3+5"), 2); assert.equal(X.calc("7%3"), 1); assert.equal(X.calc("1,000*2"), 2000); assert.equal(X.calc("12 x 3"), 36);
});
await ok("calc: rejects division by zero, junk, code, huge and unbalanced input", () => {
  for (const bad of ["1/0", "", "abc", "2+", "(2+3", "2))", "process.exit()", "1+1;alert(1)", "9".repeat(100), "()", "..", "2**3"]) assert.equal(X.calc(bad), null, bad);
});

// ---- notes, spending, calculator commands
await ok("notes: save, list, delete, never hijack plain text", () => {
  const o = rig();
  assert.equal(o.a.handle("note: wifi password is on the fridge").reply, "Saved your note.");
  o.a.handle("note: buy bread");
  assert.ok(o.a.handle("my notes").reply.includes("2. buy bread"));
  assert.equal(o.a.handle("delete note 1").reply, "Deleted that note.");
  assert.ok(o.a.handle("notes").reply.includes("1. buy bread"));
  for (const s of ["I wrote a note yesterday", "notes are useful", "take note of this"]) assert.equal(o.a.handle(s), null, s);
});
await ok("spending: log, totals today and month, no false positives", () => {
  const o = rig();
  assert.ok(o.a.handle("spent 12.50 on lunch").reply.includes("Logged 12.50 for lunch. Today: 12.50"));
  o.a.handle("I paid $7,5 for coffee"); o.t = at(2026, 11, 24, 9);
  const r = o.a.handle("spent 30 on fuel").reply; assert.ok(r.includes("Today: 30.00") && r.includes("This month: 50.00"));
  assert.equal(o.a.handle("my spending today").reply, "Today you’ve spent 30.00.");
  assert.equal(rig().a.handle("my spending").reply.includes("haven’t logged"), true);
  for (const s of ["I spent the weekend resting", "spent time on this", "spent 0 on air"]) assert.equal(o.a.handle(s), null, s);
});
await ok("calculator command only fires on real arithmetic", () => {
  const o = rig();
  assert.equal(o.a.handle("what is 12 * (3 + 4)").reply, "12 * (3 + 4) = 84");
  assert.equal(o.a.handle("calc 10/4").reply, "10/4 = 2.5");
  assert.ok(o.a.handle("calculate 1/0").reply.includes("couldn’t work that out"));
  for (const s of ["what is 5", "what is love", "what is 2024", "calc"]) assert.equal(o.a.handle(s), null, s);
});

// ---- brain dump
await ok("brain dump splits into todos", () => {
  assert.deepEqual(X.splitDump("call mum; buy milk and pay rent, book flights\nrenew passport"), ["call mum", "buy milk", "pay rent", "book flights", "renew passport"]);
  assert.equal(X.splitDump("x ".repeat(500)).length <= 12, true);
  const o = rig(); const r = o.a.handle("brain dump: call mum, buy milk and then clean the car");
  assert.ok(r.reply.includes("3 to-dos") && r.reply.includes("2. buy milk")); assert.equal(o.a._todo.list().length, 3);
});

// ---- routines
await ok("routines: save, run, list, delete, no nesting", () => {
  const o = rig();
  assert.ok(o.a.handle("routine morning: add todo stretch; remind me in 5 minutes to drink water").reply.includes("2 steps"));
  const run = o.a.handle("run routine morning").reply;
  assert.ok(run.includes("Added to your to-do list: stretch") && run.includes("drink water"));
  assert.equal(o.a._todo.list().length, 1); assert.equal(o.a._rem.list().length, 1);
  assert.ok(o.a.handle("my routines").reply.includes("morning (2 steps)"));
  assert.ok(o.a.handle("routine loop: run routine loop").reply.includes("can’t contain another routine"));
  assert.ok(o.a.handle("run routine nope").reply.includes("don’t have"));
  assert.ok(o.a.handle("delete routine morning").reply.includes("Deleted"));
});

// ---- morning brief
await ok("morning brief summarises the day", async () => {
  const o = rig(); o.a.handle("remind me at 3pm to call mum"); o.a.handle("add todo pay rent"); o.a.handle("spent 5 on tea");
  const r = o.a.handle("morning brief");
  assert.ok(r.reply.includes("Monday 23 November") && r.reply.includes("call mum (3:00 PM)") && r.reply.includes("pay rent") && r.reply.includes("Spent today: 5.00"));
  const o2 = rig({ nav: { getBattery: async () => ({ level: 0.5, charging: true, chargingTime: 600 }) } });
  const r2 = o2.a.handle("brief me"); const x = await r2.pending;
  assert.ok(x.reply.includes("Battery is at 50%, charging"));
});

// ---- device
await ok("battery in several browsers", async () => {
  assert.equal(await V.create({ getBattery: async () => ({ level: 0.82, charging: true, chargingTime: 5400 }) }).battery(), "Battery is at 82%, charging (full in about 1h 30m).");
  assert.ok((await V.create({ getBattery: async () => ({ level: 0.15, charging: false, dischargingTime: 3600 }) }).battery()).includes("low"));
  assert.ok((await V.create({}).battery()).includes("doesn’t share battery"));
  assert.ok((await V.create({ getBattery: async () => { throw new Error("x"); } }).battery()).includes("couldn’t read"));
});
await ok("location: success, denied, unsupported, garbage", async () => {
  const geo = (fn) => ({ geolocation: { getCurrentPosition: fn } });
  assert.equal(await V.create(geo((ok2) => ok2({ coords: { latitude: 6.52444, longitude: 3.37922, accuracy: 30.4 } }))).location(), "You’re near 6.524, 3.379 (accurate to about 30 m).");
  assert.ok((await V.create(geo((a, no) => no({ code: 1 }))).location()).includes("permission was denied"));
  assert.ok((await V.create(geo((a, no) => no({ code: 2 }))).location()).includes("couldn’t get"));
  assert.ok((await V.create({}).location()).includes("can’t share"));
  assert.ok((await V.create(geo((ok2) => ok2({ coords: { latitude: "x" } }))).location()).includes("unusable"));
});
await ok("system check on a minimal and a rich browser", async () => {
  assert.ok((await V.create({}).system()).includes("Online: yes"));
  const rich = await V.create({ onLine: false, connection: { effectiveType: "4g", downlink: 10 }, deviceMemory: 4, hardwareConcurrency: 8, storage: { estimate: async () => ({ usage: 5242880, quota: 1073741824 }) }, getBattery: async () => ({ level: 1, charging: true }) }).system();
  assert.ok(rich.includes("Online: no") && rich.includes("4g, about 10 Mbps") && rich.includes("5.0 MB used of 1024 MB") && rich.includes("Battery is at 100%"));
});
await ok("device commands route through handle as pending replies", async () => {
  const o = rig({ nav: { getBattery: async () => ({ level: 0.4, charging: false, dischargingTime: 7200 }), geolocation: { getCurrentPosition: (g) => g({ coords: { latitude: 1, longitude: 2, accuracy: 5 } }) } } });
  assert.ok((await o.a.handle("battery").pending).reply.includes("40%"));
  assert.ok((await o.a.handle("what's my battery level?").pending).reply.includes("40%"));
  assert.ok((await o.a.handle("where am I").pending).reply.includes("1.000, 2.000"));
  assert.ok((await o.a.handle("system status").pending).reply.startsWith("System check"));
  assert.equal(o.a.handle("my battery died yesterday"), null);
  assert.equal(rig().a.handle("battery"), null);
});

// ---- native-only features
await ok("native-only commands are honest on web and work once a shell registers them", () => {
  N._reset();
  const web = rig({ native: N });
  assert.ok(web.a.handle("open app WhatsApp").reply.includes("needs the Blizi phone app"));
  assert.ok(web.a.handle("sentry mode on").reply.includes("needs the Blizi phone app"));
  N.register("app_launch", (a) => a.name);
  assert.equal(rig({ native: N }).a.handle("open the app Maps").reply, "Done.");
  N.register("sentry", () => { throw new Error("x"); });
  assert.ok(rig({ native: N }).a.handle("guard on").reply.includes("didn’t work"));
});

console.log(`\n${passed} extras/device tests passed`);
