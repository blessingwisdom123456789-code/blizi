// Focused tests for the static-GLB viewing mode and the built-in character loader.
// WHAT IS REAL: the Body3D code from frontend/index.html, the GLB header inspection, the shipped GLB bytes, the Node host's /models route.
// WHAT IS FAKE: three.js, GLTFLoader, three-vrm, WebGL, fetch for the built-in sources, timers. Nothing here renders pixels or runs on a phone.
import fs from "node:fs";
import crypto from "node:crypto";
import { makeServer } from "../server.mjs";
let pass = 0, fail = 0;
const ok = (c, n) => { c ? pass++ : (fail++, console.log("FAIL:", n)); if (c) console.log("ok  :", n); };
const html = fs.readFileSync(new URL("../frontend/index.html", import.meta.url), "utf8");
const block = html.slice(html.indexOf("/* body3d */"), html.indexOf("/* /body3d */"));
const Body3D = new Function(block + ";return Body3D")();
const sleep = ms => new Promise(r => setTimeout(r, ms));
const GLB_PATH = new URL("../frontend/models/blizi-character.glb", import.meta.url);

// ---- GLB builders (valid header + JSON chunk) ----
function glb(json, { version = 2, truncate = 0, rawJson = null, chunkType = 0x4E4F534A } = {}) {
  const j = new TextEncoder().encode(rawJson ?? JSON.stringify(json)); const pad = (4 - j.length % 4) % 4; const jl = j.length + pad;
  const out = new Uint8Array(20 + jl); const dv = new DataView(out.buffer);
  dv.setUint32(0, 0x46546C67, true); dv.setUint32(4, version, true); dv.setUint32(8, out.length, true); dv.setUint32(12, jl, true); dv.setUint32(16, chunkType, true);
  out.set(j, 20); out.fill(32, 20 + j.length);
  return truncate ? out.slice(0, out.length - truncate).buffer : out.buffer;
}
const mesh = n => ({ meshes: [{ primitives: [{ attributes: { POSITION: 0 } }] }], accessors: [{ count: n }] });
const STATIC = () => glb({ asset: { version: "2.0" }, ...mesh(30890) });
const VRM0 = () => glb({ asset: { version: "2.0" }, extensions: { VRM: {} }, ...mesh(3) });

// ---- fake environment ----
function env({ urls = {}, parseFail = false, emptyScene = false, size = { x: .21, y: 1, z: .36 }, noGLTFLoader = false, sources, fetchMap = {}, anim } = {}) {
  const log = { scripts: [], status: [], notify: [], renders: 0, disposed: 0, set: [], scaleArgs: null, camPos: null, encoding: null, lights: [], added: [], removed: [], vrmFrom: 0 };
  let cb = null, id = 0, ioCb = null, flags = { flip: false, turn: false, anim };
  const holderObjs = [], winH = {};
  const TH = {
    sRGBEncoding: 3001, LinearEncoding: 3000,
    WebGLRenderer: function () { const r = { setPixelRatio() {}, setSize() {}, render: () => log.renders++, dispose() {} }; Object.defineProperty(r, "outputEncoding", { set: v => log.encoding = v, get: () => log.encoding }); return r; },
    Scene: function () { return { add: o => log.added.push(o), remove: o => log.removed.push(o) }; },
    PerspectiveCamera: function () { return { position: { set: (...a) => log.camPos = a }, lookAt() {}, updateProjectionMatrix() {} }; },
    AmbientLight: function (c, i) { const l = { intensity: i }; log.lights.push(l); return l; },
    DirectionalLight: function (c, i) { const l = { intensity: i, position: { set() {} } }; log.lights.push(l); return l; },
    Group: function () { const g = { rotation: { y: 0 }, position: { y: 0 }, scale: { set: (...a) => log.scaleArgs = a }, children: [], add(o) { g.children.push(o); }, traverse(fn) { fn(g); g.children.forEach(c => c.traverse && c.traverse(fn)); } }; holderObjs.push(g); return g; },
    Box3: function () { return { setFromObject() { return this; }, isEmpty: () => size.y === 0 && size.x === 0, getSize: () => ({ ...size }), getCenter: () => ({ x: .01, y: .02, z: .03 }) }; },
    Vector3: function () {}
  };
  const mat = { map: { isTexture: true, dispose: () => log.disposed++ }, dispose: () => log.disposed++ };
  const sceneRoot = () => ({ position: { x: 0, y: 0, z: 0 }, traverse(fn) { fn({ geometry: { dispose: () => log.disposed++ }, material: mat }); } });
  const win = { devicePixelRatio: 3, requestAnimationFrame: f => { cb = f; return ++id; }, cancelAnimationFrame() {}, addEventListener: (t, f) => { winH[t] = f; }, IntersectionObserver: function (f) { ioCb = f; this.observe = () => {}; } };
  const doc = { visibilityState: "visible", addEventListener() {},
    head: { appendChild(el) { log.scripts.push(el.src); setTimeout(() => {
      if ((urls[el.src] || "ok") === "fail") return el.onerror();
      if (el.src.includes("three.min")) win.THREE = TH;
      if (el.src.includes("GLTFLoader") && !noGLTFLoader) win.THREE.GLTFLoader = function () { this.parse = (b, p, res, rej) => parseFail ? rej(new Error("bad gltf")) : res({ scene: emptyScene ? null : sceneRoot() }); };
      if (el.src.includes("three-vrm")) win.THREE.VRM = { from: async () => { log.vrmFrom++; return { scene: { rotation: { y: 0 }, position: { y: 0 } }, humanoid: { getBoneNode: () => null }, blendShapeProxy: { setValue: (n, w) => log.set.push([n, w]) }, update() {} }; } };
      el.onload(); }, 0); } },
    createElement: t => t === "script" ? { src: "" } : { getContext: () => ({}) } };
  const hnd = {}; const cv = { hidden: true, clientWidth: 300, clientHeight: 340, addEventListener: (t, f) => hnd[t] = f };
  const svg = { style: { display: "" } };
  let taps = 0;
  const fetchFn = async u => { log.fetched = (log.fetched || []).concat(u); const r = fetchMap[u]; if (r === "throw") throw new Error("offline"); if (!r) return { ok: false, status: 404 }; await sleep(r.delay || 0); return { ok: true, arrayBuffer: async () => r.buf() }; };
  const b = Body3D({ win, doc, canvas: cv, svg, status: m => log.status.push(m), flags: () => flags, onTap: () => taps++, onModel: i => log.notify.push(i.kind), sources, fetch: sources ? fetchFn : undefined });
  let now = 1000; const tick = (ms = 33) => { now += ms; cb && cb(now); };
  const holder = () => holderObjs[holderObjs.length - 1];
  return { b, log, win, winH, doc, cv, svg, hnd, tick, holder, taps: () => taps, setFlags: f => flags = { ...flags, ...f }, status: () => log.status[log.status.length - 1], ioFire: v => ioCb([{ isIntersecting: v }]) };
}
const near = (a, b, e = 1e-6) => Math.abs(a - b) <= e;

// ===== 1. The shipped GLB: real bytes, real header inspection (structure only, NOT rendering) =====
const shipped = fs.readFileSync(GLB_PATH);
ok(shipped.length === 5242064 && crypto.createHash("sha256").update(shipped).digest("hex") === "473d2ccd319c96cde2c8aa891e4266a63eb061b631b8a4c452343fd77f62c2c1", "bundled character is byte-identical to the uploaded GLB (sha256 matches)");
const probe = env().b;
const real = probe.inspect(shipped.buffer.slice(shipped.byteOffset, shipped.byteOffset + shipped.byteLength));
ok(real.ok && real.kind === "static" && real.vertices === 30890 && real.skinned === false && real.animated === false, "REAL GLB header: classified static; 30,890 vertices; no skeleton; no animations");

// ===== 2. Header inspection: clear errors for invalid / unsupported files =====
const bad = (b, re, n) => { const r = probe.inspect(b); ok(r.ok === false && re.test(r.error), n + " -> " + r.error); };
bad(new ArrayBuffer(5), /empty/, "tiny file");
bad(new Uint8Array(40).buffer, /isn’t a VRM\/GLB/, "wrong magic");
bad(glb({}, { version: 1 }), /version 1/, "glTF 1.x");
bad(glb({ ...mesh(3) }, { truncate: 8 }), /cut off/, "truncated file");
bad(glb({}, { chunkType: 0x004E4942 }), /no readable model header/, "first chunk not JSON");
bad(glb(null, { rawJson: "{not json" }), /damaged/, "garbage JSON");
bad(glb({ ...mesh(3), extensionsRequired: ["KHR_draco_mesh_compression"] }), /KHR_draco_mesh_compression.*decoder/, "Draco compression required");
bad(glb({ ...mesh(3), extensionsRequired: ["EXT_meshopt_compression"] }), /meshopt.*decoder/, "meshopt compression required");
bad(glb({ ...mesh(3), extensionsRequired: ["SOME_FUTURE_THING"] }), /SOME_FUTURE_THING/, "unknown required extension");
bad(glb({ asset: { version: "2.0" } }), /no 3D mesh/, "no meshes");
bad(glb(mesh(600000)), /too heavy.*600k/, "too many vertices for a phone");
bad(glb({ ...mesh(3), extensions: { VRMC_vrm: {} } }), /VRM 1\.0/, "VRM 1.0");
ok(probe.inspect(VRM0()).kind === "vrm" && probe.inspect(STATIC()).kind === "static", "VRM 0.x is classified vrm; plain GLB is classified static");
ok(probe.inspect(glb({ ...mesh(3), extensionsRequired: ["KHR_texture_transform", "KHR_materials_unlit"] })).ok, "supported required extensions are accepted");
ok(probe.inspect(glb({ ...mesh(3), skins: [{}] })).skinned === true, "a skinned non-VRM file is detected (shown static)");

// ===== 3. Static load: only three + GLTFLoader (NOT three-vrm), framing, status =====
let e = env({ urls: Object.fromEntries(["https://cdn.jsdelivr.net/npm/@pixiv/three-vrm@0.6.7/lib/three-vrm.js"].map(u => [u, "fail"])) }); e.b.enable(true, { manual: true });
ok((await e.b.loadModel(STATIC(), { yaw: -Math.PI / 2 })) === true, "static GLB loads");
ok(e.log.scripts.length === 2 && e.log.scripts[0].includes("three.min") && e.log.scripts[1].includes("GLTFLoader") && !e.log.scripts.some(s => s.includes("three-vrm")), "static mode downloads only three.js + GLTFLoader (three-vrm is never fetched)");
ok(e.b.info().kind === "static" && e.b.info().ready && e.svg.style.display === "none" && e.cv.hidden === false, "canvas shown, 2D hidden, kind = static");
ok(/Static 3D model loaded/.test(e.status()) && /no skeleton/.test(e.status()) && /lip-sync/.test(e.status()) && /rigged VRM/.test(e.status()), "status clearly says: static, no skeleton, no lip-sync/gestures without a rigged VRM");
ok(e.log.notify.includes("static"), "UI is told the loaded kind is static (used to disable VRM-only controls)");
ok(near(e.log.scaleArgs[0], 1.6) && near(e.log.scaleArgs[1], 1.6), "model normalised to 1.6 units tall (height 1.0 -> scale 1.6)");
const cz = e.log.camPos[2]; ok(e.log.camPos[0] === 0 && e.log.camPos[1] === 0 && cz > 3 && cz < 8 && isFinite(cz), "camera is centred and far enough to frame a 1.6-unit body (z=" + cz.toFixed(2) + ")");
ok(e.log.encoding === 3001, "static mode sets sRGB output encoding");
ok(near(e.log.lights[0].intensity, .5) && near(e.log.lights[1].intensity, .7), "softer lights for the PBR static material");
// wide canvas vs tall canvas: portrait phone canvases are width-limited
const zWide = e.log.camPos[2]; e.cv.clientWidth = 120; e.cv.clientHeight = 340; e.winH.resize();
ok(e.log.camPos[2] > zWide + .3, "a narrower (portrait) canvas moves the camera back so the body still fits (" + zWide.toFixed(2) + " -> " + e.log.camPos[2].toFixed(2) + ")");
e.cv.clientWidth = 300; e.cv.clientHeight = 340; e.winH.resize();
// ===== 4. Static motion: sway, base yaw, turn flag, reduced motion, tap bounce, drag =====
e.b.view(true); e.tick(); e.tick();
const h = e.holder(); const y1 = h.rotation.y;
for (let i = 0; i < 30; i++) e.tick(); const y2 = h.rotation.y;
ok(Math.abs(y1 + Math.PI / 2) < .45 && Math.abs(y2 + Math.PI / 2) < .45 && y1 !== y2, "gentle sway around the base yaw (-90 deg for the bundled model), bounded to about +/-0.4 rad");
e.setFlags({ turn: true }); e.tick(); ok(Math.abs(h.rotation.y - (-Math.PI / 2 + Math.PI)) < .45, "Turn her around adds 180 degrees");
e.setFlags({ turn: false, anim: false }); e.tick(); e.tick(); const f1 = h.rotation.y; for (let i = 0; i < 20; i++) e.tick(); ok(near(h.rotation.y, f1) && near(f1, -Math.PI / 2), "animations off (or reduced motion) -> no sway");
e.setFlags({ anim: true });
e.hnd.pointerdown({ clientX: 100 }); e.hnd.pointerup(); ok(e.taps() === 1, "tap still calls the app reaction");
let maxHop = 0; for (let i = 0; i < 25; i++) { e.tick(); maxHop = Math.max(maxHop, h.position.y); }
ok(maxHop > .05, "tap makes the model hop (max " + maxHop.toFixed(3) + ")");
for (let i = 0; i < 30; i++) e.tick(); ok(h.position.y === 0, "bounce ends and the model lands back at 0");
const yawBefore = h.rotation.y; e.hnd.pointerdown({ clientX: 100 }); e.hnd.pointermove({ clientX: 400 }); e.hnd.pointerup(); e.tick(); e.tick();
ok(Math.abs(h.rotation.y - yawBefore) > 1.5, "drag turns a static model freely (not clamped to VRM's +/-0.9)");
// ===== 5. VRM-only features are disabled for a static model =====
ok(e.b.gesture("wave") === false && e.b.gesture("jump") === false && e.b.gesture("dance") === false, "gestures refused for a static model");
e.b.state("speaking"); e.b.mouth(.9); for (let i = 0; i < 10; i++) e.tick(); ok(e.log.set.length === 0 && e.log.vrmFrom === 0, "expressions / mouth / lip-sync input have no effect on a static model (no blendshape calls)");
// ===== 6. Switching models disposes the old one; off/on keeps it =====
const d0 = e.log.disposed; await e.b.loadModel(STATIC()); ok(e.log.disposed > d0 && e.log.removed.length >= 1, "loading another model disposes the previous geometry/textures");
e.b.enable(false); ok(e.svg.style.display === "" && e.cv.hidden === true && !e.b.info().running, "switching 3D off shows 2D and stops rendering");
e.b.enable(true, { manual: true }); ok(e.b.info().ready && e.b.info().kind === "static" && /3D is on/.test(e.status()), "switching back on keeps the loaded model without re-downloading");

// ===== 7. Error handling =====
e = env(); e.b.enable(true, { manual: true });
ok((await e.b.loadModel(glb({ ...mesh(3), extensionsRequired: ["KHR_draco_mesh_compression"] }))) === false && /KHR_draco/.test(e.status()) && e.svg.style.display === "" && e.log.scripts.length === 0, "unsupported model -> clear message, 2D stays, nothing downloaded");
ok((await e.b.loadModel(glb(null, { rawJson: "{bad" }))) === false && /damaged/.test(e.status()) && e.log.scripts.length === 0, "damaged GLB -> clear message before any download");
e = env({ urls: { "https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js": "fail" } }); e.b.enable(true, { manual: true });
ok((await e.b.loadModel(STATIC())) === false && /Couldn’t load the model/.test(e.status()) && /download failed/.test(e.status()) && /cdnjs/.test(e.status()) && e.svg.style.display === "", "missing three.js -> readable error naming the host, 2D stays");
e = env({ noGLTFLoader: true }); e.b.enable(true, { manual: true });
ok((await e.b.loadModel(STATIC())) === false && /did not start/.test(e.status()), "library loaded but not initialised -> readable error");
e = env({ parseFail: true }); e.b.enable(true, { manual: true });
ok((await e.b.loadModel(STATIC())) === false && /Couldn’t load the model: bad gltf/.test(e.status()) && e.svg.style.display === "", "GLTFLoader parse failure -> readable error, 2D stays");
e = env({ emptyScene: true }); e.b.enable(true, { manual: true });
ok((await e.b.loadModel(STATIC())) === false && /no scene/.test(e.status()), "file with no scene -> readable error");
e = env({ size: { x: 0, y: 0, z: 0 } }); e.b.enable(true, { manual: true });
ok((await e.b.loadModel(STATIC())) === false && /no visible geometry/.test(e.status()), "empty bounding box -> readable error");
e = env({ size: { x: 1, y: NaN, z: 1 } }); e.b.enable(true, { manual: true });
ok((await e.b.loadModel(STATIC())) === false && /no usable size/.test(e.status()), "NaN bounds -> readable error");
e = env(); e.b.enable(true, { manual: true }); await e.b.loadModel(STATIC()); e.hnd.webglcontextlost({ preventDefault() {} });
ok(e.svg.style.display === "" && e.cv.hidden === true && /Using 2D/.test(e.status()) && e.b.info().kind === null, "WebGL context loss in static mode -> 2D fallback");
// static still works when every three-vrm URL is dead (isolation of the VRM dependency)
e = env({ urls: Object.fromEntries(["https://cdn.jsdelivr.net/npm/@pixiv/three-vrm@0.6.7/lib/three-vrm.js", "https://unpkg.com/@pixiv/three-vrm@0.6.7/lib/three-vrm.js", "https://cdn.jsdelivr.net/npm/@pixiv/three-vrm@0.3.4/lib/three-vrm.js", "https://unpkg.com/@pixiv/three-vrm@0.3.4/lib/three-vrm.js"].map(u => [u, "fail"])) }); e.b.enable(true, { manual: true });
ok((await e.b.loadModel(STATIC())) === true, "static GLB works even if all three-vrm builds are unreachable");
ok((await e.b.loadModel(VRM0())) === false && /No compatible three-vrm/.test(e.status()), "a VRM file in the same situation still reports the three-vrm error (existing behaviour preserved)");

// ===== 8. VRM path preserved =====
e = env(); e.b.enable(true, { manual: true });
ok((await e.b.loadModel(VRM0())) === true && e.b.info().kind === "vrm" && e.log.vrmFrom === 1 && e.log.scripts.some(s => s.includes("three-vrm")) && /Not verified on this phone/.test(e.status()), "VRM 0.x still loads through three-vrm and keeps its status text");
ok(e.log.encoding === 3000 && e.b.gesture("wave") === true, "VRM keeps linear encoding and gestures");
await e.b.loadModel(STATIC()); ok(e.b.info().kind === "static" && e.b.gesture("wave") === false, "switching VRM -> static switches modes cleanly");

// ===== 9. Built-in character loader =====
const SRC = [{ url: "models/blizi-character.vrm" }, { url: "models/blizi-character.glb", yaw: -Math.PI / 2 }];
e = env({ sources: SRC, fetchMap: { "models/blizi-character.glb": { buf: STATIC } } }); e.b.enable(true);
await sleep(30); ok(e.b.info().kind === "static" && e.b.info().ready && JSON.stringify(e.log.fetched) === JSON.stringify(SRC.map(s => s.url)), "enabling 3D auto-loads the built-in GLB (a missing .vrm is skipped silently)");
e.tick(); e.tick(); ok(Math.abs(e.holder().rotation.y + Math.PI / 2) < .45, "built-in character uses its -90 degree facing correction");
e = env({ sources: SRC, fetchMap: { "models/blizi-character.vrm": { buf: VRM0 }, "models/blizi-character.glb": { buf: STATIC } } }); e.b.enable(true); await sleep(30);
ok(e.b.info().kind === "vrm" && !e.log.fetched.includes("models/blizi-character.glb"), "a rigged VRM at models/blizi-character.vrm takes priority over the GLB (upgrade path, no code change)");
e = env({ sources: SRC, fetchMap: { "models/blizi-character.vrm": { buf: () => new TextEncoder().encode("<html>SPA fallback</html>").buffer }, "models/blizi-character.glb": { buf: STATIC } } }); e.b.enable(true); await sleep(30);
ok(e.b.info().kind === "static", "a host that answers 200 with HTML for a missing file is treated as missing");
e = env({ sources: SRC, fetchMap: { "models/blizi-character.vrm": { buf: () => glb({ ...mesh(3), extensions: { VRMC_vrm: {} } }) }, "models/blizi-character.glb": { buf: STATIC } } }); e.b.enable(true); await sleep(30);
ok(e.b.info().kind === "static", "an unsupported .vrm falls through to the static GLB");
e = env({ sources: SRC, fetchMap: {} }); e.b.enable(true); await sleep(30);
ok(!e.b.info().ready && e.svg.style.display === "" && /built-in character couldn’t be downloaded/.test(e.status()) && /Using 2D/.test(e.status()), "no built-in file reachable -> clear message, 2D stays");
e = env({ sources: SRC, fetchMap: { "models/blizi-character.vrm": "throw", "models/blizi-character.glb": "throw" } }); e.b.enable(true); await sleep(30);
ok(!e.b.info().ready && /couldn’t be downloaded/.test(e.status()), "network failure -> same clear message, no crash");
e = env({ sources: SRC, fetchMap: { "models/blizi-character.glb": { buf: STATIC, delay: 40 } } }); e.b.enable(true);
await sleep(5); const mine = await e.b.loadModel(VRM0()); await sleep(80);
ok(mine === true && e.b.info().kind === "vrm", "a model the user picks while the built-in one is downloading wins; the late built-in result is dropped");
e = env({ sources: SRC, fetchMap: { "models/blizi-character.glb": { buf: STATIC, delay: 40 } } }); e.b.enable(true); await sleep(5); e.b.enable(false); await sleep(80);
ok(!e.b.info().ready && e.svg.style.display === "", "switching 3D off while downloading cancels the built-in load");
e = env({ sources: SRC, fetchMap: { "models/blizi-character.glb": { buf: STATIC } } }); e.b.enable(true, { manual: true }); await sleep(10);
ok(!e.log.fetched && /Choose a VRM or GLB file/.test(e.status()), "manual enable (user is picking a file) does not download the built-in character");
e = env(); e.b.enable(true); ok(/Choose a VRM or GLB file/.test(e.status()) && e.log.scripts.length === 0, "with no sources configured, enabling 3D downloads nothing (previous behaviour)");

// ===== 10. Node host serves the model safely =====
const app = makeServer({}); await new Promise(r => app.listen(0, "127.0.0.1", r)); const base = `http://127.0.0.1:${app.address().port}`;
const r1 = await fetch(base + "/models/blizi-character.glb"); const body = Buffer.from(await r1.arrayBuffer());
ok(r1.status === 200 && r1.headers.get("content-type") === "model/gltf-binary" && body.equals(shipped) && !!r1.headers.get("etag"), "/models/blizi-character.glb served with the right type and exact bytes");
const r2 = await fetch(base + "/models/blizi-character.glb", { headers: { "if-none-match": r1.headers.get("etag") } }); await r2.arrayBuffer(); ok(r2.status === 304, "repeat request revalidates with ETag (304, no 5 MB re-download)");
const r3 = await fetch(base + "/models/blizi-character.vrm"); await r3.arrayBuffer(); ok(r3.status === 404, "absent optional .vrm is a clean 404 (not a 500)");
for (const p of ["/models/", "/models/other.glb", "/models/..%2Fserver.mjs", "/models/%2e%2e/server.mjs", "/frontend/models/blizi-character.glb"]) { const r = await fetch(base + p); await r.arrayBuffer(); ok(r.status === 404, "not served: " + p); }
app.close();

// ===== 11. Page wiring (string-level) =====
ok(/onModel:b3dUi/.test(html) && /sources:\[\{url:"models\/blizi-character\.vrm"\},\{url:"models\/blizi-character\.glb",yaw:-Math\.PI\/2\}\]/.test(html), "page passes the built-in sources (VRM first, GLB with -90 deg yaw) and the UI callback");
ok(/function b3dUi/.test(html) && /"gWave","gJump","gDance","s3dFlip"/.test(html) && /id="b3dBuiltin"/.test(html) && /id="gNote"/.test(html), "VRM-only controls are disabled for static models; built-in button and note exist");
ok(/B3\.enable\(true,\{manual:true\}\)/.test(html), "picking a file does not also trigger the built-in download");
console.log(`\n${pass} passed, ${fail} failed (FAKE three.js/WebGL/fetch: logic only. The GLB header/bytes and Node route are real; NO real rendering, phone, or browser was tested)`);
process.exitCode = fail ? 1 : 0;
