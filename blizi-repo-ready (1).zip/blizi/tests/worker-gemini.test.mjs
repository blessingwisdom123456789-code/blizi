import worker from "../backend/worker.js";
import { mockD1, sha256 } from "./helpers/mock-d1.mjs";
let pass=0,fail=0;const ok=(c,n)=>{c?pass++:(fail++,console.log("FAIL:",n));if(c)console.log("ok  :",n)};
const FAKE="DUMMY-TEST-KEY-0000";
const DB=mockD1(),sessionToken="gemini-test-session";
await DB.sessions.set(await sha256(sessionToken),{user_id:"owner",created_at:Date.now(),expires_at:Date.now()+86400000});
const env={DB,BLIZI_AUTH_PASSWORD:"correct-horse-battery-staple",SESSION_SECRET:"test-session-secret-at-least-32-bytes",MEMORY_ENCRYPTION_KEY:"test-memory-encryption-key-at-least-32",BLIZI_COOKIE_INSECURE:"true",GEMINI_API_KEY:FAKE,GEMINI_MODEL_FAST:"model-fast",GEMINI_MODEL_DEEP:"model-deep",ALLOWED_ORIGINS:"https://site.test"};
let mode="ok",last=null;const logs=[];const cl=console.log;
globalThis.fetch=async(url,init)=>{
  last={url:String(url),headers:init.headers,body:JSON.parse(init.body)};
  const R=(s,b)=>new Response(typeof b==="string"?b:JSON.stringify(b),{status:s});
  switch(mode){
   case"429":return R(429,{error:{message:"quota"}});
   case"badkey":return R(400,{error:{message:"API key not valid. Please pass a valid API key.",status:"INVALID_ARGUMENT"}});
   case"403":return R(403,{error:{message:"denied"}});
   case"404":return R(404,{error:{message:"models/x is not found"}});
   case"400other":return R(400,{error:{message:"bad field"}});
   case"500":return R(500,"oops");
   case"badjson":return R(200,"nope");
   case"nocand":return R(200,{});
   case"blocked":return R(200,{promptFeedback:{blockReason:"SAFETY"}});
   case"safetyfinish":return R(200,{candidates:[{finishReason:"SAFETY"}]});
   case"emptytext":return R(200,{candidates:[{content:{parts:[{text:"  "}]},finishReason:"MAX_TOKENS"}]});
   case"thought":return R(200,{candidates:[{content:{parts:[{text:"hidden",thought:true},{text:"[happy] Hi "},{text:"there"}]}}]});
   case"down":throw new TypeError("net");
   default:return R(200,{candidates:[{content:{parts:[{text:"[happy] Hello from Gemini"}]},finishReason:"STOP"}]});
  }};
const H={"Content-Type":"application/json",Origin:"https://site.test",Cookie:"blizi_session="+sessionToken};
const call=(b)=>{DB.rateLimits.clear();return worker.fetch(new Request("https://w.test/chat",{method:"POST",headers:H,body:JSON.stringify(b)}),env)};
const good={messages:[{role:"user",content:"hi"},{role:"assistant",content:"hello"},{role:"user",content:"how are you"}],system:"be nice",tier:"fast"};
let r=await call(good),j=await r.json();
ok(r.status===200&&j.text==="[happy] Hello from Gemini","mock Gemini success -> text");
ok(last.url==="https://generativelanguage.googleapis.com/v1beta/models/model-fast:generateContent","URL uses configured model, generateContent");
ok(last.headers["x-goog-api-key"]===FAKE&&!last.url.includes(FAKE),"key sent in header, not in URL");
ok(JSON.stringify(last.body.contents.map(c=>c.role))==='["user","model","user"]',"assistant mapped to model role");
ok(last.body.contents[0].parts[0].text==="hi"&&last.body.systemInstruction.parts[0].text==="be nice","contents/parts + systemInstruction shape");
ok(typeof last.body.generationConfig.maxOutputTokens==="number","generationConfig present");
ok(!JSON.stringify(j).includes(FAKE),"key not in response body");
r=await call({...good,tier:"deep"});await r.json();ok(last.url.includes("model-deep:"),"deep tier uses deep model");
const e2={...env};delete e2.GEMINI_MODEL_DEEP;DB.rateLimits.clear();r=await worker.fetch(new Request("https://w.test/chat",{method:"POST",headers:H,body:JSON.stringify({...good,tier:"deep"})}),e2);await r.json();ok(last.url.includes("model-fast:"),"deep falls back to fast model");
r=await call({messages:[{role:"user",content:"hi"}]});await r.json();ok(!("systemInstruction" in last.body),"no systemInstruction when none given");
for(const [m,st,e] of [["429",429,"provider_rate_limited"],["badkey",502,"provider_auth_failed"],["403",502,"provider_auth_failed"],["404",502,"provider_model_not_found"],["400other",502,"provider_error"],["500",502,"provider_error"],["badjson",502,"provider_bad_response"],["nocand",502,"provider_bad_response"],["blocked",502,"provider_blocked"],["safetyfinish",502,"provider_blocked"],["emptytext",502,"provider_bad_response"],["down",504,"provider_unreachable"]]){
  mode=m;r=await call(good);j=await r.json();const s=JSON.stringify(j);
  ok(r.status===st&&j.error===e,`gemini ${m} -> ${st} ${e}`);ok(!s.includes(FAKE)&&!s.includes("API key not valid")&&!s.includes("quota"),`no key/provider text leaked on ${m}`)}
mode="thought";r=await call(good);j=await r.json();ok(j.text==="[happy] Hi there"&&!j.text.includes("hidden"),"thought parts dropped, text parts joined");mode="ok";
const bad={...env,GEMINI_MODEL_FAST:"../evil?x=1"};DB.rateLimits.clear();r=await worker.fetch(new Request("https://w.test/chat",{method:"POST",headers:H,body:JSON.stringify(good)}),bad);ok(r.status===500,"unsafe model id rejected");
const none={...env};delete none.GEMINI_MODEL_FAST;DB.rateLimits.clear();r=await worker.fetch(new Request("https://w.test/chat",{method:"POST",headers:H,body:JSON.stringify(good)}),none);ok(r.status===500,"missing model -> 500 not_configured");
console.log(`\n${pass} passed, ${fail} failed (ALL MOCK; no real Gemini request was made)`);
