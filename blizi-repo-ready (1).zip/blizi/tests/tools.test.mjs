import fs from "node:fs";
import assert from "node:assert/strict";

const load = (f) => { const root = {}; new Function("window", fs.readFileSync(new URL("../frontend/tools/" + f, import.meta.url), "utf8"))(root); return root; };
const T = load("registry.js").BliziTools, N = load("native-bridge.js").BliziNative, R = load("reminders.js").BliziReminders, D = load("todos.js").BliziTodos;
let passed = 0;
const ok = (name, fn) => { fn(); passed++; console.log("ok  : " + name); };
const at = (y, mo, d, h, mi = 0) => new Date(y, mo - 1, d, h, mi, 0).getTime();
const mem = (init = []) => { let v = init; return { get: () => v, set: (x) => { v = x; } }; };

// ---- registry
const echo = { name: "echo", description: "Echo text", params: { text: { type: "string", required: true, max: 10 }, n: { type: "number", min: 1, max: 5 }, mode: { type: "enum", values: ["a", "b"] } }, run: (a) => a };
const danger = { name: "open_link", description: "Open a link", risk: "confirm", params: { url: { type: "string", required: true } }, run: (a) => "opened " + a.url, describe: (a) => "Open " + a.url };

ok("registry: valid call runs, strings are cleaned and capped", () => {
  T._reset(); T.register(echo);
  const r = T.execute("echo", { text: "  hello\u0000 world, long text  " });
  assert.equal(r.ok, true); assert.equal(r.result.text, "hello worl");
});
ok("registry: unknown tool, unknown key, missing, wrong type, out of range, bad enum are all rejected", () => {
  assert.equal(T.execute("nope", {}).error, "unknown_tool");
  assert.equal(T.execute("echo", { text: "x", evil: 1 }).error, "unknown_arg:evil");
  assert.equal(T.execute("echo", {}).error, "missing_arg:text");
  assert.equal(T.execute("echo", { text: 5 }).error, "bad_type:text");
  assert.equal(T.execute("echo", { text: "x", n: 9 }).error, "out_of_range:n");
  assert.equal(T.execute("echo", { text: "x", n: NaN }).error, "bad_type:n");
  assert.equal(T.execute("echo", { text: "x", mode: "c" }).error, "bad_value:mode");
  assert.equal(T.execute("echo", null).error, "bad_args");
  assert.equal(T.execute("echo", [1]).error, "bad_args");
});
ok("registry: prototype names are not tools", () => {
  assert.equal(T.execute("__proto__", {}).error, "unknown_tool");
  assert.equal(T.execute("constructor", {}).error, "unknown_tool");
  assert.equal(T.execute("hasOwnProperty", {}).error, "unknown_tool");
});
ok("registry: risky tools need confirmation and never run before it", () => {
  T.register(danger);
  const r = T.execute("open_link", { url: "https://example.com" });
  assert.equal(r.ok, false); assert.equal(r.needsConfirm, true);
  assert.equal(r.card.summary, "Open https://example.com");
  assert.equal(T.execute("open_link", { url: "https://example.com" }, { confirmed: "yes" }).needsConfirm, true);
  assert.equal(T.execute("open_link", { url: "https://example.com" }, { confirmed: true }).result, "opened https://example.com");
});
ok("registry: a throwing tool returns a safe error", () => {
  T.register({ name: "boom", description: "x", params: {}, run: () => { throw new Error("secret"); } });
  assert.deepEqual(T.execute("boom", {}), { ok: false, error: "tool_failed" });
});
ok("registry: bad registrations are refused", () => {
  assert.throws(() => T.register({ name: "Bad Name", run() {} }));
  assert.throws(() => T.register({ name: "echo", run() {} }));
  assert.throws(() => T.register({ name: "norun" }));
});
ok("extractCalls: parses markers, strips them, caps at 3, ignores malformed JSON", () => {
  const e = T.extractCalls('Sure. [[tool echo {"text":"hi"}]] done [[tool echo {bad}]] [[tool a1 {}]] [[tool b1]] [[tool c1]]');
  assert.deepEqual(e.calls.map((c) => c.name), ["echo", "a1", "b1"]);
  assert.equal(e.text.includes("[[tool"), false);
  assert.deepEqual(T.extractCalls("[[tool echo []]]").calls, []);
  assert.deepEqual(T.extractCalls(null).calls, []);
});
ok("manifest lists tools compactly", () => {
  const m = T.manifest(); assert.ok(m.includes("echo(text,n,mode)")); assert.ok(m.length < 600);
});

// ---- native bridge
ok("native bridge: unavailable on web, pluggable later", () => {
  N._reset();
  assert.equal(N.capabilities().native, false);
  assert.deepEqual(N.call("accessibility", {}), { ok: false, error: "unavailable_on_web" });
  assert.deepEqual(N.call("hack", {}), { ok: false, error: "unknown_feature" });
  assert.throws(() => N.register("hack", () => 1));
  N.register("wake_word", (a) => "on:" + a.word);
  assert.equal(N.call("wake_word", { word: "blizi" }).result, "on:blizi");
  assert.equal(N.capabilities().features.wake_word, true);
  assert.equal(N.call("overlay").error, "unavailable_on_web");
});

// ---- reminders parser
const NOW = at(2026, 11, 23, 10, 0);
ok("parse: relative times", () => {
  assert.equal(R.parse("remind me to call mum in 10 minutes", NOW).at, NOW + 600000);
  assert.equal(R.parse("remind me to call mum in 10 minutes", NOW).text, "call mum");
  assert.equal(R.parse("in an hour stretch", NOW).at, NOW + 3600000);
  assert.equal(R.parse("Remind me in 2 hours to take the bins out", NOW).at, NOW + 7200000);
  assert.equal(R.parse("in 30 secs check oven", NOW).at, NOW + 30000);
  assert.equal(R.parse("in three days renew pass", NOW).at, NOW + 3 * 86400000);
});
ok("parse: clock times with am/pm and 24h", () => {
  assert.equal(R.parse("remind me at 3pm to eat", NOW).at, at(2026, 11, 23, 15));
  assert.equal(R.parse("at 9am gym", NOW).at, at(2026, 11, 24, 9));
  assert.equal(R.parse("at 18:30 dinner", NOW).at, at(2026, 11, 23, 18, 30));
  assert.equal(R.parse("at 6:05 pm tea", NOW).at, at(2026, 11, 23, 18, 5));
  assert.equal(R.parse("at 12am sleep", NOW).at, at(2026, 11, 24, 0));
  assert.equal(R.parse("at 12pm lunch", NOW).at, at(2026, 11, 23, 12));
});
ok("parse: bare '7' means the sooner of 7 AM or 7 PM", () => {
  assert.equal(R.parse("remind me at 7 to cook", NOW).at, at(2026, 11, 23, 19));
  assert.equal(R.parse("remind me at 7 to cook", at(2026, 11, 23, 5)).at, at(2026, 11, 23, 7));
  assert.equal(R.parse("at 7 call", at(2026, 11, 23, 20)).at, at(2026, 11, 24, 7));
});
ok("parse: tomorrow and tonight", () => {
  assert.equal(R.parse("tomorrow at 8 meeting", NOW).at, at(2026, 11, 24, 8));
  assert.equal(R.parse("tomorrow at 3 meeting", NOW).at, at(2026, 11, 24, 15));
  assert.equal(R.parse("tonight at 9 movie", NOW).at, at(2026, 11, 23, 21));
  assert.equal(R.parse("remind me tomorrow to pay rent", NOW).at, at(2026, 11, 24, 9));
});
ok("parse: stacked polite prefixes and non-times", () => {
  assert.equal(R.parse("Hey Blizi, can you remind me to call in 5 minutes", NOW).text, "call");
  assert.equal(R.parse("please remind me in 5 minutes to stretch", NOW).text, "stretch");
  assert.equal(R.parse("buy 2 eggs", NOW), null);
  assert.equal(R.parse("what is 5 minutes in seconds", NOW), null);
  assert.equal(R.parse("", NOW), null);
  assert.equal(R.parse(null, NOW), null);
});
ok("parse: invalid and absurd input", () => {
  assert.equal(R.parse("at 25:00 x", NOW), null);
  assert.equal(R.parse("at 13pm x", NOW), null);
  assert.equal(R.parse("at 7:99 x", NOW), null);
  assert.equal(R.parse("in 0 minutes x", NOW), null);
  assert.equal(R.parse("in 9999 days x", NOW), null);
  assert.equal(R.parse("in 5 minutes " + "x".repeat(1000), NOW).text.length <= 140, true);
});

// ---- scheduler with a fake clock
ok("scheduler: add, list sorted, cancel, next", () => {
  const s = R.create(mem());
  const a = s.add("b", NOW + 2000, NOW), b = s.add("a", NOW + 1000, NOW);
  assert.deepEqual(s.list().map((r) => r.text), ["a", "b"]);
  assert.equal(s.nextAt(), NOW + 1000);
  assert.equal(s.cancel(a.id), true); assert.equal(s.cancel("zzz"), false);
  assert.equal(s.list().length, 1); assert.notEqual(a.id, b.id);
});
ok("scheduler: due fires once, in order, on time not late", () => {
  const s = R.create(mem());
  s.add("two", NOW + 2000, NOW); s.add("one", NOW + 1000, NOW);
  assert.deepEqual(s.due(NOW), []);
  const d = s.due(NOW + 2500);
  assert.deepEqual(d.map((r) => r.text), ["one", "two"]); assert.equal(d[0].late, false);
  assert.deepEqual(s.due(NOW + 9000), []);
});
ok("scheduler: catch-up after the app was closed marks reminders late", () => {
  const store = mem(); const s = R.create(store);
  s.add("missed", NOW + 60000, NOW);
  const d = s.due(NOW + 3 * 3600000);
  assert.equal(d.length, 1); assert.equal(d[0].late, true);
});
ok("scheduler: old fired reminders are pruned and the list is capped", () => {
  const store = mem(); const s = R.create(store);
  s.add("x", NOW + 1, NOW); s.due(NOW + 5);
  s.add("y", NOW + 8 * 86400000, NOW); s.due(NOW + 8 * 86400000 + 5);
  assert.equal(store.get().some((r) => r.text === "x"), false);
  const c = R.create(mem()); let last;
  for (let i = 0; i < R.MAX + 5; i++) last = c.add("r" + i, NOW + 1000 + i, NOW);
  assert.equal(last, null); assert.equal(c.list().length, R.MAX);
});
ok("scheduler: corrupt storage does not crash", () => {
  const s = R.create({ get: () => "garbage", set() {} });
  assert.deepEqual(s.list(), []); assert.deepEqual(s.due(NOW), []);
});

// ---- todos
ok("todos: add, list, done, remove, input hygiene", () => {
  const t = D.create(mem());
  const a = t.add("  buy\u0000   milk ", NOW), b = t.add("call dad", NOW);
  assert.equal(a.text, "buy milk"); assert.equal(t.add("   ", NOW), null);
  assert.equal(t.list().length, 2);
  assert.equal(t.done(a.id), true); assert.equal(t.done(a.id), false);
  assert.deepEqual(t.list().map((x) => x.text), ["call dad"]);
  assert.equal(t.list(true).length, 2);
  assert.equal(t.remove(b.id), true); assert.equal(t.remove("no"), false);
});

console.log(`\n${passed} tool tests passed`);
