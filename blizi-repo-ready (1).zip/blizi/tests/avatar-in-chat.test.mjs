// The avatar must appear above the conversation while chatting, and return to Home.
// Runs the REAL placeStage() from index.html against a tiny fake DOM (no layout, no browser).
import fs from "node:fs";
let pass = 0, fail = 0;
const ok = (c, n) => { c ? pass++ : (fail++, console.log("FAIL:", n)); if (c) console.log("ok  :", n); };
const html = fs.readFileSync(new URL("../frontend/index.html", import.meta.url), "utf8");

const m = html.match(/function placeStage\(v\)\{[\s\S]*?\n\}/);
ok(!!m, "placeStage() exists in the page script");

function node(name) {
  const n = { name, parentNode: null, kids: [] };
  n.insertBefore = (child, ref) => {
    if (child.parentNode) child.parentNode.kids = child.parentNode.kids.filter(k => k !== child);
    child.parentNode = n;
    const i = ref ? n.kids.indexOf(ref) : -1;
    i >= 0 ? n.kids.splice(i, 0, child) : n.kids.push(child);
  };
  return n;
}
const home = node("home"), chat = node("chat"), stage = node("stage"), hero = node("hero"), log = node("log");
home.insertBefore(stage); home.insertBefore(hero);       // Home: stage, then hero
chat.insertBefore(log);                                  // Chat: log
const $ = s => ({ ".stage": stage, "#v-home": home, "#v-chat": chat, "#log": log, ".hero": hero })[s];
const placeStage = new Function("$", m[0] + "; return placeStage;")($);

placeStage("chat");
ok(stage.parentNode === chat, "opening Chat moves the avatar into the chat view");
ok(chat.kids[0] === stage && chat.kids[1] === log, "avatar sits above the message list");
ok(!home.kids.includes(stage), "avatar is not duplicated on Home while chatting");
placeStage("chat");
ok(chat.kids.filter(k => k === stage).length === 1, "calling it again does not duplicate the avatar");
placeStage("home");
ok(stage.parentNode === home && home.kids[0] === stage && home.kids[1] === hero, "going Home puts the avatar back before the title");
placeStage("tools");
ok(stage.parentNode === home, "other tabs leave the avatar on Home");
const noop = new Function("$", m[0] + "; return placeStage;")(() => null);
ok((() => { try { noop("chat"); return true; } catch { return false; } })(), "missing elements never throw");
console.log(`${pass} passed, ${fail} failed (fake DOM: placement logic only; real layout NOT tested)`);
process.exit(fail ? 1 : 0);
