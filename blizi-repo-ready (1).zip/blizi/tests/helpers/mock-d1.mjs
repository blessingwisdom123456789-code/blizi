import { webcrypto } from "node:crypto";
if (!globalThis.crypto) globalThis.crypto = webcrypto;

export async function sha256(text) {
  const bytes = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return Array.from(new Uint8Array(bytes), b => b.toString(16).padStart(2, "0")).join("");
}

export function mockD1() {
  const sessions = new Map(), rateLimits = new Map(), userData = new Map();
  const db = {
    sessions, rateLimits, userData,
    prepare(sql) {
      return {
        args: [],
        bind(...args) { this.args = args; return this; },
        async first() {
          const a = this.args;
          if (sql.includes("INSERT INTO rate_limits")) {
            const [key, start] = a, old = rateLimits.get(key);
            const count = old && old.window_start === start ? old.count + 1 : 1;
            rateLimits.set(key, { window_start: start, count });
            return { count };
          }
          if (sql.startsWith("SELECT user_id, expires_at FROM sessions")) {
            const row = sessions.get(a[0]);
            return row && row.expires_at > a[1] ? { user_id: row.user_id, expires_at: row.expires_at } : null;
          }
          if (sql.startsWith("SELECT payload_ciphertext, updated_at FROM user_data")) return userData.get(a[0]) || null;
          throw new Error("Unhandled mock D1 first(): " + sql);
        },
        async run() {
          const a = this.args;
          if (sql.startsWith("INSERT INTO sessions")) {
            sessions.set(a[0], { user_id: a[1], created_at: a[2], expires_at: a[3] });
            return { success: true };
          }
          if (sql.startsWith("DELETE FROM rate_limits WHERE window_start")) {
            for (const [key, row] of rateLimits) if (row.window_start < a[0]) rateLimits.delete(key);
            return { success: true };
          }
          if (sql.startsWith("DELETE FROM sessions WHERE expires_at")) {
            for (const [key, row] of sessions) if (row.expires_at < a[0]) sessions.delete(key);
            return { success: true };
          }
          if (sql.startsWith("DELETE FROM sessions WHERE token_hash")) { sessions.delete(a[0]); return { success: true }; }
          if (sql.startsWith("INSERT INTO user_data")) {
            userData.set(a[0], { payload_ciphertext: a[1], updated_at: a[2] });
            return { success: true };
          }
          if (sql.startsWith("DELETE FROM user_data")) { userData.delete(a[0]); return { success: true }; }
          throw new Error("Unhandled mock D1 run(): " + sql);
        }
      };
    }
  };
  return db;
}
