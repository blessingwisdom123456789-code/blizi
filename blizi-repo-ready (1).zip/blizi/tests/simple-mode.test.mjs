import worker from "../backend/worker.js";
let pass = 0, fail = 0;
const ok = (c, n) => { c ? pass++ : (fail++, console.log("FAIL:", n)); if (c) console.log("ok  :", n); };
const FAKE = "DUMMY-SIMPLE-MODE-KEY";
let hits = 0;
globalThis.fetch = async (url, init) => { hits++; return new Response(JSON.stringify({ candidates: [{ content: { parts: [{ text: "[happy] simple ok" }] }, finishReason: "STOP" }] }), { status: 200 }); };
const base = { BLIZI_MODE: "simple", GEMINI_API_KEY: FAKE, GEMINI_MODEL_FAST: "m", ALLOWED_ORIGINS: "https://site.test" };
const good = JSON.stringify({ messages: [{ role: "user", content: "hi" }], system: "s", tier: "fast" });
const post = (env, o = "https://site.test", ip = "1.1.1.1", path = "/chat", body = good) => worker.fetch(new Request("https://w.test" + path, { method: "POST", headers: { "Content-Type": "application/json", ...(o ? { Origin: o } : {}), "CF-Connecting-IP": ip }, body }), env);
let r = await post(base), j = await r.json();
ok(r.status === 200 && j.text === "[happy] simple ok", "simple mode: chat works with NO D1, NO password, NO sessions");
ok(!JSON.stringify(j).includes(FAKE) && !JSON.stringify([...r.headers]).includes(FAKE), "key not in response");
r = await post(base, "https://evil.test"); await r.json(); ok(r.status === 403, "simple mode: disallowed origin rejected");
const before = hits; r = await post(base, null); await r.json(); ok(r.status === 403 && hits === before, "simple mode: POST without Origin rejected before provider call");
r = await post(base, "https://site.test", "1.1.1.1", "/memory"); j = await r.json(); ok(r.status === 404 && j.error === "not_available_in_simple_mode", "/memory unavailable in simple mode");
r = await post(base, "https://site.test", "1.1.1.1", "/auth/login", "{}"); await r.json(); ok(r.status === 404, "/auth/login unavailable in simple mode");
r = await post(base, "https://site.test", "1.1.1.1", "/chat", "{bad"); await r.json(); ok(r.status === 400, "invalid JSON -> 400");
r = await post(base, "https://site.test", "1.1.1.1", "/chat", JSON.stringify({ messages: [{ role: "system", content: "x" }] })); await r.json(); ok(r.status === 400, "role injection -> 400");
const noOrigins = { ...base }; delete noOrigins.ALLOWED_ORIGINS; r = await post(noOrigins); await r.json(); ok(r.status === 403 || r.status === 503, "no ALLOWED_ORIGINS -> refuses");
// rate limit: 20/min per IP, other IPs unaffected
let last = 0; for (let i = 0; i < 22; i++) { const x = await post(base, "https://site.test", "9.9.9.9"); last = x.status; await x.json(); }
ok(last === 429, "in-memory limiter returns 429 after 20 requests/min from one IP");
r = await post(base, "https://site.test", "8.8.8.8"); await r.json(); ok(r.status === 200, "a different IP is not throttled");
// secure mode must NOT be weakened
const secure = { GEMINI_API_KEY: FAKE, GEMINI_MODEL_FAST: "m", ALLOWED_ORIGINS: "https://site.test" };
r = await post(secure); await r.json(); ok(r.status === 503, "no BLIZI_MODE and no D1/secrets -> 503 (not open)");
for (const v of ["Simple", "true", "1", " simple", "simple "]) { r = await post({ ...secure, BLIZI_MODE: v }); await r.json(); ok(r.status === 503, `BLIZI_MODE=${JSON.stringify(v)} does not enable simple mode`); }
console.log(`\n${pass} passed, ${fail} failed (ALL MOCK; no real provider contacted)`);
if (fail) process.exit(1);
