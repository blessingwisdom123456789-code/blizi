import worker from "../backend/worker.js";
let pass = 0, fail = 0;
const ok = (c, n) => { c ? pass++ : (fail++, console.log("FAIL:", n)); if (c) console.log("ok  :", n); };
const KEY = "DUMMY-TTS-KEY-0000";
let mode = "ok", last = null, hits = 0;
const b64 = n => Buffer.from(new Uint8Array(n).fill(1)).toString("base64");
globalThis.fetch = async (url, init) => {
  hits++; last = { url: String(url), headers: init.headers, body: JSON.parse(init.body) };
  const R = (s, b) => new Response(typeof b === "string" ? b : JSON.stringify(b), { status: s });
  const audio = (rate, data) => R(200, { candidates: [{ content: { parts: [{ inlineData: { mimeType: `audio/L16;codec=pcm;rate=${rate}`, data } }] } }] });
  switch (mode) {
    case "rate16": return audio(16000, b64(200));
    case "429": return R(429, { error: { message: "quota" } });
    case "badkey": return R(400, { error: { message: "API key not valid" } });
    case "403": return R(403, {}); case "404": return R(404, {}); case "500": return R(500, "x");
    case "noaudio": return R(200, { candidates: [{ content: { parts: [{ text: "no audio" }] } }] });
    case "blocked": return R(200, { promptFeedback: { blockReason: "SAFETY" } });
    case "badb64": return audio(24000, "not base64 !!!");
    case "down": throw new TypeError("net");
    default: return audio(24000, b64(200));
  }
};
const env = { BLIZI_MODE: "simple", GEMINI_API_KEY: KEY, GEMINI_MODEL_FAST: "chat-m", GEMINI_TTS_MODEL: "tts-m", GEMINI_TTS_VOICE: "Kore", ALLOWED_ORIGINS: "https://site.test" };
const call = (e, body, o = {}) => worker.fetch(new Request("https://w.test/tts", { method: o.method || "POST", headers: { ...(o.noCT ? {} : { "Content-Type": "application/json" }), ...(o.origin === null ? {} : { Origin: o.origin || "https://site.test" }), "CF-Connecting-IP": o.ip || "1.1.1.1" }, body: o.method === "GET" ? undefined : (typeof body === "string" ? body : JSON.stringify(body)) }), e);
let r = await call(env, { text: "Hello there" }), j = await r.json();
ok(r.status === 200 && j.format === "pcm16" && j.sampleRate === 24000 && typeof j.audio === "string" && j.audio.length > 8, "TTS success returns pcm16 audio + sample rate");
ok(last.url === "https://generativelanguage.googleapis.com/v1beta/models/tts-m:generateContent" && last.headers["x-goog-api-key"] === KEY && !last.url.includes(KEY), "uses the configured TTS model; key only in a header");
ok(JSON.stringify(last.body.generationConfig.responseModalities) === '["AUDIO"]' && last.body.generationConfig.speechConfig.voiceConfig.prebuiltVoiceConfig.voiceName === "Kore" && last.body.contents[0].parts[0].text === "Hello there", "request asks for AUDIO with the configured voice and the text");
ok(!JSON.stringify(j).includes(KEY), "key not in response");
mode = "rate16"; r = await call(env, { text: "x" }, { ip: "2.2.2.2" }); j = await r.json(); ok(j.sampleRate === 16000, "sample rate parsed from the provider mime type"); mode = "ok";
let e2 = { ...env, GEMINI_TTS_VOICE: "Kore;drop" }; r = await call(e2, { text: "x" }, { ip: "3.3.3.3" }); await r.json(); ok(!("speechConfig" in last.body.generationConfig), "unsafe voice setting is ignored");
e2 = { ...env }; delete e2.GEMINI_TTS_MODEL; r = await call(e2, { text: "x" }, { ip: "4.4.4.4" }); j = await r.json(); ok(r.status === 503 && j.error === "tts_not_configured", "no TTS model -> 503 not configured");
e2 = { ...env, GEMINI_TTS_MODEL: "../evil?x" }; r = await call(e2, { text: "x" }, { ip: "4.4.4.5" }); await r.json(); ok(r.status === 503, "unsafe TTS model id rejected");
for (const [b, n] of [[{}, "missing text"], [{ text: "   " }, "blank text"], [{ text: 5 }, "non-string text"], [{ text: "a".repeat(501) }, "501 chars"], ["{bad", "bad JSON"]]) { r = await call(env, b, { ip: "5.5.5." + n.length }); j = await r.json(); ok(r.status === 400 && j.error === "invalid_text", "rejects " + n); }
r = await call(env, { text: "x" }, { noCT: true, ip: "6.6.6.6" }); await r.json(); ok(r.status === 415, "wrong content type -> 415");
r = await call(env, null, { method: "GET", ip: "6.6.6.7" }); await r.json(); ok(r.status === 405, "GET -> 405");
const before = hits; r = await call(env, { text: "x" }, { origin: "https://evil.test", ip: "7.7.7.7" }); await r.json(); ok(r.status === 403 && hits === before, "disallowed origin rejected before the provider is called");
r = await call(env, { text: "x" }, { origin: null, ip: "7.7.7.8" }); await r.json(); ok(r.status === 403 && hits === before, "no Origin rejected");
for (const [m, st, er] of [["429", 429, "provider_rate_limited"], ["badkey", 502, "provider_auth_failed"], ["403", 502, "provider_auth_failed"], ["404", 502, "provider_model_not_found"], ["500", 502, "provider_error"], ["noaudio", 502, "provider_bad_response"], ["blocked", 502, "provider_blocked"], ["badb64", 502, "provider_bad_response"], ["down", 504, "provider_unreachable"]]) {
  mode = m; r = await call(env, { text: "x" }, { ip: "8.8.8." + st + m.length }); j = await r.json(); const t = JSON.stringify(j);
  ok(r.status === st && j.error === er, `provider ${m} -> ${st} ${er}`); ok(!t.includes(KEY) && !t.includes("quota") && !t.includes("API key not valid"), `no key/provider text leaked on ${m}`); }
mode = "ok"; let last2 = 0; for (let i = 0; i < 12; i++) { const x = await call(env, { text: "x" }, { ip: "9.9.9.9" }); last2 = x.status; await x.json(); }
ok(last2 === 429, "TTS limiter: 429 after 10 requests/min from one IP");
r = await call(env, { text: "x" }, { ip: "9.9.9.10" }); await r.json(); ok(r.status === 200, "other IPs unaffected");
console.log(`\n${pass} passed, ${fail} failed (ALL MOCK; no real Gemini TTS request was made)`);
process.exit(fail ? 1 : 0);
