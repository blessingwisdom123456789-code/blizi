import fs from "node:fs";
import assert from "node:assert/strict";

const root = { structuredClone: globalThis.structuredClone };
for (const file of ["core-schema.js", "core-store.js", "core-events.js", "core-seed.js", "core-migrations.js", "core-state.js"]) {
  const source = fs.readFileSync(new URL(`../frontend/core/${file}`, import.meta.url), "utf8");
  new Function("window", source)(root);
}
const SC = root.BliziCoreSchema;
const Store = root.BliziCoreStore;
let pass = 0;
const ok = (condition, label) => { assert.ok(condition, label); pass++; console.log("ok  :", label); };
const rejectsCode = async (promise, code, label) => {
  await assert.rejects(promise, error => error && error.code === code, label);
  pass++;
  console.log("ok  :", label);
};
const now = () => Date.parse("2026-01-01T00:00:00.000Z");

// Registry, opaque envelope, prefixed ULID-style identifiers and profile guards.
ok(SC.PROFILE_ID === "prof_main" && SC.DATABASE_VERSION === 1, "v1 is pinned to prof_main and schema-neutral database version 1");
ok(["identity", "mood", "relationship", "episodes", "facts", "corrections", "projects", "journal", "proposals", "versions", "migrations", "transcripts", "snapshots", "eventlog"].every(name => SC.STORE_NAMES.includes(name)), "registry contains the planned profile stores and event log");
const id = SC.makeId("identity", { now: now(), random: () => 0.5 });
ok(/^ide_[0-9A-HJKMNP-TV-Z]{26}$/.test(id), "ID helper generates a prefixed, sortable 26-character Crockford token");
const record = SC.createEnvelope("identity", { label: "Blizi" }, { now: now(), id: "idn_main" });
ok(record.id === "idn_main" && record.profileId === "prof_main" && record.createdAt === "2026-01-01T00:00:00.000Z", "generic envelope supplies id, active profile, and timestamps");
assert.throws(() => SC.createEnvelope("identity", { id: "other", profileId: "prof_other" }), { code: "profile_mismatch" });
assert.throws(() => SC.createEnvelope("identity", { sensitivity: "sensitive" }), { code: "sensitive_disabled" });
assert.throws(() => SC.createEnvelope("identity", { sensitive: true }), { code: "sensitive_disabled" });
pass += 3;
console.log("ok  : wrong-profile and sensitive-memory records are rejected at schema boundary");

// Memory adapter: deep copies, scoped transactions, read-only enforcement, rollback and profile filtering.
const memory = new Store.MemoryAdapter({ profileId: "prof_main" });
await memory.open();
const first = SC.createEnvelope("identity", { label: "Blizi" }, { id: "idn_main", now: now() });
await memory.put("identity", first);
first.label = "mutated outside";
const loaded = await memory.get("identity", "idn_main");
ok(loaded.label === "Blizi", "adapter clones records on write and read");
await rejectsCode(memory.transaction(["identity"], "readonly", tx => tx.put("identity", first)), "readonly_transaction", "readonly transactions cannot write");
await rejectsCode(memory.transaction(["identity"], "readonly", tx => tx.get("mood", "x")), "store_not_in_transaction", "transaction scope rejects an undeclared store");
await rejectsCode(memory.transaction(["identity"], "readwrite", async tx => { await tx.put("identity", SC.createEnvelope("identity", { label: "rollback" }, { id: "rollback", now: now() })); throw new Error("abort"); }), undefined, "memory transaction rolls back when its callback rejects");

await memory.put("eventlog", { seq: 1, profileId: "prof_main", op: "import" });
await memory.put("eventlog", { seq: 7, profileId: "prof_main", op: "import" });
const nextEvent = await memory.add("eventlog", { profileId: "prof_main", op: "update" });
ok(nextEvent.seq === 8, "event sequence remains monotonic after restoring/importing existing rows");
memory._data.identity.push({ id: "other-profile", profileId: "prof_other", label: "injected test row" });
ok((await memory.getAll("identity")).every(row => row.profileId === "prof_main"), "profile-scoped reads hide records from every other profile");
ok(memory.tx === memory.transaction, "tx is a backward-compatible alias for transaction");

// localStorage adapter persists atomically and enforces its configured bounded fallback.
const backing = Object.create(null);
const fakeStorage = { getItem: key => Object.prototype.hasOwnProperty.call(backing, key) ? backing[key] : null, setItem: (key, value) => { backing[key] = String(value); } };
const local = new Store.LocalStorageAdapter(fakeStorage, { key: "test.core", profileId: "prof_main" });
await local.open();
await local.put("identity", SC.createEnvelope("identity", { label: "Local" }, { id: "local-id", now: now() }));
const localReloaded = new Store.LocalStorageAdapter(fakeStorage, { key: "test.core", profileId: "prof_main" });
await localReloaded.open();
ok((await localReloaded.get("identity", "local-id")).label === "Local", "localStorage adapter reopens persisted profile data");
await assert.rejects(local.transaction(["identity"], "readwrite", async tx => { await tx.put("identity", SC.createEnvelope("identity", { label: "not committed" }, { id: "rollback-local", now: now() })); throw new Error("abort"); }));
ok(await local.get("identity", "rollback-local") === undefined, "localStorage adapter commits only after its transaction callback succeeds");
const capped = new Store.LocalStorageAdapter(fakeStorage, { key: "tiny.core", maxBytes: 65536 });
await capped.open();
await rejectsCode(capped.put("identity", SC.createEnvelope("identity", { content: "x".repeat(70000) }, { id: "too-large", now: now() })), "quota_exceeded", "localStorage fallback enforces its byte limit without corrupting prior data");

// IndexedDB selection and option propagation are testable without opening a database.
const idbStub = { open() {} };
const browserAdapter = Store.createBrowserAdapter({ indexedDB: idbStub, localStorage: fakeStorage, profileId: "prof_main" });
ok(browserAdapter.kind === "indexedDB" && browserAdapter.profileId === "prof_main", "browser adapter prefers IndexedDB and propagates the profile id");
const fallbackAdapter = Store.createBrowserAdapter({ indexedDB: null, localStorage: fakeStorage, profileId: "prof_main" });
ok(fallbackAdapter.kind === "localStorage" && fallbackAdapter.profileId === "prof_main", "browser adapter falls back to bounded localStorage with the same profile");

// Event records and their target mutations commit together; delete events never retain patches.
const eventStore = new Store.MemoryAdapter();
await eventStore.open();
const events = root.BliziCoreEvents.create(eventStore, { now });
const identity = SC.createEnvelope("identity", { label: "Blizi" }, { id: "idn-event", now: now() });
await events.mutate({ store: "identity", op: "create", actor: "user", id: identity.id, record: identity, patch: { fields: ["label"], state: "active" } });
const afterCreate = await events.list();
ok((await eventStore.get("identity", identity.id)).label === "Blizi" && afterCreate.length === 1 && afterCreate[0].seq === 1, "record create and metadata event append atomically with a sequence");
await events.mutate({ store: "identity", op: "delete", actor: "user", id: identity.id, patch: { source: "user" } });
const afterDelete = await events.list();
ok(!(await eventStore.get("identity", identity.id)) && afterDelete.length === 2 && afterDelete[1].seq === 2 && !Object.hasOwn(afterDelete[1], "patch"), "delete is atomic and its event contains no record-content patch");
await rejectsCode(Promise.resolve().then(() => root.BliziCoreEvents.cleanEvent({ store: "identity", op: "update", id: "x", patch: { content: "private text" } })), "invalid_event_patch", "event log rejects arbitrary content fields in patches");
await rejectsCode(events.mutate({ store: "identity", op: "create", actor: "user", id: "mismatch", record: identity }), "event_record_id_mismatch", "failed target mutation creates no partial event");
ok((await events.list()).length === 2, "failed event transaction leaves the event log unchanged");

// Core facade stages raw legacy values without deleting or remapping them.
const legacy = Object.create(null);
legacy["blizi.settings"] = JSON.stringify({ name: "Legacy Name", persona: "friendly" });
legacy["blizi.settings.manus.v1"] = JSON.stringify({ voice: "browser", speak: true });
legacy["blizi.notes"] = "buy milk";
legacy["blizi.convs"] = JSON.stringify({ cur: "c1", list: [{ id: "c1", msgs: [{ who: "user", text: "hello" }] }] });
const legacyStorage = { getItem: key => Object.prototype.hasOwnProperty.call(legacy, key) ? legacy[key] : null, setItem: (key, value) => { legacy[key] = String(value); }, removeItem: key => { delete legacy[key]; } };
const stateAdapter = new Store.MemoryAdapter();
let mode = "off";
const core = root.BliziCore.create({ adapter: stateAdapter, localStorage: legacyStorage, getMode: () => mode, now });
const opened = await core.open();
ok(opened.ok && opened.profileId === "prof_main" && opened.mode === "off" && core.mode() === "off", "facade opens asynchronously with the default-off mode and fixed profile");
ok(core.seed().identityId === "idn_main" && core.seed().canonicalSchemaApplied === undefined, "identity seed is a manifest, not a premature canonical record");
const originalSettings = legacy["blizi.settings"], originalNotes = legacy["blizi.notes"], originalConvs = legacy["blizi.convs"];
const staged = await stateAdapter.get("migrations", "mig_localstorage_v1");
ok(staged && staged.state === "staged" && staged.schemaMapped === false && staged.payload.keys["blizi.convs"] === originalConvs && staged.payload.keys["blizi.notes"] === originalNotes, "migration stores an unmapped raw snapshot while preserving source values");
ok(staged.payload.identitySeedCandidate.candidateValues.userCalledBy === "Legacy Name", "seed exposes only an explicit candidate projection for later schema review");
const unchanged = await core.migrations().refreshLegacySnapshot(legacyStorage);
ok(unchanged.status === "unchanged" && unchanged.revision === 1, "re-running the same legacy migration is idempotent");
legacy["blizi.settings"] = JSON.stringify({ name: "Updated Name" });
const refreshed = await core.migrations().refreshLegacySnapshot(legacyStorage);
ok(refreshed.status === "refreshed" && refreshed.revision === 2 && legacy["blizi.settings"] !== originalSettings, "changed legacy data is staged as a new revision without deleting its source");
mode = "shadow";
ok(core.mode() === "shadow", "facade reflects an explicitly supplied runtime mode");
mode = "on";
ok(core.mode() === "on", "facade supports the reserved on mode without implementing memory retrieval");
mode = "off";

// Export/import and snapshot restoration are profile-validated and repeatable.
const stateIdentity = SC.createEnvelope("identity", { label: "Original" }, { id: "idn-main", now: now() });
await core.events().mutate({ store: "identity", op: "create", actor: "user", id: stateIdentity.id, record: stateIdentity });
const bundle = await core.export({ now });
ok(bundle.format === "blizi-core-foundation-bundle" && bundle.profileId === "prof_main" && bundle.stores.identity.length === 1 && !Object.hasOwn(bundle.stores, "snapshots"), "export returns a versioned profile bundle and omits snapshots by default");
await assert.rejects(core.import({ ...bundle, profileId: "prof_other" }), { code: "invalid_bundle" });
const sensitiveBundle = { ...bundle, stores: { identity: [{ id: "private", profileId: "prof_main", sensitive: true }] } };
await assert.rejects(core.import(sensitiveBundle), { code: "sensitive_disabled" });
pass += 2;
console.log("ok  : import rejects wrong profiles and sensitive records");
const snapshot = await core.snapshot("test");
const secondIdentity = SC.createEnvelope("identity", { label: "Later" }, { id: "idn-later", now: now() });
await core.events().mutate({ store: "identity", op: "create", actor: "user", id: secondIdentity.id, record: secondIdentity });
await core.restore(snapshot.id);
ok((await stateAdapter.getAll("identity")).length === 1 && (await stateAdapter.get("identity", "idn-main")).label === "Original", "restore replaces profile data with the selected snapshot");
ok(!!(await stateAdapter.get("snapshots", snapshot.id)), "restore retains its snapshot for repeatable recovery");
const restoredEventCount = (await core.events().list()).length;
await core.restore(snapshot.id);
ok((await core.events().list()).length === restoredEventCount, "repeat restore restores the event log atomically with profile records");
await core.clearProfile();
ok((await stateAdapter.getAll("identity")).length === 0 && (await stateAdapter.getAll("migrations")).length === 0, "profile clear removes active profile records and staged migration data");
ok(legacy["blizi.settings"] && legacy["blizi.notes"] === originalNotes && legacy["blizi.convs"] === originalConvs, "Core State clear leaves unrelated legacy source keys unchanged");
console.log(`\n${pass} passed, 0 failed (Core State foundation; in-memory/fake localStorage adapters; no browser IndexedDB run)`);
