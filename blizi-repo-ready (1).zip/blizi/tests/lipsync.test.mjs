import fs from "node:fs";
let pass = 0, fail = 0;
const ok = (c, n) => { c ? pass++ : (fail++, console.log("FAIL:", n)); if (c) console.log("ok  :", n); };
const html = fs.readFileSync(new URL("../frontend/index.html", import.meta.url), "utf8");
const LS = new Function("atob", html.slice(html.indexOf("/* lipsync */"), html.indexOf("/* /lipsync */")) + ";return LipSync")(globalThis.atob);
const toB64 = f32 => { const b = Buffer.alloc(f32.length * 2); f32.forEach((v, i) => b.writeInt16LE(Math.round(Math.max(-1, Math.min(1, v)) * 32767), 2 * i)); return b.toString("base64"); };
const rate = 24000, sec = (n) => Math.floor(rate * n);
// synthetic "speech": 0.3s silence, 0.4s loud tone, 0.3s quiet tone, 0.3s silence
const sig = new Float32Array(sec(1.3)); for (let i = 0; i < sig.length; i++) { const t = i / rate, a = t < .3 ? 0 : t < .7 ? .8 : t < 1.0 ? .25 : 0; sig[i] = a * Math.sin(2 * Math.PI * 220 * t); }
const pcm = LS.b64ToPcm(toB64(sig));
ok(pcm.length === sig.length && Math.abs(pcm[sec(.5)] - sig[sec(.5)]) < 1e-3, "base64 16-bit PCM decodes to the original samples (incl. negatives)");
const env = LS.envelope(pcm, rate, LS.FPS);
ok(env.length === Math.ceil(sig.length / Math.round(rate / LS.FPS)), "one envelope value per frame");
const at = s => LS.levelAt(env, LS.FPS, s);
ok(at(.1) === 0 && at(1.2) < .02, "silence keeps the mouth closed (noise gate; release eases to ~0)");
ok(at(.5) > .8, "loud speech opens the mouth wide");
ok(at(.85) > .05 && at(.85) < at(.5), "quieter speech opens it less");
ok(at(.3 + .02) < at(.5) && at(.35) > at(.3 - .02), "mouth opens just after speech starts (attack)");
ok(at(.72) > at(.69 + .2) || at(.8) < at(.5), "mouth eases down after loud speech (release smoothing)");
ok(at(-1) === 0 && at(99) === 0 && LS.levelAt(null, LS.FPS, 1) === 0 && LS.levelAt(env, LS.FPS, NaN) === 0, "out-of-range / invalid times return 0");
ok(Array.from(env).every(v => v >= 0 && v <= 1), "levels stay within 0..1");
const mono = LS.envelope(new Float32Array(sec(.5)), rate, LS.FPS); ok(Array.from(mono).every(v => v === 0), "all-zero audio never moves the mouth");
console.log(`\n${pass} passed, ${fail} failed (synthetic audio; real Gemini speech not tested)`);
process.exit(fail ? 1 : 0);
