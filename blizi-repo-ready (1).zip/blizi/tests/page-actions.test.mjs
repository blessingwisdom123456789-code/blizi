import fs from "node:fs";
import assert from "node:assert/strict";

const load = (f) => { const root = {}; new Function("window", fs.readFileSync(new URL("../frontend/tools/" + f, import.meta.url), "utf8"))(root); return root; };
const R = load("reminders.js").BliziReminders, D = load("todos.js").BliziTodos, A = load("page-actions.js").BliziActions;
let passed = 0;
const ok = (name, fn) => { fn(); passed++; console.log("ok  : " + name); };
const at = (y, mo, d, h, mi = 0) => new Date(y, mo - 1, d, h, mi, 0).getTime();

function rig(start = at(2026, 11, 23, 10, 0)) {
  const o = { t: start, db: {}, said: [], notes: [], beeps: 0 };
  o.a = A.create({ R, D, now: () => o.t, load: (k) => (k in o.db ? JSON.parse(o.db[k]) : null), save: (k, v) => { o.db[k] = JSON.stringify(v); },
    say: (x) => o.said.push(x), notify: (t, b) => o.notes.push([t, b]), beep: () => { o.beeps++; } });
  return o;
}

ok("ordinary sentences are never hijacked", () => {
  const o = rig();
  for (const s of ["hello", "I forgot to remind my sister about the party", "what is a reminder?", "tell me about my todo habits", "can you tell me a joke", "I have 3 tasks at work today", "reminders are annoying", "remember that I like tea", ""]) assert.equal(o.a.handle(s), null, s);
  assert.equal(o.a._rem.list().length, 0); assert.equal(o.a._todo.list().length, 0);
});
ok("set a reminder with stacked polite prefixes", () => {
  const o = rig();
  const r = o.a.handle("Hey Blizi, can you remind me to call mum in 10 minutes");
  assert.ok(r.reply.includes("call mum") && r.reply.includes("10:10 AM")); assert.equal(r.askNotify, true);
  assert.equal(o.a._rem.list().length, 1);
});
ok("a reminder with no usable time asks when instead of failing silently", () => {
  const o = rig(); const r = o.a.handle("remind me to buy milk");
  assert.ok(/When should I remind you/.test(r.reply)); assert.equal(r.askNotify, undefined); assert.equal(o.a._rem.list().length, 0);
});
ok("tomorrow reminders say tomorrow", () => {
  const o = rig(); assert.ok(o.a.handle("remind me tomorrow at 8 to run").reply.includes("tomorrow 8:00 AM"));
});
ok("list and cancel reminders by number", () => {
  const o = rig(); o.a.handle("remind me in 5 minutes to a"); o.a.handle("remind me in 2 hours to b");
  const l = o.a.handle("my reminders").reply; assert.ok(l.includes("1. a") && l.includes("2. b"));
  assert.ok(o.a.handle("cancel reminder 1").reply.startsWith("Cancelled: a"));
  assert.ok(o.a.handle("cancel reminder 9").reply.includes("couldn’t find"));
  assert.equal(o.a.handle("what are my reminders?").reply.includes("1. b"), true);
});
ok("tick fires due reminders once with say, notify and beep; catch-up is flagged", () => {
  const o = rig(); o.a.handle("remind me in 1 minute to stretch");
  assert.equal(o.a.tick(), 0); o.t += 61000;
  assert.equal(o.a.tick(), 1); assert.equal(o.said[0], "⏰ stretch"); assert.deepEqual(o.notes[0], ["Blizi reminder", "stretch"]); assert.equal(o.beeps, 1);
  assert.equal(o.a.tick(), 0);
  o.a.handle("remind me in 5 minutes to eat"); o.t += 3 * 3600000; o.a.tick();
  assert.ok(o.said[1].includes("came due while you were away"));
});
ok("reminders survive a reload (storage round trip)", () => {
  const o = rig(); o.a.handle("remind me in 30 minutes to call");
  const o2 = rig(); o2.db = o.db; o2.t = o.t + 31 * 60000;
  assert.equal(o2.a.tick(), 1); assert.equal(o2.said[0].includes("call"), true);
});
ok("todos: add, list, done, delete by number", () => {
  const o = rig();
  assert.ok(o.a.handle("add todo buy milk").reply.includes("buy milk"));
  o.a.handle("todo: call dad"); o.a.handle("new task to book flights");
  const l = o.a.handle("show my todos").reply; assert.ok(l.includes("1. buy milk") && l.includes("3. book flights"));
  assert.ok(o.a.handle("done todo 1").reply.includes("marked done: buy milk"));
  assert.ok(o.a.handle("delete task 1").reply.includes("Removed: call dad"));
  assert.equal(o.a.handle("done todo 7").reply.includes("couldn’t find"), true);
  assert.equal(o.a.handle("my tasks").reply.includes("1. book flights"), true);
});
ok("failing storage and speech never break the tick", () => {
  const o = rig(); o.a.handle("remind me in 1 minute to x");
  const bad = A.create({ R, D, now: () => o.t + 120000, load: () => { throw new Error("x"); }, save: () => { throw new Error("y"); }, say: () => { throw new Error("z"); }, notify: () => { throw new Error("n"); }, beep: () => { throw new Error("b"); } });
  assert.equal(bad.tick(), 0); assert.equal(bad.handle("my reminders").reply, "You have no reminders set.");
});

console.log(`\n${passed} page action tests passed`);
