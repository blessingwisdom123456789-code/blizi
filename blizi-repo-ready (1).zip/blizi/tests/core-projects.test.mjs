import fs from "node:fs";
import assert from "node:assert/strict";

const root = { structuredClone: globalThis.structuredClone };
for (const file of ["core-schema.js", "core-store.js", "core-events.js", "projects.js"]) {
  new Function("window", fs.readFileSync(new URL(`../frontend/core/${file}`, import.meta.url), "utf8"))(root);
}
let now = Date.parse("2026-03-01T10:00:00Z");
const adapter = new root.BliziCoreStore.MemoryAdapter({ profileId: "prof_main" });
await adapter.open();
const events = root.BliziCoreEvents.create(adapter, { profileId: "prof_main", now: () => now });
const moodCauses = [];
const projects = root.BliziProjects.create({
  adapter, events, profileId: "prof_main", now: () => now,
  mood: { addCause: async cause => moodCauses.push(cause) },
  episodes: {}, relationship: {}
});
await projects.open();
const seed = await projects.get("proj_blizi");
assert.equal(seed.profileId, "prof_main");
assert.equal(seed.status, "active");
const project = await projects.create({ title: "Continuity Lab", aliases: ["continuity"], keywords: ["ledger", "companion"] });
assert.equal(project.status, "active");
await projects.update(project.id, { description: "Build the continuous self", goals: [{ id: "goal_1", title: "Ship the ledger" }], roadmap: [{ phaseId: "e", title: "Project Ledger", status: "active" }] });
const decision = await projects.addDecision(project.id, { title: "Local-first storage", decision: "Keep the ledger on-device", reasons: ["Privacy", "Offline support"], alternatives: ["Remote-only"], scope: ["storage"], revisitIf: "Security requirements change" });
assert.equal(decision.conflicts.length, 0);
const conflict = await projects.addDecision(project.id, { title: "Remote storage", decision: "Move the ledger to a hosted service", reasons: ["Sync"], scope: ["storage"] });
assert.equal(conflict.conflicts.length, 1);
assert.equal(conflict.decision.status, "conflicted");
await assert.rejects(() => projects.addDecision(project.id, { title: "Missing rationale", decision: "No reason", scope: ["x"] }), error => error.code === "decision_reasons_required");
const issue = await projects.addIssue(project.id, { title: "Review export format", description: "Check the bundle", severity: "high", refs: [{ label: "schema", path: "docs/schema.md" }] });
assert.equal(issue.status, "open");
const resolved = await projects.resolveIssue(project.id, issue.id, "Bundle format is already versioned");
assert.equal(resolved.status, "resolved");
const milestone = await projects.completeMilestone(project.id, { title: "Ledger foundation", phaseId: "e", evidence: [{ label: "tests", path: "tests/core-projects.test.mjs" }] });
assert.equal(milestone.status, "complete");
assert.equal((await projects.get(project.id)).roadmap[0].status, "complete");
assert.equal(moodCauses.length, 1);
assert.equal((await projects.detect("continuity ledger work")).length >= 1, true);
assert.equal((await projects.detect("Continuity Lab"))[0].confidence, 1);
const rendered = await projects.render(project.id, { maxChars: 240 });
assert.ok(rendered.length <= 240);
assert.match(rendered, /Continuity Lab/);
assert.equal(projects.dependencies.episodes, true);
assert.equal(projects.dependencies.relationship, true);
const listed = await projects.list({ status: "active" });
assert.equal(listed.length, 2);
const projectEvents = (await events.list()).filter(event => event.store === "projects");
assert.ok(projectEvents.length >= 7);
console.log("20 passed, 0 failed (Core State project ledger, decisions, rationale, conflicts, issues, milestones, detection, rendering, event log, and dependencies)");
