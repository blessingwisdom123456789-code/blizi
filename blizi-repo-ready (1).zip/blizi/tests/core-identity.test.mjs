import fs from "node:fs";
import assert from "node:assert/strict";
import { webcrypto } from "node:crypto";

const root = { structuredClone: globalThis.structuredClone, crypto: webcrypto };
for (const file of ["core-schema.js", "core-store.js", "core-events.js", "core-seed.js", "identity.js", "context-assembler.js"]) {
  const source = fs.readFileSync(new URL(`../frontend/core/${file}`, import.meta.url), "utf8");
  new Function("window", source)(root);
}
const SC = root.BliziCoreSchema;
const adapter = new root.BliziCoreStore.MemoryAdapter({ profileId: SC.PROFILE_ID });
await adapter.open();
const events = root.BliziCoreEvents.create(adapter, { profileId: SC.PROFILE_ID, now: () => Date.parse("2026-01-01T00:00:00Z") });
const identity = root.BliziIdentity.create({ adapter, events, seed: root.BliziCoreSeed.manifest(), profileId: SC.PROFILE_ID, now: () => Date.parse("2026-01-01T00:00:00Z"), crypto: webcrypto });
await identity.open();
const record = await identity.get();
assert.equal(record.id, "idn_main");
assert.equal(record.profileId, "prof_main");
assert.match(record.integrity.hardBoundariesHash, /^[0-9a-f]{64}$/);
assert.deepEqual(await identity.verifyIntegrity(), { ok: true, reason: "ok" });
record.boundaries.hard.push("tampered");
await adapter.put("identity", record);
assert.deepEqual(await identity.verifyIntegrity(), { ok: false, reason: "hard_boundaries_hash_mismatch" });
const context = root.BliziContext.create({ identity, maxChars: 2800 }).build({ base: "x".repeat(2900), maxChars: 3000 });
assert.ok(context.length <= 3000);
console.log("4 passed, 0 failed (Core State identity, integrity, and context cap)");
