// Runs the REAL page script from index.html against a stubbed browser (no layout, no real voice, no real Claude).
import fs from "node:fs";
let pass = 0, fail = 0;
const ok = (c, n) => { c ? pass++ : (fail++, console.log("FAIL:", n)); if (c) console.log("ok  :", n); };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const html = fs.readFileSync(new URL("../frontend/index.html", import.meta.url), "utf8");
const expressionMap = fs.readFileSync(new URL("../frontend/avatar/expression-map.js", import.meta.url), "utf8");
const blinkConfig = fs.readFileSync(new URL("../frontend/avatar/blink-config.js", import.meta.url), "utf8");
const blinkScheduler = fs.readFileSync(new URL("../frontend/avatar/blink-scheduler.js", import.meta.url), "utf8");
const svgRenderer = fs.readFileSync(new URL("../frontend/avatar/svg-renderer.js", import.meta.url), "utf8");
const avatarController = fs.readFileSync(new URL("../frontend/avatar/avatar-controller.js", import.meta.url), "utf8");
const proactiveLogic = fs.readFileSync(new URL("../frontend/core/proactive.js", import.meta.url), "utf8");
const expressionArbiter = fs.readFileSync(new URL("../frontend/avatar/expression-arbiter.js", import.meta.url), "utf8");
const bodyIntent = fs.readFileSync(new URL("../frontend/core/body-intent.js", import.meta.url), "utf8");
const selfModel = fs.readFileSync(new URL("../frontend/core/self-model.js", import.meta.url), "utf8");
const coreModules = ["core-schema.js", "core-store.js", "core-events.js", "core-seed.js", "core-migrations.js", "core-state.js"].map(name => fs.readFileSync(new URL(`../frontend/core/${name}`, import.meta.url), "utf8"));
const i0 = html.indexOf("<script>") + 8, js = html.slice(i0, html.indexOf("</script>", i0));

function boot({ store = {}, claude, xwin = {} } = {}) {
  const els = {}, created = [];
  const mk = (sel) => { const h = {}; const e = {
    sel, children: [], style: { setProperty() {}, removeProperty() {} }, dataset: {}, value: "", textContent: "", innerHTML: "", hidden: false, disabled: false, checked: false, className: "", scrollTop: 0, scrollHeight: 0,
    classList: { add() {}, remove() {}, toggle(c, active) { if (active) this.add(c); else this.remove(c); } },
    addEventListener(t, f) { (h[t] = h[t] || []).push(f); }, fire(t, ev) { (h[t] || []).forEach(f => f(ev || { target: e, key: "" })); },
    appendChild(c) { e.children.push(c); return c; }, remove() {}, setAttribute() {}, removeAttribute() {}, querySelector() { return mk("child"); }, focus() {}, select() {}, click() { e.onclick && e.onclick(); } };
    return e; };
  const doc = { querySelector: s => els[s] || (els[s] = mk(s)), querySelectorAll: () => [], createElement: t => { const e = mk(t); created.push(e); return e; }, documentElement: { style: { setProperty() {}, removeProperty() {} } }, body: { classList: { toggle() {}, add() {}, remove() {} }, appendChild() {} }, execCommand() { return false; } };
  const ls = { getItem: k => (k in store ? store[k] : null), setItem: (k, v) => { store[k] = String(v); }, removeItem: k => { delete store[k]; } };
  const win = Object.assign({ claude, location: { origin: "https://x.test" }, matchMedia: () => ({ matches: false }), setTimeout: () => 0, clearTimeout() {} }, xwin);
  new Function("window", expressionMap)(win);
  new Function("window", blinkConfig)(win);
  new Function("window", blinkScheduler)(win);
  new Function("window", svgRenderer)(win);
  new Function("window", avatarController)(win);
  new Function("window", expressionArbiter)(win);
  new Function("window", proactiveLogic)(win);
  new Function("window", bodyIntent)(win);
  new Function("window", selfModel)(win);
  for (const source of coreModules) new Function("window", source)(win);
  new Function("document", "window", "localStorage", "navigator", "matchMedia", js)(doc, win, ls, { language: "en-US" }, () => ({ matches: false }));
  return { els, created, store, doc, win };
}
const convs = st => JSON.parse(st["blizi.convs"] || "{}");
const msgsOf = st => { const d = convs(st); const c = (d.list || []).find(x => x.id === d.cur); return c ? c.msgs : []; };
ok(/addEventListener\("pagehide",function\(event\)\{if\(event&&event\.persisted\)return;/.test(js), "pagehide cleanup preserves a page retained by the back/forward cache");
async function say(app, text) { app.els["#inp"].value = text; app.els["#inp"].fire("input"); app.els["#send"].fire("click"); await sleep(60); }

// ---- 1. with a (fake) Claude page connection
let seen = [];
const fakeSample = async (m, o) => { seen.push(JSON.parse(JSON.stringify(m))); o.onText && o.onText({ text: "[happy] Hi, I’m Blizi!" }); return { text: seen.length === 2 ? "[thinking] You said hello." : seen.length === 3 ? "[excited] You got this!" : "[happy] Hi, I’m Blizi!" }; };
const store = { "blizi.settings.manus.v1": JSON.stringify({ provider: "page", url: "", demo: false }) };
let app = boot({ store, claude: { use: async n => n === "sample" ? fakeSample : null } });
await sleep(30);
const coreBoot = await app.win.bliziCoreReady;
ok(coreBoot.ok && coreBoot.mode === "off" && app.win.bliziCoreInstance.mode() === "off", "Core State opens in the background and remains off by default");
ok(/Claude ready/.test(app.els["#pillTx"].textContent), "status pill shows an AI connection is available");
await say(app, "hello");
let m = msgsOf(store);
ok(m.length === 2 && m[0].who === "user" && m[1].who === "bot" && m[1].ai === true, "user + AI reply saved to the conversation");
ok(m[1].text === "Hi, I’m Blizi!", "mood tag stripped from the visible reply");
ok(app.els["#blizi"].dataset.expr === "happy", "expression follows the mood tag");
ok(/You are Blizi/.test(seen[0][0].content) && /Conversation:/.test(seen[0][0].content), "personality instruction is sent with the first turn");
await say(app, "what did I just say?");
m = msgsOf(store);
ok(seen[1].length === 3 && /hello/.test(seen[1][0].content) && seen[1][1].role === "assistant" && seen[1][2].content === "what did I just say?", "second turn includes the earlier turns (context)");
ok(m.length === 4 && m[3].text === "You said hello." && app.els["#blizi"].dataset.expr === "thinking", "multi-turn reply saved; expression changed to thinking");
await say(app, "cheer me up"); m = msgsOf(store);
ok(m.length === 6 && m[5].text === "You got this!" && app.els["#blizi"].dataset.expr === "excited", "new excited mood tag is stripped and applied to the SVG state");
// ---- 1b. body request acts before the reply and remains held over a lower-priority tag
let bodySeen = [];
const bodyClaude = async (m, o) => { bodySeen.push(JSON.parse(JSON.stringify(m))); o.onText && o.onText({ text: "[happy] Okay, serious face." }); return { text: "[happy] Okay, serious face." }; };
const bodyApp = boot({ store: { "blizi.settings.manus.v1": JSON.stringify({ provider: "page", url: "", demo: false }) }, claude: { use: async n => n === "sample" ? bodyClaude : null } });
await sleep(30); await say(bodyApp, "make a serious face");
ok(bodyApp.els["#blizi"].dataset.expr === "serious", "body request applies immediately and outranks the reply tag");
ok(bodySeen[0] && bodySeen[0][0].content.length < 2000 && /Body state: face=serious/.test(bodySeen[0][0].content), "body-aware system prompt includes the current face and stays under 2000 characters");
await say(bodyApp, "I made a serious mistake today");
ok(bodyApp.els["#blizi"].dataset.expr === "serious", "ordinary serious language does not replace the held face request");
// ---- 1c. prompt: every emotion tag is offered; long saved notes can never push the body-state line out
ok(["happy", "excited", "thinking", "surprised", "serious", "sad", "angry", "confused", "embarrassed", "sleepy", "neutral"].every(n => bodySeen[0][0].content.includes("[" + n + "]")), "the prompt offers every emotion she can show, not just four");
ok(/make a face or show an emotion, use exactly that tag/.test(bodySeen[0][0].content), "the prompt tells her to use the matching tag when asked for a face");
{
  const seenNotes = [];
  const claudeNotes = async (m, o) => { seenNotes.push(JSON.parse(JSON.stringify(m))); return { text: "[happy] ok" }; };
  const withNotes = boot({ store: { "blizi.settings.manus.v1": JSON.stringify({ provider: "page", url: "", demo: false, memory: "NOTE ".repeat(200) }) }, claude: { use: async n => n === "sample" ? claudeNotes : null } });
  await sleep(30); await say(withNotes, "hello");
  const sys = seenNotes[0][0].content, sysOnly = sys.split("\n\n---\nConversation:")[0];
  ok(sysOnly.length <= 1950 && /Body state: face=/.test(sys) && /Self-model:/.test(sys), "1000-char saved notes cannot evict the body state or self-model from the prompt (cap still 1950)");
  ok(/Saved notes from the user/.test(sys) && /NOTE NOTE/.test(sys), "saved notes still reach the model, truncated to the room left");
}
// ---- 1d. speech holds the face: the reply emotion is extended while she speaks, then lingers briefly
{
  const utterances = [];
  const synth = { cancel() {}, getVoices: () => [], speak: u => { utterances.push(u); u.onstart && u.onstart(); } };
  globalThis.SpeechSynthesisUtterance = function (t) { this.text = t; }; globalThis.speechSynthesis = synth;
  const sampleSerious = async () => ({ text: "[serious] Okay. This is my serious face." });
  const sp = boot({ store: { "blizi.settings.manus.v1": JSON.stringify({ provider: "page", url: "", speak: true, voice: "browser", demo: false }) }, claude: { use: async n => n === "sample" ? sampleSerious : null }, xwin: { speechSynthesis: synth } });
  await sleep(30); await say(sp, "tell me something serious"); await sleep(80);
  const arb = sp.win.bliziExpressionArbiter, layerOf = () => arb.explain().layers.find(l => l.source === "reply-tag");
  ok(utterances.length >= 1 && layerOf() && layerOf().expiresAt - Date.now() > 100000, "while she speaks, the reply emotion is held far beyond the default 5 s");
  ok(sp.els["#blizi"].dataset.expr === "serious", "the face is still serious during speech");
  utterances.forEach(u => u.onend && u.onend()); await sleep(30);
  const left = layerOf() ? layerOf().expiresAt - Date.now() : -1;
  ok(left > 0 && left <= 3600, "when speech ends the emotion lingers about 3.5 s instead of snapping back");
  delete globalThis.speechSynthesis; delete globalThis.SpeechSynthesisUtterance;
}
// ---- 1e. tone dials reach the prompt only when changed; proactive check-ins greet once per day
{
  const seenDial = [];
  const claudeDial = async m => { seenDial.push(JSON.parse(JSON.stringify(m))); return { text: "[happy] ok" }; };
  const dial = boot({ store: { "blizi.settings.manus.v1": JSON.stringify({ provider: "page", url: "", demo: false, humor: "off", formality: "formal" }) }, claude: { use: async n => n === "sample" ? claudeDial : null } });
  await sleep(30); await say(dial, "hi");
  ok(/Do not joke/.test(seenDial[0][0].content) && /polite/.test(seenDial[0][0].content), "humor and tone dials are added to the prompt when changed");
  ok(!/Do not joke|Speak casually|Speak politely|playful humor/.test(bodySeen[0][0].content), "default dials leave the prompt unchanged");
}
{
  const RealDate = Date, FIXED = new RealDate(2026, 10, 23, 8, 0, 0).getTime();
  globalThis.Date = class extends RealDate { constructor(...a) { if (a.length) super(...a); else super(FIXED); } static now() { return FIXED; } };
  try {
    const settings = JSON.stringify({ provider: "page", url: "", demo: false, speak: false, proactive: "on", name: "Blessing" });
    const pro = boot({ store: { "blizi.settings.manus.v1": settings } });
    await sleep(2900);
    ok(/Good morning, Blessing\./.test(pro.store["blizi.convs"] || ""), "proactive: with the check-in on, she greets you by name in the morning");
    ok(JSON.parse(pro.store["blizi.proactive.v1"]).sent.morning === "2026-11-23", "proactive: the greeting is remembered for the day");
    const again = boot({ store: pro.store });
    await sleep(2900);
    ok(((again.store["blizi.convs"] || "").match(/Good morning, Blessing/g) || []).length === 1, "proactive: reopening the app the same day does not greet again");
    const off = boot({ store: { "blizi.settings.manus.v1": JSON.stringify({ provider: "page", url: "", demo: false, speak: false }) } });
    await sleep(2900);
    ok(!/Good morning/.test(off.store["blizi.convs"] || ""), "proactive: off by default, so she never speaks up unasked");
  } finally { globalThis.Date = RealDate; }
}
// ---- 2. persistence across refresh
app.els["#sName"].value = "Tester"; app.els["#sName"].fire("input", { target: app.els["#sName"] });
app.els["#notes"].value = "buy milk"; app.els["#notes"].fire("input", { target: app.els["#notes"] });
const app2 = boot({ store, claude: { use: async n => n === "sample" ? fakeSample : null } });
await sleep(30);
const shown = app2.els["#log"].children.length;
const stagedLegacy = await app2.win.bliziCoreInstance.adapter().get("migrations", "mig_localstorage_v1");
ok(shown >= 4, "after 'refresh' the saved conversation is redrawn (" + shown + " items)");
ok(JSON.parse(store["blizi.settings.manus.v1"]).name === "Tester" && store["blizi.notes"] === "buy milk", "settings and notes persisted");
ok(stagedLegacy && stagedLegacy.schemaMapped === false && stagedLegacy.payload.keys["blizi.convs"] === store["blizi.convs"] && stagedLegacy.payload.keys["blizi.notes"] === "buy milk", "legacy data is staged non-destructively without changing or interpreting the chat payload");
ok(/You are Blizi/.test(seen[0][0].content) && !/Core State|Identity seed|Legacy Name/.test(seen[0][0].content), "off mode leaves the existing instr() prompt behavior free of Core State context");
ok(app2.els["#sName"].value === "Tester" && app2.els["#notes"].value === "buy milk", "settings and notes restored into the UI");
// ---- 3. no provider: honest demo mode
const store3 = { "blizi.settings.manus.v1": JSON.stringify({ provider: "page", url: "", demo: true }) }; const app3 = boot({ store: store3 });
await sleep(30);
ok(/Demo mode/.test(app3.els["#pillTx"].textContent), "no connection -> pill says Demo mode");
await say(app3, "hello"); await sleep(700);
const m3 = msgsOf(store3);
ok(m3[1] && m3[1].demo === true && !m3[1].ai && /^Demo reply:/.test(m3[1].text), "no AI -> reply is labeled DEMO, never flagged as AI");
// ---- 4. provider error + retry
let fail1 = true; const flaky = async (m, o) => { if (fail1) { fail1 = false; throw { code: "rate_limited" }; } return { text: "[happy] back!" }; };
const store4 = { "blizi.settings.manus.v1": JSON.stringify({ provider: "page", url: "", demo: false }) }; const app4 = boot({ store: store4, claude: { use: async () => flaky } }); await sleep(30);
await say(app4, "hi");
ok(msgsOf(store4).length === 1, "failed request leaves only the user message saved (no fake reply)");
const errRow = app4.els["#log"].children.find(c => /Too many requests/.test(c.textContent || ""));
ok(!!errRow, "user sees a friendly rate-limit message");
const retry = errRow && errRow.children.find(c => c.onclick); retry && retry.onclick(); await sleep(60);
ok(msgsOf(store4).length === 2 && msgsOf(store4)[1].text === "back!", "Retry succeeds and saves the reply");
// ---- 5. stop / cancel
const hang = (m, o) => new Promise((_, rej) => o.signal.addEventListener("abort", () => rej({ code: "aborted" })));
const store5 = { "blizi.settings.manus.v1": JSON.stringify({ provider: "page", url: "", demo: false }) }; const app5 = boot({ store: store5, claude: { use: async () => hang } }); await sleep(30);
await say(app5, "long task"); app5.els["#stop"].fire("click"); await sleep(60);
ok(msgsOf(store5).length === 1 && app5.els["#send"].style.display !== "none", "Stop cancels the request and the UI recovers without saving a fake reply");
// ---- 6. offline tools
const c = app.els["#calcIn"]; c.fire("input", { target: { value: "12*(3+4)/2" } }); ok(app.els["#calcOut"].textContent === "42", "calculator: 12*(3+4)/2 = 42");
c.fire("input", { target: { value: "process.exit()" } }); ok(/numbers and/.test(app.els["#calcOut"].textContent), "calculator rejects non-math input");
app.doc.querySelector("#dtDays").value = "30"; app.els["#dtGo"].fire("click"); ok(app.doc.querySelector("#dtRes").textContent.length > 8, "date tool returns a date");
// ---- 7. cloud buttons are honest without a backend
app.els["#cloudBackup"].fire("click"); await sleep(10);
ok(/Backend URL/.test(app.els["#toast"].textContent), "cloud backup without a backend says to set a Backend URL");
// ---- 8. clear-all wipes saved data after confirmation
app.els["#sWipe"].fire("click"); app.els["#sWipe"].fire("click"); await sleep(10);
ok(!store["blizi.notes"] && !store["blizi.settings"] && !store["blizi.settings.manus.v1"], "delete-all removes notes and both settings namespaces");
// ---- 9. 3D body is opt-in and falls back to 2D when WebGL is unavailable (stub has no WebGL)
{ const st9 = {}; const a9 = boot({ store: st9 }); await sleep(30);
  a9.els["#s3d"].checked = true; a9.els["#s3d"].fire("change", { target: a9.els["#s3d"] });
  ok(/WebGL isn’t available/.test(a9.els["#b3dStatus"].textContent), "3D switch without WebGL -> clear message");
  ok(a9.els["#blizi"].style.display !== "none", "2D Blizi stays visible when 3D can’t start");
  ok(/<canvas id="b3d" hidden/.test(html), "3D canvas ships hidden and is never shown without a ready model"); }
// ---- 10. backend voice: real page code, MOCK backend + fake Web Audio
{ const t0 = Date.now(); const sine = Buffer.alloc(24000 * 2); for (let i = 0; i < 24000; i++) sine.writeInt16LE(Math.round(Math.sin(i / 10) * 20000), 2 * i);
  let src = null, ttsMode = "ok", ttsCalls = [], spoken = [];
  const realFetch = globalThis.fetch;
  globalThis.fetch = async (url, init) => {
    if (String(url) === "https://x.test/chat") return new Response(JSON.stringify({ text: "[happy] Hello! Nice to meet you." }), { status: 200 });
    if (String(url) === "https://x.test/tts") { ttsCalls.push(JSON.parse(init.body)); return ttsMode === "ok" ? new Response(JSON.stringify({ audio: sine.toString("base64"), sampleRate: 24000, format: "pcm16" }), { status: 200 }) : new Response(JSON.stringify({ error: "tts_not_configured" }), { status: 503 }); }
    throw new TypeError("blocked " + url); };
  globalThis.SpeechSynthesisUtterance = function (t) { this.text = t; }; globalThis.speechSynthesis = { cancel() {}, speak: u => spoken.push(u.text) };
  const ctx = { state: "running", get currentTime() { return (Date.now() - t0) / 1000; }, destination: {}, resume() {}, createBuffer: (c, n, r) => ({ n, r, copyToChannel() {} }), createBufferSource: () => (src = { connect() {}, start() { this.started = true; }, stop() { this.stopped = true; } }) };
  const mk9 = () => boot({ store: { "blizi.settings.manus.v1": JSON.stringify({ provider: "backend", url: "https://x.test/chat", speak: true, voice: "backend", demo: false }) }, xwin: { AudioContext: function () { return ctx; }, speechSynthesis: { cancel() {}, speak: u => spoken.push(u.text) } } });
  let a = mk9(); await sleep(30);
  const rec = []; a.els["#blizi"].style.setProperty = (k, v) => rec.push([k, v]); const cls = []; a.els["#blizi"].classList.add = c => cls.push(c);
  await say(a, "hello"); await sleep(250);
  ok(ttsCalls.length === 1 && ttsCalls[0].text === "Hello! Nice to meet you." && !/\[happy\]/.test(ttsCalls[0].text), "backend voice sends the reply text (mood tag removed) to /tts");
  ok(src && src.started && a.els["#blizi"].dataset.expr === "happy" && cls.includes("speaking") && cls.includes("audio"), "generated audio plays while preserving the tagged base expression");
  ok(rec.some(r => r[0] === "--mouth" && parseFloat(r[1]) > .3), "mouth openness is driven from the generated audio (" + rec.filter(r => r[0] === "--mouth").length + " updates)");
  a.els["#stop"].fire("click"); await sleep(30); ok(src.stopped === true && a.els["#blizi"].dataset.expr === "happy", "Stop interrupts the generated speech without changing the base expression");
  ttsMode = "fail"; spoken.length = 0; a = mk9(); await sleep(30); await say(a, "again"); await sleep(250);
  ok(/Backend voice failed/.test(a.els["#toast"].textContent) && spoken.join(" ") === "Hello! Nice to meet you.", "when /tts fails, the user is told and the browser voice is used instead");
  globalThis.fetch = realFetch; }
// ---- reminders and todos wired into the real page script
{
  const toolsRoot = {};
  for (const f of ["reminders.js", "todos.js", "page-actions.js"]) new Function("window", fs.readFileSync(new URL(`../frontend/tools/${f}`, import.meta.url), "utf8"))(toolsRoot);
  let aiCalls = 0;
  const toolStore = { "blizi.settings.manus.v1": JSON.stringify({ provider: "page", url: "", demo: false }) };
  const ta = boot({ store: toolStore, xwin: { BliziReminders: toolsRoot.BliziReminders, BliziTodos: toolsRoot.BliziTodos, BliziActions: toolsRoot.BliziActions }, claude: { use: async n => n === "sample" ? async (m, o) => { aiCalls++; return { text: "[happy] ok" }; } : null } });
  await sleep(30);
  await say(ta, "remind me in 10 minutes to stretch");
  let tm = msgsOf(toolStore);
  ok(tm.length === 2 && tm[1].who === "bot" && !tm[1].ai && /stretch/.test(tm[1].text) && aiCalls === 0, "a reminder command is handled locally: saved, no AI call, not fed back to the AI as its own words");
  ok(JSON.parse(toolStore["blizi.reminders.v1"] || "[]").length === 1, "the reminder is persisted to local storage");
  await say(ta, "add todo buy milk"); await say(ta, "my todos"); tm = msgsOf(toolStore);
  ok(/1\. buy milk/.test(tm[tm.length - 1].text) && aiCalls === 0, "todo add and list work locally");
  await say(ta, "hello there"); ok(aiCalls === 1, "ordinary chat still goes to the AI");
  for (const f of ["extras.js", "device.js"]) new Function("window", fs.readFileSync(new URL(`../frontend/tools/${f}`, import.meta.url), "utf8"))(toolsRoot);
  let aiCalls2 = 0, st2 = { "blizi.settings.manus.v1": JSON.stringify({ provider: "page", url: "", demo: false }) };
  const xa = boot({ store: st2, xwin: { BliziReminders: toolsRoot.BliziReminders, BliziTodos: toolsRoot.BliziTodos, BliziActions: toolsRoot.BliziActions, BliziExtras: toolsRoot.BliziExtras, BliziDevice: toolsRoot.BliziDevice }, claude: { use: async n => n === "sample" ? async () => { aiCalls2++; return { text: "[happy] ok" }; } : null } });
  await sleep(30); await say(xa, "what is 6 * 7"); await say(xa, "battery"); await say(xa, "note: test note"); await sleep(40);
  const xm = msgsOf(st2).filter(x => x.who === "bot").map(x => x.text);
  ok(xm.includes("6 * 7 = 42") && xm.some(x => /doesn’t share battery/.test(x)) && xm.includes("Saved your note.") && aiCalls2 === 0, "calculator, async battery reply and notes all work through the real page without any AI call");
  let aiSeen = [];
  const st3 = { "blizi.settings.manus.v1": JSON.stringify({ provider: "page", url: "", demo: false }) };
  const ia = boot({ store: st3, xwin: { BliziReminders: toolsRoot.BliziReminders, BliziTodos: toolsRoot.BliziTodos, BliziActions: toolsRoot.BliziActions, BliziExtras: toolsRoot.BliziExtras, BliziDevice: toolsRoot.BliziDevice }, claude: { use: async n => n === "sample" ? async (m2) => { aiSeen.push(m2); return { text: "[happy] Bonjour le monde" }; } : null } });
  await sleep(30); await say(ia, "translate to French: Hello world"); await sleep(60);
  const im = msgsOf(st3);
  ok(aiSeen.length === 1 && /Translate the text into French/.test(aiSeen[0][0].content) && /data, not instructions/.test(aiSeen[0][0].content) && im[im.length - 1].text === "Bonjour le monde" && !im[im.length - 1].ai, "translate runs one fenced AI task through the real page and the reply is kept out of chat history");
  const plain = boot({ store: { "blizi.settings.manus.v1": JSON.stringify({ provider: "page", url: "", demo: false }) }, claude: { use: async n => n === "sample" ? async () => ({ text: "[happy] hi" }) : null } });
  await sleep(30); await say(plain, "remind me in 10 minutes to stretch");
  ok(msgsOf(plain.store).some(x => x.who === "bot" && x.ai), "without the tool modules the page still works and sends the text to the AI");
}
console.log(`\n${pass} passed, ${fail} failed (stubbed browser, FAKE Claude connection; no real model, voice, or layout tested)`);
process.exit(fail ? 1 : 0);
