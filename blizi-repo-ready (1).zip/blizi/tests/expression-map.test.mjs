import fs from "node:fs";

let pass = 0, fail = 0;
const ok = (condition, name) => { condition ? pass++ : (fail++, console.log("FAIL:", name)); if (condition) console.log("ok  :", name); };
const source = fs.readFileSync(new URL("../frontend/avatar/expression-map.js", import.meta.url), "utf8");
const win = {};
new Function("window", source)(win);
const map = win.BliziExpressionMap;

const expected = ["neutral", "happy", "excited", "embarrassed", "confused", "sad", "angry", "thinking", "sleepy", "speaking"];
ok(JSON.stringify(map.canonicalNames) === JSON.stringify(expected), "canonical registry contains the ten requested expressions in order");
ok(expected.every(name => map.isSupported(name) && map.get(name).name === name), "all ten canonical expressions are supported");
ok(["surprised", "serious", "listening"].every(name => map.isSupported(name)), "legacy expressions remain supported for saved states and callers");
ok(map.normalize("  EXCITED ") === "excited" && map.normalize("unlisted") === "neutral", "normalization is case-insensitive and unknown names fall back to neutral");
ok(map.get("sad").label === "Feeling sad" && map.toVrm("sad").sorrow === 0.7, "the sad expression has a user label and reusable VRM sorrow mapping");
ok(map.toVrm("neutral") && Object.keys(map.toVrm("neutral")).length === 0, "neutral maps to the VRM baseline without adding facial blendshapes");
const weights = map.toVrm("happy"); weights.joy = 0;
ok(map.toVrm("happy").joy === 0.8, "VRM mappings are copied so renderers cannot mutate the shared registry");

const html = fs.readFileSync(new URL("../frontend/index.html", import.meta.url), "utf8");
ok(expected.every(name => new RegExp('data-e="' + name + '"').test(html)), "the Home expression controls expose all ten canonical moods");
const cssStart = html.indexOf("/* character expressions */");
const cssEnd = html.indexOf("/* chat */", cssStart);
const css = html.slice(cssStart, cssEnd);
const mouthStates = {
  neutral: "m-neutral", happy: "m-happy", excited: "m-excited", embarrassed: "m-embarrassed",
  confused: "m-confused", sad: "m-sad", angry: "m-angry", thinking: "m-think", sleepy: "m-sleepy", speaking: "m-o"
};
ok(Object.entries(mouthStates).every(([name, mouth]) => css.includes("[data-expr=" + name + "]") && css.includes("." + mouth)), "each canonical expression has a distinct SVG mouth selector");
ok(/\.face-features\s*\{[^}]*transition/i.test(css) && /\[data-expr=(confused|embarrassed|sad|sleepy)\] \.face-features/.test(css), "appropriate expressions transition the SVG face into a distinct head tilt");
ok(/#blizi\.blink \.lidT/.test(css), "the existing manual/idle blink override remains present");
ok(/avatar\/expression-map\.js/.test(html), "the shared map loads before the browser application");

console.log(`\n${pass} passed, ${fail} failed (expression map and source-level SVG state checks; real browser rendering not tested)`);
process.exit(fail ? 1 : 0);
