import fs from "node:fs";
import assert from "node:assert/strict";

const root = {};
new Function("window", fs.readFileSync(new URL("../frontend/core/self-model.js", import.meta.url), "utf8"))(root);
let face = "serious", activity = "speaking";
const model = root.BliziSelfModel.create({
  name: "Blizi", profileId: "prof_main", now: () => Date.parse("2026-01-01T12:00:00Z"),
  getMode: () => "on", getActivity: () => activity,
  getBodyState: () => ({ expression: face, source: "user-command", speaking: true, canSpeak: true, canListen: false, canChangeExpression: true }),
  getIdentity: () => "Blizi core: curious, warm, candid. Values: honesty, privacy."
});
const state = model.snapshot();
assert.equal(state.name, "Blizi");
assert.equal(state.profileId, "prof_main");
assert.equal(state.mode, "on");
assert.equal(state.activity, "speaking");
assert.equal(state.body.expression, "serious");
assert.equal(state.body.source, "user-command");
assert.ok(state.boundaries.includes("I do not claim consciousness"));
assert.match(model.render(), /current face=serious/);
assert.match(model.render(), /persistent AI companion/);
assert.ok(model.render({ maxChars: 300 }).length <= 300);
assert.match(model.explain("Who are you?"), /persistent AI companion/);
assert.match(model.explain("Why is your face serious?"), /serious/);
activity = "idle"; face = "sad";
assert.match(model.explain("What are you doing?"), /idle/);

console.log("13 passed, 0 failed (runtime self-model identity, body state, capabilities, boundaries, and truthful introspection)");
