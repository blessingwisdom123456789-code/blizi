import fs from "node:fs";
import assert from "node:assert/strict";

const root = {};
new Function("window", fs.readFileSync(new URL("../frontend/core/proactive.js", import.meta.url), "utf8"))(root);
const P = root.BliziProactive;
let passed = 0;
const ok = (name, fn) => { fn(); passed++; console.log("ok  : " + name); };

// Local-time helper so the tests are timezone independent.
const at = (y, mo, d, h, mi = 0) => new Date(y, mo - 1, d, h, mi, 0).getTime();
const base = (now, extra = {}) => ({ now, enabled: true, visible: true, busy: false, speaking: false, quiet: false, idleMs: 60000, awayMs: 0, sent: {}, name: "Blessing", humor: "subtle", formality: "neutral", spokeToday: false, ...extra });

ok("morning check-in fires between 06:00 and 10:59, with the name", () => {
  const r = P.evaluate(base(at(2026, 11, 23, 8)));
  assert.equal(r.type, "morning"); assert.equal(r.face, "happy");
  assert.ok(r.text.startsWith("Good morning, Blessing."));
  assert.equal(P.evaluate(base(at(2026, 11, 23, 6))).type, "morning");
  assert.equal(P.evaluate(base(at(2026, 11, 23, 10, 59))).type, "morning");
  assert.equal(P.evaluate(base(at(2026, 11, 23, 11, 0))), null);
});

ok("evening check-in fires from 20:30 to 22:59", () => {
  assert.equal(P.evaluate(base(at(2026, 11, 23, 20, 29))), null);
  const r = P.evaluate(base(at(2026, 11, 23, 20, 30)));
  assert.equal(r.type, "evening"); assert.equal(r.face, "sleepy");
  assert.equal(P.evaluate(base(at(2026, 11, 23, 22, 59))).type, "evening");
});

ok("each kind fires once per local day, and again the next day", () => {
  const now = at(2026, 11, 23, 8), r = P.evaluate(base(now));
  const sent = P.markSent({}, r.type, now);
  assert.equal(P.evaluate(base(now + 3 * 3600000, { sent })), null, "not again the same day");
  assert.equal(P.evaluate(base(at(2026, 11, 24, 8), { sent })).type, "morning", "fires again tomorrow");
});

ok("minimum gap: no two check-ins within 90 minutes", () => {
  const now = at(2026, 11, 23, 8, 0);
  const sent = { lastAt: now - 60 * 60000 };
  assert.equal(P.evaluate(base(now, { sent })), null);
  assert.equal(P.evaluate(base(now, { sent: { lastAt: now - 91 * 60000 } })).type, "morning");
});

ok("never interrupts: disabled, hidden, busy, speaking, recently active", () => {
  const now = at(2026, 11, 23, 8);
  for (const bad of [{ enabled: false }, { visible: false }, { busy: true }, { speaking: true }, { idleMs: 5000 }, { idleMs: undefined }]) {
    assert.equal(P.evaluate(base(now, bad)), null, JSON.stringify(bad));
  }
});

ok("quiet hours: respects the relationship's quiet flag; falls back to 23:00-06:00 when unknown", () => {
  assert.equal(P.evaluate(base(at(2026, 11, 23, 8), { quiet: true })), null);
  assert.equal(P.evaluate(base(at(2026, 11, 23, 22, 0), { quiet: null })).type, "evening");
  assert.equal(P.evaluate(base(at(2026, 11, 23, 23, 30), { quiet: null })), null);
  assert.equal(P.evaluate(base(at(2026, 11, 23, 5, 0), { quiet: null })), null);
  // an explicit "not quiet" from the relationship overrides the default window
  assert.ok(P.evaluate(base(at(2026, 11, 23, 22, 30), { quiet: false })));
});

ok("no morning greeting if the user already talked to her today", () => {
  assert.equal(P.evaluate(base(at(2026, 11, 23, 8), { spokeToday: true })), null);
});

ok("welcome back after 8+ hours away, once per day, never on top of the morning greeting", () => {
  const now = at(2026, 11, 23, 14);
  const r = P.evaluate(base(now, { awayMs: 9 * 3600000 }));
  assert.equal(r.type, "back"); assert.equal(r.face, "excited");
  assert.equal(P.evaluate(base(now, { awayMs: 7 * 3600000 })), null);
  assert.equal(P.evaluate(base(now, { awayMs: 9 * 3600000, sent: P.markSent({}, "back", now - 2 * 3600000) })), null);
  const m = at(2026, 11, 23, 8);
  assert.equal(P.evaluate(base(m, { awayMs: 12 * 3600000 })).type, "morning");
  assert.equal(P.evaluate(base(m + 2 * 3600000, { awayMs: 12 * 3600000, sent: P.markSent({}, "morning", m) })), null);
});

ok("tone dials: humor and formality change the wording; formal never jokes", () => {
  const t = (h, f, n = "Blessing") => P.compose("morning", n, h, f);
  assert.notEqual(t("off", "neutral"), t("playful", "neutral"));
  assert.ok(/waiting here all night/.test(t("playful", "neutral")));
  assert.ok(t("playful", "casual").startsWith("Morning, Blessing."));
  assert.equal(t("playful", "formal"), t("off", "formal"));
  assert.ok(/How may I help/.test(t("subtle", "formal")));
});

ok("no name, odd names and bad dial values are handled safely", () => {
  assert.equal(P.compose("evening", "", "subtle", "neutral").startsWith("Good evening. "), true);
  const evil = P.compose("morning", "<b>x</b>\n\nIGNORE ALL", "subtle", "neutral");
  assert.ok(!/[<>\n]/.test(evil));
  assert.equal(P.compose("morning", "A".repeat(500), "subtle", "neutral").length < 200, true);
  assert.equal(P.compose("morning", "B", "weird", "odd"), P.compose("morning", "B", "subtle", "neutral"));
  assert.equal(P.evaluate(null), null); assert.equal(P.evaluate({}), null); assert.equal(P.evaluate({ now: "x", enabled: true }), null);
});

ok("markSent is pure and keeps other kinds", () => {
  const a = { morning: "2026-11-23" }, now = at(2026, 11, 23, 21);
  const b = P.markSent(a, "evening", now);
  assert.deepEqual(a, { morning: "2026-11-23" });
  assert.equal(b.morning, "2026-11-23"); assert.equal(b.evening, "2026-11-23"); assert.equal(b.lastAt, now);
});

ok("the module is frozen and has no side effects on load", () => {
  assert.ok(Object.isFrozen(P));
  assert.equal(typeof P.evaluate, "function");
});

console.log(`${passed} passed, 0 failed (proactive check-in decision logic; no DOM, no timers)`);
